/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_NVRAM_H
#define MTK_NVRAM_H

#ifdef __cplusplus
   extern "C" {
#endif


#include "MTK_SDK.h"

/** @defgroup sdk_function Function
  * @{
  */
  
/** @defgroup flash_nvram Flash and NVRam
  * @{
  */
  

/**
 * @brief
 * Read data from the NVRam. \n
 * After giving the start address and length of the NVRam, the wanted NVRam data will be store in NVbuf. 
 * @param[in] Addr    the start address of NVRam want to read from.
 * @param[in] length  how many bytes want to read.
 * @return 
 * true   -->  if the input address and length are available.\n
 * false  -->  the input format is wrong
 * @par Example
 * @code
 * MTK_UTC last_update_time;
 * MTK_Read_NVRam(0,sizeof(MTK_UTC), &last_update_time);
 * @endcode
 * @note
 * Addr = 0 means reading data from the start of NVRam, and available NVRam size is 256 bytes.
 * Adding checksum to the entire NVRam data structure is recommended to ensure data integrity.
 */
unsigned char MTK_Read_NVRam (unsigned int Addr, unsigned int length,
   void* NVbuf);

/**
 * @brief
 * Write data to the NVRam. \n
 * After giving the start address and length of the NVRam, the corresponding source data stored in NVbuf will be written to specified address of NVRam. 
 * @param[in] Addr   the start address of NVRam want to write to.
 * @param[in] length  how many bytes want to write.
 * @return 
 * true   -->  if the input address and length are available.
 * false   -->  the input format is wrong
 * @par Example
 * @code
 * MTK_UTC update_time;
 * MTK_Get_UTC(&update_time);
 * MTK_Write_NVRam(0,sizeof(MTK_UTC), &update_time);
 * @endcode
 */
unsigned char MTK_Write_NVRam (unsigned int Addr, unsigned int length,
   const void* NVbuf);

/**
  * @}
  */
  
/**
  * @}
  */

#ifdef __cplusplus
   }
#endif

#endif /* MTK_NVRAM_H */
