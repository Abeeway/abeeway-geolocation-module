/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_IOPIN_H
#define MTK_IOPIN_H

#ifdef __cplusplus
   extern "C" {
#endif


#include "MTK_SDK.h"

/** @defgroup sdk_enum Enums
  * @{
  */
  
/** @brief
 * This enum defines external interrupt pin. 
 */
typedef enum
{
   PIN_INT0 = 0, /**< EIN0 (GPIO12). */
   PIN_STANDBY = 1 /**< EIN1 (GPIO13). */
}  eExtInt_Pin;
/**
  * @}
  */
  
/** @defgroup sdk_function Function
  * @{
  */
  
/** @defgroup gpio GPIO
  * @{
  * GPIO is the abbreviation of General Purpose Input/Output. \n
  * Sixteen GPIO ports are provided for SDK developer, i.e. GPIO 0~15. 
  * Therefore, developer can set the status of these these GPIO ports to high or low.
  */
  
/**
 * @brief
 * Config the input pin to be the external interrupt pin if the interrupt handler 'f_handler' is specified. \n
 * If the 'f_handler' is NULL, the corresponding interrupt will be disabled. 
 * @param[in] pin the pin that want to be set as external interrupt.
 * @return 
 * The entry point of the previous interrupt handler.
 * @par Example
 * @code
 *   volatile int global_count;
 *   void handler (void) 
 *   { 
 *     global_count++; 
 *     MTK_Disable_ExtInterrupt(PIN_INT0); 
 *   }
 *
 *   int SDK_Init (void) 
 *   { 
 *     ......
 *     global_count = 0; 
 *     MTK_Config_ExtInterrupt(PIN_INT0, handler); 
 *     MTK_Enable_ExtInterrupt(PIN_INT0); 
 *     ......
 *   }
 *
 *   void SDK_Main (void)
 *   {
 *     ......
 *     // global_count would be 1 if the interrupt had happened
 *     MTK_NMEA_OutputData("SDK,Test,%d", global_count);
 *     ......
 *   }
 * @endcode
 * @note
 * The stack space is very limited(<64bytes) in the interrupt handler.
 */
unsigned MTK_Config_ExtInterrupt (eExtInt_Pin pin, void (*f_handler)(void));

/**
 * @brief
 * Remove the interrupt status mask of the specified input pin. 
 * @param[in] eExtInt_Pin pin:  the external interrupt pin that will be set as enable.
 * @return nonzero --> success;\n 0 --> failure
 * @par Example
 * Please refer to MTK_Config_ExtInterrupt().
 */
int MTK_Enable_ExtInterrupt (eExtInt_Pin pin);

/**
 * @brief
 * Set interrupt status mask of the specified input pin. 
 * @param[in] pin  the external interrupt pin that will be set as disable. 
 * @return nonzero --> success;\n 0 --> failure
 * @par Example
 * Please refer to MTK_Config_ExtInterrupt()
 */
int MTK_Disable_ExtInterrupt (eExtInt_Pin pin);

/**
 * @brief
 * Read the logic level of the external interrupt pin regardless of interrupt disabled or enable.\n
 * The logic level will be given by a return value in integer type. 
 * @param[in] pin  input the number of external interrupt pin that you want to read. 
 * @return value: 1 --> high or 0 --> low
 */
int MTK_Read_ExtInterrupt (eExtInt_Pin pin);

/**
 * @brief
 * Select a GIO port and configure it as input or output.
 * @param[in] PortNum the Port-th GIO will be set as input if IOSelect is 1, or ouput if IOSelect is 0.\n
 * Input   -> 0,1,2,3,7,8,9,10,11,12,13\n
 * Output  -> 0,1,2,3,7,8,9,10,11,12,13,15,16,18,20\n
 * @param[in] IOSelect value 1: as input, value 0: as ouput.
 * @param reserved1 reserved
 * @param reserved2 reserved
 * @note This function can put into SDK_Init() for initialization.
 * @return TRUE -> Success\n    FALSE -> Failure
 * @par Example
 * @code
 *    unsigned char Success = 0;
 *    unsigned char IOSelect = 1;
 *    Success = MTK_Config_GIO(1,IOSelect,0,0))
 *    ===> you will find that GIO1 is configured as input mode
 * @endcode
 */
unsigned char MTK_Config_GIO(
        unsigned char PortNum,     // set the Port-th port 
        unsigned char IOSelect,    // set as input or output
        unsigned char reserved1,   // reserved
        unsigned char reserved2);  // reserved

/**
 * @brief
 * Set the chosen GIO port to high or low.\n
 * Provided Ports  :  0,1,2,3,7,8,9,10,11,12,13,15,16,18,20.\n
 * the PortNum-th GIO will be set to high or low according to HighLow
 * If you choose a port that is not supported, return 0.
 * @param[in] PortNum which port you want to set
 * @param[in] HighLow you want to set the port High or Low
 * @return TRUE -> Success\n    FALSE -> Failure
 * @par Example
 * @code
 *    unsigned char HighLow1 = 1;
 *    unsigned char GIOState1 = 0;
 *    if (MTK_Set_GIO(1,HighLow1))
 *    {
 *        HighLow1 = HighLow1^1;
 *        MTK_NMEA_OutputData("SDK,HighLow1,%d", HighLow1);
 *        if(MTK_Read_GIO(1,&GIOState1))
 *        MTK_NMEA_OutputData("SDK,GIO1,%d", GIOState1);
 *    }
 *
 *    =====> $SDK,GIO1,0*1E
 *           $SDK,GIO1,1*1F
 *      you will also see square wave with frequency 0.5 Hz
 * @endcode
 */
unsigned char MTK_Set_GIO(
                  unsigned char PortNum,  // input, which port you want to set
                  unsigned char HighLow); // input, you want to set the port High or Low

/**
 * @brief
 * Read the status of chosen GIO port.\n
 * Provided Ports  :  0,1,2,3,7,8,9,10,11,12,13.\n
 * The status of the PortNum-th GIO will be stored in Status.
 * If you choose a port that is not supported, return 0.
 * @param[in] PortNum status of which port you want to know
 * @param[in] Status the status of the chosen port
 * @return TRUE -> Success\n    FALSE -> Failure
 * @par Example
 * @code
 *    unsigned char HighLow1 = 1;
 *    unsigned char GIOState1 = 0;
 *    if (MTK_Set_GIO(1,HighLow1))
 *    {
 *        HighLow1 = HighLow1^1;
 *        MTK_NMEA_OutputData("SDK,HighLow1,%d", HighLow1);
 *        if(MTK_Read_GIO(1,&GIOState1))
 *        MTK_NMEA_OutputData("SDK,GIO1,%d", GIOState1);
 *    }
 *
 *    =====> $SDK,GIO1,0*1E
 *           $SDK,GIO1,1*1F
 *      you will also see square wave with frequency 0.5 Hz
 * @endcode
 */
unsigned char MTK_Read_GIO(
                  unsigned char PortNum,  // input, status of which port you want to know
                  unsigned char *Status); // output, the status of the chosen port

/**
 * @brief
 * This function is used to enable or disable I2C module. 
 * @param[in] enable  nonzero for enable I2C;  zero for disable I2C. 
 * @return 
 * void
 * @par Example
 * @code
 *    MTK_I2C_Enable(1);
 *    MTK_I2C_Write(0x3C, 0x01, 0xFF);
 *    MTK_I2C_Enable(0);
 * @endcode
 * @note
 * Please enable I2C before read/write. Otherwise, the system could hang. 
 * If I2C read/write has done, please disable I2C to save system resources.
 */
void MTK_I2C_Enable (
                  unsigned char enable);

/**
 * @brief
 * I2C read bytes from slave.
 * @param[in] dev      slave dev address.
 * @param[in] addr     register address.
 * @param[in] count    how many bytes you want to read once from slave.
 * @param[out] data[]  the content read from slave.
 * @return 
 * void
 * @note the count must be less than 8, it means you can read 8 bytes once from slave at most.
 */
void MTK_I2C_Read (
                   unsigned char dev, 
                   unsigned char addr,
                   unsigned short data[],
                   unsigned short count);

/**
 * @brief
 * I2C write bytes to slave.
 * @param[in] dev      slave dev address.
 * @param[in] addr     register address.
 * @param[in] count    how many bytes you want to write once to slave.
 * @param[in] data[]   the content will be written to slave.
 * @return 
 * void
 * @note the count must be less than 7, it means you can write 7 bytes once to slave at most.
 * if you want to just write a command to slave, please set count zero,then parameter:addr will 
 * be ignored.
 */
void MTK_I2C_Write (unsigned char dev, 
                        unsigned char addr, 
                        unsigned short data[],
                        unsigned short count);

/**
 * @brief
 * Set values of multiple GPIO output ports. The values and multiple GPIO ports shall be given by bitmap. 
 * @param[in] Value   the output value for respective GPIO pins (bi0 = GIO0, bit1 =GIO1...). 
 * @param[in] Mask    turned-on bits mean these pins need to be set. 
 * @return 
 * void 
 * @par Example
 * @code
 * unsigned Value = 0;
 * //Set GIO6 =1, GIO7 = 0, GIO8 = 1
 * MTK_Set_GIO_Array(0x00000140, 0x000001C0);
 * //Read logic level of GIO6, 7, 8
 * Value = MTK_Read_GIO_Array(0x000001C0);
 * //values of bit 6,7,8 represent logic levels of GIO6,7,8
 * MTK_UART_OutputData("***GIO level: %x***", Value);
 * @endcode
 */
void MTK_Set_GIO_Array (
        unsigned Value,         // wanted output pin values
        unsigned Mask);         // mask for setting wanted pins

/**
 * @brief
 * Read logic levels from multiple input GPIO ports. \n
 * The multiple GPIO ports are input by bitmap. Only port 0,2,6,7,8,11,12,13,14,15 are supported
 * @param[in] Mask   turned-on bits mean these pins need to be read. 
 * @return 
 * a 16bit bitmap that values of each bit represent logic levels of multiple input GPIO ports. 
 * @par Example
 * @code
 * //Read logic level of GPIO2, GPIO6, GPIO8, GPIO11, GPIO12
 * unsigned Value = MTK_Read_GIO_Array(0x00001944);
 * //values of bit 2,6,8,11,12 representing logic levels of GPIO2,6,8,11,12 respectively.
 * @endcode
 */
unsigned MTK_Read_GIO_Array (unsigned Mask);

/**
 * @brief
 * To choose whether need trigger 1PPS output or not when no fix position.
 * @param[in] Enable 1, Trigger 1PPS output even when no fix position.\n
 * 0, Don't trigger 1PPS output when no fix position
 * @return 
 * void
 */
void MTK_Trigger_1PPS (unsigned char Enable);

/**
 * @brief
 * Select favorite GPIO to output 1PPS. Provided ports are 7, 9, 13, 14, 15.
 * @param[in] PortNum  input the number of port which will be selected to output 1PPS.
 * @return 
 * true   -->  success\n
 * false  -->  failure
 */
unsigned char MTK_Select_PPS_Port (unsigned char PortNum);

/**
 * @brief
 * Disable selected GPIO to output 1PPS. Provided ports are 7, 9, 13, 14, 15.
 * @param[in] PortNum  input the number of port which 1PPS output will be disable.
 * @return 
 * true   -->  success\n
 * false  -->  failure
 */
unsigned char MTK_Disable_PPS_Port (unsigned char PortNum);

/**
 * @brief
 * Enable 1PPS output
 * @return 
 * void
 */
void MTK_Enable_1PPS (void);

/**
 * @brief
 * Disable 1PPS output.
 * @return 
 * void
 */
void MTK_Disable_1PPS (void);

/**
 * @brief
 * Set the type and pulse width of 1PPS's output. 
 * @param[in] ppstype  the type of 1PPS's output.\n
 * ppstype  =  0 :  Disable 1PPS output\n
 * 1:  Send 1PPS after TTFF\n
 * 2:  Send 1PPS after 3D_Fix\n
 * 3:  Send 1PPS after 2D_Fix\n
 * 4:  Send 1PPS always\n
 * @param[in]  mswidth  pulse width in millisecond
 * @return 
 * true    -->     success\n
 * false   -->     failure\n
 * @par Example
 * @code
 * MTK_Set_1PPS_Pulse_Width(0,0);       //Disable 1PPS output 
 * MTK_Set_1PPS_Pulse_Width(1,200);  // PPS after TTFF. 1PPS output 200ms high, 800ms low 
 * MTK_Set_1PPS_Pulse_Width(2,200);  // PPS after 3D_Fix. 1PPS output 200ms high, 800ms low 
 * MTK_Set_1PPS_Pulse_Width(3,200);  // PPS after 2D_Fix. 1PPS output 200ms high, 800ms low
 * MTK_Set_1PPS_Pulse_Width(4,200);  //PPS always. 1PPS output 200ms high, 800ms low
 * @endcode
 */
unsigned char MTK_Set_1PPS_Pulse_Width (unsigned char ppstype,unsigned short mswidth);

/**
 * @brief
 * Set the delay time of 1PPS's output. 
 * @param[in] ppsdelaytime  PPS delay time (0 ~2000ns).
 * @return 
 * true    --> success\n
 * false   --> failure\n
 */
unsigned char MTK_Set_1PPS_Delay_Time (short ppsdelaytime);

/**
 * @brief
 * Get the 1PPS's config 
 * @param pps_hw_enabled PPS hardware is enabled or not.\n 
 *  0: Disabled.\n
 *  1: Enabled.\n
 *  @param pps_type The type of 1PPS's output timing.\n
 *  0: PPS output disabled by software.\n
 *  1: PPS After TTFF.\n
 *  2: PPS After 3D_FIX.\n 
 *  3: PPS After 2D_FIX.\n
 *  4: PPS Always.\n 
 *  @param mswidth Pulse width in millisecond (range: 0~999)\n
 * @par Example
 * @code
 *      unsigned char pps_hw_enabled, pps_type;
 *      unsigned short mswidth;
 *      MTK_Get_PPS_Config(&pps_hw_enabled, &pps_type, &mswidth );
 *      MTK_NMEA_OutputData("SDK,PPS,%d,%d,%d",pps_hw_enabled,pps_type,mswidth);
 * @endcode
 */
void MTK_Get_PPS_Config(unsigned char *pps_hw_enabled, unsigned char *pps_type, unsigned short *mswidth );

/**
 * @brief
 * Enable Pulse Per Fix feature
 * @param[in] fgEnablePPF  1: Enable;\n 0: Disable
 * @return 
 *    TRUE -> Success\n    FALSE -> Failure
 */
unsigned char MTK_Enable_PPF(unsigned char fgEnablePPF);

/**
 * @brief
 * Power on the SPI interface. Before using the SPI interface, we need call this function to power on SPI.
 * @return 
 * void
 * @par Example
 * @code
 * unsigned char pCmdBuf[8];
 * unsigned char pSerialFlashID[4];
 * pCmdBuf[0] = 0x9F;  // Read serial flash ID Command
 * 
 * MTK_SPI_Enable();  // Power on SPI
 * Set_SPI_CE_Low();  // User set the serial flash CE(or CS) pin to low
 * MTK_SPI_EXEC(1, 4, pCmdBuf);  // Execute SPI command
 * Set_SPI_CE_High(); // User set the serial flash CE(or CS) pin to high
 * MTK_SPI_Disable();  // Power down SPI
 * pSerialFlashID[0] = pCmdBuf[1];
 * pSerialFlashID[1] = pCmdBuf[2];
 * pSerialFlashID[2] = pCmdBuf[3];
 * pSerialFlashID[3] = pCmdBuf[4];
 * @endcode
 */
void MTK_SPI_Enable(void);

/**
 * @brief
 * Power down the SPI interface. After using SPI, call this function to power down SPI if needed.
 * @return 
 * void
 * @par Example
 * @code
 * unsigned char pCmdBuf[8];
 * unsigned char pSerialFlashID[4];
 * pCmdBuf[0] = 0x9F;  // Read serial flash ID Command
 * 
 * MTK_SPI_Enable();  // Power on SPI
 * Set_SPI_CE_Low();  // User set the serial flash CE(or CS) pin to low
 * MTK_SPI_EXEC(1, 4, pCmdBuf);  // Execute SPI command
 * Set_SPI_CE_High(); // User set the serial flash CE(or CS) pin to high
 * MTK_SPI_Disable();  // Power down SPI
 * pSerialFlashID[0] = pCmdBuf[1];
 * pSerialFlashID[1] = pCmdBuf[2];
 * pSerialFlashID[2] = pCmdBuf[3];
 * pSerialFlashID[3] = pCmdBuf[4];
 * @endcode
 */
void MTK_SPI_Disable(void);

/**
 * @brief
 * After enabling SPI interface, user can change clock rate of SPI interface.\n 
 * This function is used to set clock rate of SPI interface. 
 * SPI clock is 48MHz / (Division + 1), and Division must larger than 1.
 * @param[in] ClockDivision   The Division number
 * @return 
 * 1    -->     success\n
 * 0    -->     failure
 */
int MTK_SPI_SetClock(unsigned char ClockDivision);

/**
 * @brief
 * Set the active SPI port
 * @param[in] port active SPI port number (0=port0, 1=port1)
 * @return Value : 32-bit integer. \n
 * zero: configuration fail.\n
 * non-zero: configuration successfully.
 */
int MTK_Set_SPI_Port (int port);

/**
 * @brief
 * Execute the SPI command
 * @param[in] u2OutLen Output command length (if no output , fill 0)
 * @param[in] u2InLen  Input data length     (if no input  , fill 0)
 * @param[in] pCmdBuf  Buffer contain commands to send
 * @return  Return data will be put in pCmdBuf[], from pCmdBuf[u2OutLen] to pCmdBuf[u2OutLen + u2InLen - 1]
 * @note Please make sure pCmdBuf[] allocates enough space for input data.\n
 *  This function manipulate SI, SO, SCK pin, user should take care the control of CE(or CS) pin.
 * @par Example
 * @code
 *   unsigned char pCmdBuf[8];
 *   unsigned char pSerialFlashID[4];
 *
 *   pCmdBuf[0] = 0x9F;  // Read serial flash ID Command
 *
 *   MTK_SPI_Enable();  // Power on SPI
 *
 *   Set_SPI_CE_Low();  // User set the serial flash CE(or CS) pin to low
 *
 *   MTK_SPI_EXEC(1, 4, pCmdBuf);  // Execute SPI command
 *
 *   Set_SPI_CE_High(); // User set the serial flash CE(or CS) pin to high
 *
 *   MTK_SPI_Disable();  // Power down SPI
 *
 *   pSerialFlashID[0] = pCmdBuf[1];
 *   pSerialFlashID[1] = pCmdBuf[2];
 *   pSerialFlashID[2] = pCmdBuf[3];
 *   pSerialFlashID[3] = pCmdBuf[4];
 * @endcode
 */
void MTK_SPI_EXEC( unsigned short u2OutLen, unsigned short u2InLen, unsigned char * pCmdBuf);

/**
 * @brief
 * Detect if external antenna is used. Return the result of detection on external antenna.
 * @return Value : 32-bit integer. \n
 *  zero: use internal antennal\n
 *  non-zero: external antenna used\n
 */
int MTK_Antenna_Detect(void);

/**
 * @brief
 * Detect if antenna is short.\n
 * Return the result of detection on antenna short.
 * @return Value : 32-bit integer. \n
 *  zero: no short\n
 *  non-zero: short\n
 */
int MTK_Antenna_Short(void);

/**
 * @brief
 * Config if 32K output or not
 * @param[in] fgEn32Kout  Buffer contain commands to send.\n
 *  1   -->   enable 32K out\n
 *  0   -->   disable 32K out\n
 * @return 
 * 1   -->    succeed\n
 * 0   -->     fail\n
 */
int MTK_Config_32K_Output(unsigned char fgEn32Kout);

/**
 * @brief
 * Config if DR output or not. 
 * @param[in] fgEnDRout  Buffer contain commands to send.\n
 * 1   -->   enable DR out\n
 * 0   -->   disable DR out\n
 * @return 
 * 1   -->    succeed\n
 * 0   -->     fail\n
 */
int MTK_Config_DR_Output(unsigned char fgEnDRout);

/**
 * @brief
 * Set MTK GPS chip I2C slave address, 7bit mode. 
 * @param[in]  i4Slave_Addr    address of I2C slave.
 * @return 
 * void
 * @note Only LSB 7 bit data will be used.
 */
void MTK_Set_I2C_Slave_Addr(int i4Slave_Addr);

/**
 * @brief
 * Select a GIO port and get its configuration.\n
 * Provided Ports  :  Input   -> 0,2,6,7,8,11,12,13,14,15\n
 *                    Output -> 0,1,2,3,7,8,9,10,11,12,13,14,15\n
 * This function is used to get configuration of selected GIO port, which includes the port
 * type (whether the selected prot is GIO port or not) and the GIO mode (input or output). 
 * @param[in] PortNum is the selected GIO port number. 
 * @param[in] PortType will be set as 1 if selected port is for GIO, and as 0 if not for GIO.
 * @param[in] IOSelect will be set as 1 if selected prot configure as input, and 0 for output.
 * @return TRUE -> Success\n    FALSE -> Failure
 * @par Example
 * @code
 *        unsigned char PortType;
 *        unsigned char IOSelect;
 *        unsigned char Success = 0;
 *        Success = MTK_Get_GIO_Config (1, &PortType, &IOSelect)
 *
 *   If Success = 1, the configuration of port 1 will store in IOSelect.
 * @endcode
 * @note If selected port is not GPIO, the value of IOSelect will not be updated.
 */
int MTK_Get_GIO_Config(unsigned char PortNum, unsigned char *PortType, unsigned char *IOSelect);

/**
  * @}
  */
  
/**
  * @}
  */
#ifdef __cplusplus
   }
#endif

#endif /* MTK_IOPIN_H */
