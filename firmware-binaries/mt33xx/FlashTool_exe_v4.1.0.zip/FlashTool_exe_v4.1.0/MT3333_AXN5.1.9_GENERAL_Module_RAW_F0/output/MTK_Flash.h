/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_FLASH_H
#define MTK_FLASH_H

#ifdef __cplusplus
   extern "C" {
#endif


#include "MTK_SDK.h"

/** @defgroup sdk_function Function
  * @{
  */
  
/** @defgroup flash_nvram Flash and NVRam
  * @{
  */
  
  
/**
 * @brief
 * Open Flash.\n
 * Before using flash operation (MTK_FlashSmallSectorErase(), MTK_FlashTotalErase(), MTK_FlashRead() or MTK_FlashWrite()), please call MTK_FlashOpen() first. 
 * @return 
 * 1   -->   success\n
 * 0   -->   failure\n
 * @par Example
 * @code
 * char DataBuf [100];
 * unsigned long WriteCnt;
 * MTK_FlashOpen();
 * MTK_FlashSmallSectorErase(0);
 * WriteCnt = MTK_FlashWrite (0, 100, DataBuf); // write 100 bytes into addr offset 0
 * MTK_FlashClose();
 * @endcode
 */
int  MTK_FlashOpen(void);

/**
 * @brief
 * Close flash.\n
 * After using flash operation (MTK_FlashTotalErase(), MTK_FlashRead() or MTK_FlashWrite()), please call MTK_FlashClose() also. 
 * @return 
 * void
 * @par Example
 * @code
 * char DataBuf [100];
 * unsigned long ReadCnt;
 * MTK_FlashOpen();
 * MTK_FlashSmallSectorErase(0);
 * ReadCnt = MTK_FlashRead (0, 100, DataBuf); // write 100 bytes into addr offset 0
 * MTK_FlashClose();
 * @endcode
 */
void MTK_FlashClose(void);

/**
 * @brief
 * This function is used to read data from flash. The read unit is byte. 
 * The total customization flash size is 32K bytes.
 * @param[in] AddrOffset  The flash address offset want to read from. [rang: 0~0x7FFF]
 * @param[in] ReadNum  How many bytes want to read.
 * @param[out] ReadBuf  The buffer to store the data read from flash.
 * @return 
 * return how many bytes actually read from the flash.
 * @par Example
 * @code
 * char DataBuf [100];
 * unsigned long ReadCnt;
 * MTK_FlashOpen();
 * ReadCnt = MTK_FlashRead (0, 100, DataBuf);
 * MTK_FlashClose();
 * @endcode
 */
unsigned int MTK_FlashRead(unsigned AddrOffset, unsigned ReadNum, char *ReadBuf);

/**
 * @brief
 * This function is used to write data into flash. The write unit is byte. 
 * The total writeable flash size is 32K bytes.
 * @param[in] AddrOffset  The flash address want to write into. [range: 0~0x7FFF]
 * @param[in] WriteNum  How many bytes want to write.
 * @param[in] WriteBuf  The data will be write into flash.
 * @return 
 * return how many bytes actually write to the flash if finished.\n
 * 0 if failed
 * @par Example
 * @code
 * char DataBuf [100];
 * unsigned long WriteCnt;
 * MTK_FlashOpen();
 * MTK_FlashSmallSectorErase(0); // Erase the 4K flash sector region of addr offset 0 before write data
 * WriteCnt = MTK_FlashWrite (0, 100, DataBuf); // write 100 bytes data into addr offset 0
 * MTK_FlashClose();
 * @endcode
 * @note
 * The data of WriteBuf cannot come from flash. The WriteBuf cannot be a constant array in global area.\n
 * Must call MTK_FlashSmallSectorErase() or MTK_FlashTotalErase() to erase the flash region before using MTK_FlashWrite() to write data
 * 
 */
unsigned int MTK_FlashWrite(unsigned AddrOffset, unsigned writeNum, const char *WriteBuf);

/**
 * @brief
 * This function is used to erase the whole customization region(32K bytes). 
 * @return 
 * return 1 if sucess.\n
 * 0 if failed
 */
unsigned int MTK_FlashTotalErase(void);

/**
 * @brief
 * This function is used to erase the all data of input address' sector. The erase unit is sector(4KB). 
 * @param[in] AddrOffset The flash address offset of the sector wants to erase. [Range: 0~0x7FFF]
 * @return 
 * return nonzero if succeeded.\n
 * 0 if failed
 * @note
 *    The actual erase address will always be 4K aligned address. For example:\n
 *    If call MTK_FlashSmallSectorErase(0x100), the actual erase region will be [0 ~ 0xFFF]\n
 *    If call MTK_FlashSmallSectorErase(0x1200), the actual erase region will be [0x1000 ~ 0x1FFF] \n
 *
 */
unsigned int MTK_FlashSmallSectorErase (unsigned AddrOffset);

/**
  * @}
  */
  
/**
  * @}
  */
#ifdef __cplusplus
   }
#endif

#endif /* MTK_FLASH_H */
