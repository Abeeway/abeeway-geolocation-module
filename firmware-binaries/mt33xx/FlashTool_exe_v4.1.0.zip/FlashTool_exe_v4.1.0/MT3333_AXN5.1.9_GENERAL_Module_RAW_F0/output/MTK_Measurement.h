/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_MEASUREMENT_H
#define MTK_MEASUREMENT_H

#ifdef __cplusplus
   extern "C" {
#endif

//******************************************************************************
// MTK_Set_Raw_Measurment_Msg_Output  : Set raw measurement message output or not
// Input Value:
//    MsgOutputSetting = -1 ---> Disable PMTKNED/PMTKCHL/PMTKGRP sentence output
//    MsgOutputSetting = 0  ---> Enable PMTKNED/PMTKCHL/PMTKGRP sentence output
// Return Value: 
//    TRUE : Setting success
//    FALSE : Setting fail
// Example :
//    signed char MsgOutputSetting;
//    MsgOutputSetting = -1;
//    MTK_Set_Raw_Measurment_Msg_Output(MsgOutputSetting);

unsigned char MTK_Set_Raw_Measurment_Msg_Output (signed char MsgOutputSetting);

//*************************************************************************************
// MTK_Get_Raw_Measurement  :  Get the raw measurement of GPS satellites
//
// Note  :  
//          PR_Meas        : Pseodorange measurement          ( Unit : meter  )
//          DO_Meas        : Doppler measurment               ( Unit : Hz     )
//          CP_Meas        : Carrier phase measurement        ( Unit : cycle  )
//          CPMeasOK       : Carrier phase measurement value is half wave cycle locked or not. 
//                             0      --->  This carrier phase measurement of the SV is unlocked.
//                             1      --->  This carrier phase measurement of the SV is carrier locked.
//                             2      --->  This carrier phase measurement of the SV is half wave cycle locked.
//          CycleSlipCount : Incremented every time there is a cycle slip on this satellite  ( Range : 0-999 )
//          IOD            : IODE for GPS                     ( Range : 0-255 )  ** If there are no IODE, the value will show '999' **                           
//          SVPosX         : Satellite ECEF positions (X)     ( Unit : meter  )
//          SVPosY         : Satellite ECEF positions (Y)     ( Unit : meter  )
//          SVPosZ         : Satellite ECEF positions (Z)     ( Unit : meter  )
//          IonoCorr       : Ionosphere Correction value      ( Unit : meter  )
//          SNR            : C/N0 of satellite                ( Unit : dB-Hz  )
//          IonoSource     : Ionosphere source
//                             0      --->  None
//                             1      --->  Broadcast
//                             2      --->  SBAS
//          SyncStatus     : GNSS data sync status
//                             0      --->  None
//                             1      --->  Bit sync
//                             2      --->  Subframe sync
//                             3      --->  Exact sync (Measurement is usable)
// Example:
//          unsigned char i;
//          double PR_Meas[32],DO_Meas[32],CP_Meas[32], reserved1[32];
//          unsigned char CP_Meas_OK[32];
//          unsigned short CycleSlipCount[32], IOD[32];
//          double SVPosX[32],SVPosY[32],SVPosZ[32];
//          float IonoCorr[32];
//          unsigned char SNR[32], IonoSource[32], SyncStatus[32];
//          MTK_Get_Raw_Measurement(PR_Meas, DO_Meas,CP_Meas,reserved1,CP_Meas_OK,CycleSlipCount, IOD,SVPosX,SVPosY,SVPosZ,IonoCorr,SNR,IonoSource,SyncStatus);
//
//          for (i=0;i<32;i++)
//          {
//             if (SNR[i]>0)
//             {
//                MTK_UART_OutputData("SDK:GPS SV=%d PR_Meas = %.2f DO_Meas = %.1f CP_Meas = %.3f CP_Meas_OK = %d CycleSlipCount = %d IOD = %d",
//                                            (i+1), PR_Meas[i], DO_Meas[i], CP_Meas[i], CP_Meas_OK[i], CycleSlipCount[i], IOD[i]);
//                MTK_UART_OutputData("SDK:GPS SVPosX = %.2f SVPosY = %.2f SVPosZ = %.2f IonoCorr = %f SNR = %d IonoSource = %d SyncStatus = %d",
//                                             SVPosX[i], SVPosY[i], SVPosZ[i], IonoCorr[i], SNR[i], IonoSource[i], SyncStatus[i]);
//             }
//          }
//
// ======>  SDK:GPS SV=18 PR_Meas = 24586843.18 DO_Meas = 2183.0 CP_Meas = -464399.857 CP_Meas_OK = 2 CycleSlipCount = 0 IOD = 25
//          SDK:GPS SVPosX = 14035863.00 SVPosY = 15603765.00 SVPosZ = 16945808.00 IonoCorr = -4.526943 SNR = 36 IonoSource = 2 SyncStatus = 3

void MTK_Get_Raw_Measurement (double PR_Meas[32], double DO_Meas[32], double CP_Meas[32], double reserved1[32], unsigned char CP_Meas_OK[32],
                                           unsigned short CycleSlipCount[32], unsigned short IOD[32],
                                           double SVPosX[32],double SVPosY[32],double SVPosZ[32], float IonoCorr[32],                                          
                                           unsigned char SNR[32], unsigned char IonoSource[32], unsigned char SyncStatus[32] );

//*************************************************************************************
// MTK_Get_GLON_Raw_Measurement  :  Get the raw measurement of GLONASS satellites
//
// Note  :  
//          PR_Meas        : Pseodorange measurement          ( Unit : meter  )
//          DO_Meas        : Doppler measurment               ( Unit : Hz     )
//          CP_Meas        : Carrier phase measurement        ( Unit : cycle  )
//          CPMeasOK       : Carrier phase measurement value is half wave cycle locked or not. 
//                             0      --->  This carrier phase measurement of the SV is unlocked.
//                             1      --->  This carrier phase measurement of the SV is carrier locked.
//                             2      --->  This carrier phase measurement of the SV is half wave cycle locked.
//          CycleSlipCount : Incremented every time there is a cycle slip on this satellite  ( Range : 0-999 )
//          Tb             : Tb for Glonass                   
//          SVPosX         : Satellite ECEF positions (X)     ( Unit : meter  )
//          SVPosY         : Satellite ECEF positions (Y)     ( Unit : meter  )
//          SVPosZ         : Satellite ECEF positions (Z)     ( Unit : meter  )
//          IonoCorr       : Ionosphere Correction value      ( Unit : meter  )
//          SNR            : C/N0 of satellite                ( Unit : dB-Hz  )
//          IonoSource     : Ionosphere source
//                             0      --->  None
//                             1      --->  Broadcast
//                             2      --->  SBAS
//          SyncStatus     : GNSS data sync status
//                             0      --->  None
//                             1      --->  Bit sync
//                             2      --->  Subframe sync
//                             3      --->  Exact sync (Measurement is usable)
//          FreqChannel    : Glonass satellite frequency channel number  ( Range : (-7) - 6 )
//
// Example:
//          unsigned char i;
//          double PR_Meas[24],DO_Meas[24],CP_Meas[24],reserved1[24];
//          unsigned char CP_Meas_OK[24];
//          unsigned short CycleSlipCount[24], Tb[24];
//          double SVPosX[24],SVPosY[24],SVPosZ[24];
//          float IonoCorr[24];
//          unsigned char SNR[24], IonoSource[24], SyncStatus[24];
//          signed char FreqChannel[24];
//          MTK_Get_GLON_Raw_Measurement(PR_Meas,DO_Meas,CP_Meas,reserved1,CP_Meas_OK,CycleSlipCount,Tb,SVPosX,SVPosY,SVPosZ,IonoCorr,SNR,IonoSource,SyncStatus,FreqChannel);
//
//          for (i=0;i<24;i++)
//          {
//             if (SNR[i]>0)
//             {
//                MTK_UART_OutputData("SDK:GLON SV=%d PR_Meas = %.2f DO_Meas = %.1f CP_Meas = %.3f CP_Meas_OK = %d CycleSlipCount = %d Tb = %d",
//                                              (i+1),PR_Meas[i],DO_Meas[i],CP_Meas[i],CP_Meas_OK[i],CycleSlipCount[i],Tb[i]);
//                MTK_UART_OutputData("SDK:GLON SVPosX = %.2f SVPosY = %.2f SVPosZ = %.2f IonoCorr = %f SNR = %d IonoSource = %d SyncStatus = %d FreqChannel = %d",
//                                              SVPosX[i],SVPosY[i],SVPosZ[i],IonoCorr[i],SNR[i],IonoSource[i],SyncStatus[i],FreqChannel[i]);
//             }
//          }
//
// ======>  SDK:GLON SV=8 PR_Meas = 22741170.42 DO_Meas = -1321.8 CP_Meas = 57410.808 CP_Meas_OK = 2 CycleSlipCount = 0 Tb = 63
//          SDK:GLON SVPosX = -19378142.00 SVPosY = -2650414.00 SVPosZ = 16437415.00 IonoCorr = 3.305518 SNR = 36 IonoSource = 1 SyncStatus = 3 FreqChannel = 6

void MTK_Get_GLON_Raw_Measurement (double PR_Meas[24], double DO_Meas[24], double CP_Meas[24], double reserved1[24], unsigned char CP_Meas_OK[24],
                                           unsigned short CycleSlipCount[24], unsigned short Tb[24],
                                           double SVPosX[24],double SVPosY[24],double SVPosZ[24], float IonoCorr[24],                                          
                                           unsigned char SNR[24], unsigned char IonoSource[24], unsigned char SyncStatus[24],
                                           signed char FreqChannel[24] );

//*************************************************************************************
// MTK_Get_BD_Raw_Measurement  :  Get the raw measurement of Beidou satellites
//
// Note  :  
//          PR_Meas        : Pseodorange measurement          ( Unit : meter  )
//          DO_Meas        : Doppler measurment               ( Unit : Hz     )
//          CP_Meas        : Carrier phase measurement        ( Unit : cycle  )
//          CPMeasOK       : Carrier phase measurement value is half wave cycle locked or not. 
//                             0      --->  This carrier phase measurement of the SV is unlocked.
//                             1      --->  This carrier phase measurement of the SV is carrier locked.
//                             2      --->  This carrier phase measurement of the SV is half wave cycle locked.
//          CycleSlipCount : Incremented every time there is a cycle slip on this satellite  ( Range : 0-999 )
//          IOD            : IODE for Beidou                  ( Range : 0-31  )  ** If there are no IODE, the value will show '999' **
//          SVPosX         : Satellite ECEF positions (X)     ( Unit : meter  )
//          SVPosY         : Satellite ECEF positions (Y)     ( Unit : meter  )
//          SVPosZ         : Satellite ECEF positions (Z)     ( Unit : meter  )
//          IonoCorr       : Ionosphere Correction value      ( Unit : meter  )
//          SNR            : C/N0 of satellite                ( Unit : dB-Hz  )
//          IonoSource     : Ionosphere source
//                             0      --->  None
//                             1      --->  Broadcast
//                             2      --->  SBAS
//          SyncStatus     : GNSS data sync status
//                             0      --->  None
//                             1      --->  Bit sync
//                             2      --->  Subframe sync
//                             3      --->  Exact sync (Measurement is usable)
// Example:
//          unsigned char i;
//          double PR_Meas[30],DO_Meas[30],CP_Meas[30],reserved1[30];
//          unsigned char CP_Meas_OK[30];
//          unsigned short CycleSlipCount[30], IOD[30];
//          double SVPosX[30],SVPosY[30],SVPosZ[30];
//          float IonoCorr[30];
//          unsigned char SNR[30], IonoSource[30], SyncStatus[30];
//          MTK_Get_BD_Raw_Measurement(PR_Meas,DO_Meas,CP_Meas,reserved1,CP_Meas_OK,CycleSlipCount, IOD,SVPosX,SVPosY,SVPosZ,IonoCorr,SNR,IonoSource,SyncStatus);
//          
//          for (i=0;i<30;i++)
//          {
//             if (SNR[i]>0)
//             {
//                MTK_UART_OutputData("SDK:BD SV=%d PR_Meas = %.2f DO_Meas = %.1f CP_Meas = %.3f CP_Meas_OK = %d CycleSlipCount = %d IOD = %d ",
//                                            (i+1),PR_Meas[i],DO_Meas[i],CP_Meas[i],CP_Meas_OK[i],CycleSlipCount[i],IOD[i]);
//                MTK_UART_OutputData("SDK:BD SVPosX = %.2f SVPosY = %.2f SVPosZ = %.2f IonoCorr = %f SNR = %d IonoSource = %d SyncStatus = %d",
//                                            SVPosX[i],SVPosY[i],SVPosZ[i],IonoCorr[i],SNR[i],IonoSource[i],SyncStatus[i]);
//             }
//          }
//
// =====> SDK:BD SV=8 PR_Meas = 38958463.36 DO_Meas = -1724.3 CP_Meas = 25991.114 CP_Meas_OK = 2 CycleSlipCount = 0 IOD = 1 
//        SDK:BD SVPosX = 0.00 SVPosY = 0.00 SVPosZ = 0.00 IonoCorr = 0.000000 SNR = 39 IonoSource = 0 SyncStatus = 3

void MTK_Get_BD_Raw_Measurement (double PR_Meas[30], double DO_Meas[30], double CP_Meas[30], double reserved1[30], unsigned char CP_Meas_OK[30],
                                           unsigned short CycleSlipCount[30], unsigned short IOD[30],
                                           double SVPosX[30],double SVPosY[30],double SVPosZ[30], float IonoCorr[30],                                          
                                           unsigned char SNR[30], unsigned char IonoSource[30], unsigned char SyncStatus[30] );

//*************************************************************************************
// MTK_Get_GAL_Raw_Measurement  :  Get the raw measurement of Galileo satellites
//
// Note  :  
//          PR_Meas        : Pseodorange measurement          ( Unit : meter  )
//          DO_Meas        : Doppler measurment               ( Unit : Hz     )
//          CP_Meas        : Carrier phase measurement        ( Unit : cycle  )
//          CPMeasOK       : Carrier phase measurement value is half wave cycle locked or not. 
//                             0      --->  This carrier phase measurement of the SV is unlocked.
//                             1      --->  This carrier phase measurement of the SV is carrier locked.
//                             2      --->  This carrier phase measurement of the SV is half wave cycle locked.
//          CycleSlipCount : Incremented every time there is a cycle slip on this satellite  ( Range : 0-999 )
//          IOD            : IODE for Galileo                 ( Range : 0-31  )  ** If there are no IODE, the value will show '999' **
//          SVPosX         : Satellite ECEF positions (X)     ( Unit : meter  )
//          SVPosY         : Satellite ECEF positions (Y)     ( Unit : meter  )
//          SVPosZ         : Satellite ECEF positions (Z)     ( Unit : meter  )
//          IonoCorr       : Ionosphere Correction value      ( Unit : meter  )
//          SNR            : C/N0 of satellite                ( Unit : dB-Hz  )
//          IonoSource     : Ionosphere source
//                             0      --->  None
//                             1      --->  Broadcast
//                             2      --->  SBAS
//          SyncStatus     : GNSS data sync status
//                             0      --->  None
//                             1      --->  Bit sync
//                             2      --->  Subframe sync
//                             3      --->  Exact sync (Measurement is usable)
// Example:
//          unsigned char i;
//          double PR_Meas[30],DO_Meas[30],CP_Meas[30],reserved1[30];
//          unsigned char CP_Meas_OK[30];
//          unsigned short CycleSlipCount[30], IOD[30];
//          double SVPosX[30],SVPosY[30],SVPosZ[30];
//          float IonoCorr[30];
//          unsigned char SNR[30], IonoSource[30], SyncStatus[30];
//          MTK_Get_GAL_Raw_Measurement(PR_Meas,DO_Meas,CP_Meas,reserved1,CP_Meas_OK,CycleSlipCount, IOD,SVPosX,SVPosY,SVPosZ,IonoCorr,SNR,IonoSource,SyncStatus);
//          
//          for (i=0;i<30;i++)
//          {
//             if (SNR[i]>0)
//             {
//                MTK_UART_OutputData("SDK:GAL SV=%d PR_Meas = %.2f DO_Meas = %.1f CP_Meas = %.3f CP_Meas_OK = %d CycleSlipCount = %d IOD = %d ",
//                                             (i+1),PR_Meas[i],DO_Meas[i],CP_Meas[i],CP_Meas_OK[i],CycleSlipCount[i],IOD[i]);
//                MTK_UART_OutputData("SDK:GAL SVPosX = %.2f SVPosY = %.2f SVPosZ = %.2f IonoCorr = %f SNR = %d IonoSource = %d SyncStatus = %d",
//                                             SVPosX[i],SVPosY[i],SVPosZ[i],IonoCorr[i],SNR[i],IonoSource[i],SyncStatus[i]);
//             }
//          }
//
// =====> SDK:BD SV=8 PR_Meas = 38958463.36 DO_Meas = -1724.3 CP_Meas = 25991.114 CP_Meas_OK = 2 CycleSlipCount = 0 IOD = 1 
//        SDK:BD SVPosX = 0.00 SVPosY = 0.00 SVPosZ = 0.00 IonoCorr = 0.000000 SNR = 39 IonoSource = 0 SyncStatus = 3

void MTK_Get_GAL_Raw_Measurement (double PR_Meas[30], double DO_Meas[30], double CP_Meas[30], double reserved1[30], unsigned char CP_Meas_OK[30],
                                           unsigned short CycleSlipCount[30], unsigned short IOD[30],
                                           double SVPosX[30],double SVPosY[30],double SVPosZ[30], float IonoCorr[30],                                          
                                           unsigned char SNR[30], unsigned char IonoSource[30], unsigned char SyncStatus[30] );

//*************************************************************************************
// MTK_Get_QZSS_Raw_Measurement  :  Get the raw measurement of QZSS satellites
//
// Note  :  
//          PR_Meas        : Pseodorange measurement          ( Unit : meter  )
//          DO_Meas        : Doppler measurment               ( Unit : Hz     )
//          CP_Meas        : Carrier phase measurement        ( Unit : cycle  )
//          CPMeasOK       : Carrier phase measurement value is half wave cycle locked or not. 
//                             0      --->  This carrier phase measurement of the SV is unlocked.
//                             1      --->  This carrier phase measurement of the SV is carrier locked.
//                             2      --->  This carrier phase measurement of the SV is half wave cycle locked.
//          CycleSlipCount : Incremented every time there is a cycle slip on this satellite  ( Range : 0-999 )
//          IOD            : IODE for Galileo                 ( Range : 0-31  )  ** If there are no IODE, the value will show '999' **
//          SVPosX         : Satellite ECEF positions (X)     ( Unit : meter  )
//          SVPosY         : Satellite ECEF positions (Y)     ( Unit : meter  )
//          SVPosZ         : Satellite ECEF positions (Z)     ( Unit : meter  )
//          IonoCorr       : Ionosphere Correction value      ( Unit : meter  )
//          SNR            : C/N0 of satellite                ( Unit : dB-Hz  )
//          IonoSource     : Ionosphere source
//                             0      --->  None
//                             1      --->  Broadcast
//                             2      --->  SBAS
//          SyncStatus     : GNSS data sync status
//                             0      --->  None
//                             1      --->  Bit sync
//                             2      --->  Subframe sync
//                             3      --->  Exact sync (Measurement is usable)
// Example:
//          unsigned char i;
//          double PR_Meas[5],DO_Meas[5],CP_Meas[5],reserved1[5];
//          unsigned char CP_Meas_OK[5];
//          unsigned short CycleSlipCount[5], IOD[5];
//          double SVPosX[5],SVPosY[5],SVPosZ[5];
//          float IonoCorr[5];
//          unsigned char SNR[5], IonoSource[5], SyncStatus[5];
//          MTK_Get_QZSS_Raw_Measurement(PR_Meas,DO_Meas,CP_Meas,reserved1,CP_Meas_OK,CycleSlipCount, IOD,SVPosX,SVPosY,SVPosZ,IonoCorr,SNR,IonoSource,SyncStatus);
//          
//          for (i=0;i<5;i++)
//          {
//             if (SNR[i]>0)
//             {
//                MTK_UART_OutputData("SDK:QZSS SV=%d PR_Meas = %.2f DO_Meas = %.1f CP_Meas = %.3f CP_Meas_OK = %d CycleSlipCount = %d IOD = %d ",
//                                             (i+1),PR_Meas[i],DO_Meas[i],CP_Meas[i],CP_Meas_OK[i],CycleSlipCount[i],IOD[i]);
//                MTK_UART_OutputData("SDK:QZSS SVPosX = %.2f SVPosY = %.2f SVPosZ = %.2f IonoCorr = %f SNR = %d IonoSource = %d SyncStatus = %d",
//                                             SVPosX[i],SVPosY[i],SVPosZ[i],IonoCorr[i],SNR[i],IonoSource[i],SyncStatus[i]);
//             }
//          }
//
// =====> SDK:QZSS SV=8 PR_Meas = 38958463.36 DO_Meas = -1724.3 CP_Meas = 25991.114 CP_Meas_OK = 2 CycleSlipCount = 0 IOD = 1 
//        SDK:QZSS SVPosX = 0.00 SVPosY = 0.00 SVPosZ = 0.00 IonoCorr = 0.000000 SNR = 39 IonoSource = 0 SyncStatus = 3

void MTK_Get_QZSS_Raw_Measurement (double PR_Meas[5], double DO_Meas[5], double CP_Meas[5], double reserved1[5], unsigned char CP_Meas_OK[5],
                                           unsigned short CycleSlipCount[5], unsigned short IOD[5],
                                           double SVPosX[5],double SVPosY[5],double SVPosZ[5], float IonoCorr[5],                                          
                                           unsigned char SNR[5], unsigned char IonoSource[5], unsigned char SyncStatus[5] );

//*************************************************************************************
// MTK_Get_Group_Message  :  Get the group message includes the receiver time information.
//
// Note  :  
//          ClockTime    : Local receiver time tick            ( Unit : millisecond )
//          TOW          : GPS TOW                             ( Unit : millisecond )
//          WeekNumber   : GPS week number                     ( Range : 0-9999 )
//          Clock_Status : Clock status 
//                             0      --->  No clock
//                             1      --->  RTC
//                             2      --->  Synced to GPS
//                             3      --->  From GPS fix
//          UTCOffset    : The difference between GPS and UTC  ( Unit : second  )
//          ClockBias    : Clock bias                          ( Unit : meter   )
//          ClockOffset  : The clock offset between GPS clock and GLONASS/Beidou clock  ( Unit : meter )
// 
// Return : 
//          TRUE  => The time information are valid.
//          FALSE => The time information are invalid.
//
// Example:
//          unsigned char ret;
//          unsigned int ClockTime, TOW;
//          short WeekNumber;
//          int Clock_Status, UTCOffset, ClockBias, ClockOffset;
// 
//          ret = MTK_Get_Group_Message (&ClockTime, &TOW, &WeekNumber, &Clock_Status,&UTCOffset, &ClockBias, &ClockOffset);
//          if(ret)
//          {
//             MTK_UART_OutputData ("SDK ClockTime = %d TOW = %d WeekNumber = %d Clock_Status = %d UTCOffset = %d ClockBias = %d ClockOffset = %d",
//                                       ClockTime, TOW, WeekNumber, Clock_Status, UTCOffset, ClockBias, ClockOffset);
//          }
//
// =====> SDK ClockTime = 39572 TOW = 370618001 WeekNumber = 1860 Clock_Status = 3 UTCOffset = 17 ClockBias = 31961 ClockOffset = -6

unsigned char MTK_Get_Group_Message (unsigned int *ClockTime, unsigned int *TOW, short *WeekNumber,
                                                 int *Clock_Status, int *UTCOffset, int *ClockBias, int *ClockOffset);

//*************************************************************************************
// MTK_Get_Raw_Measurement_Advance  :  Get advance raw measurement of GPS satellites
//
// Note  :                         
//          SVVelX         : Satellite ECEF velocity (X)                    ( Unit : meter  )
//          SVVelY         : Satellite ECEF velocity (Y)                    ( Unit : meter  )
//          SVVelZ         : Satellite ECEF velocity (Z)                    ( Unit : meter  )
//          AtmoCorr       : Ionosphere + Tropospheric Correction value     ( Unit : meter  )
//          ClockBias      : Satellite clock bias                           ( Unit : microsecond  )
//          ClockRate      : Satellite clock rate                           ( Unit : microsecond  )
//          MeasIndicator  : Measurement indicator
//                             0      --->  Not recommended of the use of the measurement
//                             1      --->  The measurement is good for use.
// Example:
//          unsigned char i;
//          float SVVelX[32],SVVelY[32],SVVelZ[32],AtmoCorr[32],ClockBias[32],ClockRate[32];
//          unsigned char MeasIndicator[32];
//          MTK_Get_Raw_Measurement_Advance(SVVelX,SVVelY,SVVelZ,AtmoCorr,ClockBias,ClockRate,MeasIndicator);
//
//          for (i=0;i<32;i++)
//          {
//             if (MeasIndicator[i]>0)
//             {
//                MTK_UART_OutputData("SDK:GPS SV=%d SVVelX = %.2f SVVelY = %.2f SVVelZ = %.2f AtmoCorr = %.2f ClockBias = %.2f ClockRate = %.2f MeasIndicator = %d",
//                                             (i+1), SVVelX[i], SVVelY[i], SVVelZ[i], AtmoCorr[i], ClockBias[i], ClockRate[i], MeasIndicator[i]);
//             }
//          }
//
// ======>  SDK:GPS SV=6 SVVelX = -1018.68 SVVelY = -160.23 SVVelZ = -2966.45 AtmoCorr = 3.71 ClockBias = 55.86 ClockRate = 0.00 MeasIndicator = 1

void MTK_Get_Raw_Measurement_Advance (float SVVelX[32],float SVVelY[32],float SVVelZ[32], float AtmoCorr[32], 
                                           float ClockBias[32], float ClockRate[32], unsigned char MeasIndicator[32] );

//*************************************************************************************
// MTK_Get_GLON_Raw_Measurement_Advance  :  Get advance raw measurement of GLONASS satellites
//
// Note  :                         
//          SVVelX         : Satellite ECEF velocity (X)                    ( Unit : meter  )
//          SVVelY         : Satellite ECEF velocity (Y)                    ( Unit : meter  )
//          SVVelZ         : Satellite ECEF velocity (Z)                    ( Unit : meter  )
//          AtmoCorr       : Ionosphere + Tropospheric Correction value     ( Unit : meter  )
//          ClockBias      : Satellite clock bias                           ( Unit : microsecond  )
//          ClockRate      : Satellite clock rate                           ( Unit : microsecond  )
//          MeasIndicator  : Measurement indicator
//                             0      --->  Not recommended of the use of the measurement
//                             1      --->  The measurement is good for use.
// Example:
//          unsigned char i;
//          float SVVelX[24],SVVelY[24],SVVelZ[24],AtmoCorr[24],ClockBias[24],ClockRate[24];
//          unsigned char MeasIndicator[24];
//          MTK_Get_GLON_Raw_Measurement_Advance(SVVelX,SVVelY,SVVelZ,AtmoCorr,ClockBias,ClockRate,MeasIndicator);
//
//          for (i=0;i<24;i++)
//          {
//             if (MeasIndicator[i]>0)
//             {
//                MTK_UART_OutputData("SDK:GLONASS SV=%d SVVelX = %.2f SVVelY = %.2f SVVelZ = %.2f AtmoCorr = %.2f ClockBias = %.2f ClockRate = %.2f MeasIndicator = %d",
//                                             (i+1), SVVelX[i], SVVelY[i], SVVelZ[i], AtmoCorr[i], ClockBias[i], ClockRate[i], MeasIndicator[i]);
//             }
//          }
//
// ======>  SDK:GLONASS SV=8 SVVelX = -2030.86 SVVelY = -2379.87 SVVelZ = -344.73 AtmoCorr = 7.10 ClockBias = -26.79 ClockRate = 0.00 MeasIndicator = 1

void MTK_Get_GLON_Raw_Measurement_Advance (float SVVelX[24],float SVVelY[24],float SVVelZ[24], float AtmoCorr[24], 
                                           float ClockBias[24], float ClockRate[24], unsigned char MeasIndicator[24] );

//*************************************************************************************
// MTK_Get_BD_Raw_Measurement_Advance  :  Get advance raw measurement of Beidou satellites
//
// Note  :                         
//          SVVelX         : Satellite ECEF velocity (X)                    ( Unit : meter  )
//          SVVelY         : Satellite ECEF velocity (Y)                    ( Unit : meter  )
//          SVVelZ         : Satellite ECEF velocity (Z)                    ( Unit : meter  )
//          AtmoCorr       : Ionosphere + Tropospheric Correction value     ( Unit : meter  )
//          ClockBias      : Satellite clock bias                           ( Unit : microsecond  )
//          ClockRate      : Satellite clock rate                           ( Unit : microsecond  )
//          MeasIndicator  : Measurement indicator
//                             0      --->  Not recommended of the use of the measurement
//                             1      --->  The measurement is good for use.
// Example:
//          unsigned char i;
//          float SVVelX[14],SVVelY[14],SVVelZ[14],AtmoCorr[14],ClockBias[14],ClockRate[14];
//          unsigned char MeasIndicator[14];
//          MTK_Get_BD_Raw_Measurement_Advance(SVVelX,SVVelY,SVVelZ,AtmoCorr,ClockBias,ClockRate,MeasIndicator);
//
//          for (i=0;i<14;i++)
//          {
//             if (MeasIndicator[i]>0)
//             {
//                MTK_UART_OutputData("SDK:BD SV=%d SVVelX = %.2f SVVelY = %.2f SVVelZ = %.2f AtmoCorr = %.2f ClockBias = %.2f ClockRate = %.2f MeasIndicator = %d",
//                                             (i+1), SVVelX[i], SVVelY[i], SVVelZ[i], AtmoCorr[i], ClockBias[i], ClockRate[i], MeasIndicator[i]);
//             }
//          }
//
// ======>  SDK:BD SV=2 SVVelX = -1.30 SVVelY = 1.01 SVVelZ = -18.44 AtmoCorr = 36.99 ClockBias = -121.84 ClockRate = 0.00 MeasIndicator = 1

void MTK_Get_BD_Raw_Measurement_Advance (float SVVelX[14],float SVVelY[14],float SVVelZ[14], float AtmoCorr[14], 
                                           float ClockBias[14], float ClockRate[14], unsigned char MeasIndicator[14] );


#ifdef __cplusplus
   }
#endif

#endif /* MTK_MEASUREMENT_H */

