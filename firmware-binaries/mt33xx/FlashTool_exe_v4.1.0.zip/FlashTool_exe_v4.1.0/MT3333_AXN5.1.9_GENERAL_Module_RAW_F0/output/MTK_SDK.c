/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_SDK_C
#define MTK_SDK_C

#ifdef __cplusplus
   extern "C" {
#endif

//#define DEMO_MTK_SDK
//#define DEMO_MTK_FLASH
//#define DEMO_MTK_UART
//#define DEMO_MTK_NMEA_MODIFY
//#define DEMO_GPS_INFO
//#define DEMO_GLONASS_INFO
//#define DEMO_NMEA_DISABLE
//#define DEMO_SBAS_INFO
//#define DEMO_NV_CAST
//#define DEMO_MTK_LOGGER
//#define DEMO_NA_BASE
//#define DEMO_NA_OUT_EPH
//#define DEMO_BAUDRATE
//#define DEMO_GIO_CONTROL_EXT_LNA
//#define DEMO_MTK_SENSOR_TASK

#include <stdio.h>    // declarations for input/output functions
#include <string.h>   // declarations and defintions for string processing functions
#include <stdlib.h>
#include "MTK_SDK.h"
#include "MTK_Flash.h"

#ifdef DEMO_NV_CAST
#include "MTK_NVRam.h"
#endif
#ifdef DEMO_MTK_LOGGER
#include "MTK_Logger.h"
#endif
#if defined(DEMO_NA_BASE) || defined(DEMO_NA_OUT_EPH)
#include "MTK_NA_Base.h"
#endif

#ifdef DEMO_GIO_CONTROL_EXT_LNA
#include "MTK_IOPin.h"
#endif

#ifdef DEMO_MTK_FLASH
#define ADDR_DATA_OFFSET   0
#define REGION_SIZE        32768
#define BUFFER_SIZE        512
#define DATA_SIZE          8
#endif

//=============================================================================
// Type Definition
//=============================================================================
#ifdef DEMO_NV_CAST
typedef struct NV_DataBase
{
    signed char ElevMask; 
    unsigned int Count;    
} s_NV_DataBase;
#endif

//=============================================================================
// Functions Prototype
//=============================================================================
#ifdef DEMO_MTK_SDK
void DEMO_SDK_Timer(void);
void DEMO_SDK_MainLoop(void);
int DEMO_SDK_RecvNmea(const char *pInBuff);
#endif

#ifdef DEMO_MTK_FLASH
void DEMO_SDK_Flash(void);
void AppendData (char Data[DATA_SIZE]);
void GetCurrData (char Data[DATA_SIZE]);
#endif

#ifdef DEMO_MTK_UART
int DEMO_SDK_Echo(const char *pInBuff, unsigned length);
#endif

#ifdef DEMO_MTK_NMEA_MODIFY
void DEMO_SDK_Nmea_Set_Enable(void);
int DEMO_SDK_Modify_NMEA(unsigned char fgNmeaType, char *NmeaBuf );
#endif

#ifdef DEMO_GPS_INFO
void DEMO_GPS_Info(void);
#endif

#ifdef DEMO_GLONASS_INFO
void DEMO_GLONASS_Info(void);
#endif

#ifdef DEMO_SBAS_INFO
void DEMO_SBAS_Info(void);
#endif

#ifdef DEMO_NV_CAST
void DEMO_NVRAM_CAST(void);
void DEMO_NV_DB_Init(void);
#endif

#ifdef DEMO_MTK_LOGGER
void MTK_LOGGER_INIT(void);
void DEMO_SDK_Logger(void);
#endif

#ifdef DEMO_NA_BASE
void DEMO_NA_Base(void);
#endif
#ifdef DEMO_NA_OUT_EPH
void DEMO_NA_Out_EPH(void);
#endif
#ifdef DEMO_BAUDRATE
int Demo_Baudrate_Receive_Nmea(const char *pInBuff, unsigned length);
#endif

#ifdef DEMO_MTK_SENSOR_TASK
unsigned char DEMO_DR_DATA_PROC(void);
#endif

//------------------------------------------------
//  Add Global Variable Here
#ifdef DEMO_MTK_SDK
    unsigned long u4TimerCnt = 0;
#endif

#ifdef DEMO_MTK_FLASH
unsigned gFixEventCount;
unsigned gDataPtr;
char     gCopyBuffer[BUFFER_SIZE];
#endif

#ifdef DEMO_NV_CAST
s_NV_DataBase gDB;
unsigned int gCnt;
#endif

#ifdef DEMO_GIO_CONTROL_EXT_LNA
#define GIO3               3
#define DIR_OUTPUT         0
#define GIO_HIGH           1
#define LNA_ENABLE_GIO     GIO3
#endif

#ifdef DEMO_MTK_SENSOR_TASK
unsigned int SensorTaskIteration = 0;
#endif


//****************************************************************************
// SDK_Hw_Init  :      The hardware initialization routine for SDK application.
//                     This callback will be invoked every hardware restart.

void SDK_Hw_Init (void)
{

#ifdef DEMO_GIO_CONTROL_EXT_LNA
    MTK_Config_GIO( LNA_ENABLE_GIO, DIR_OUTPUT, 0, 0 );
    MTK_Set_GIO( LNA_ENABLE_GIO, GIO_HIGH );
    MTK_Set_GIO_CONTROL_EXT_LNA( LNA_ENABLE_GIO, 1 );
#endif

}

//****************************************************************************
// SDK_Init  :      The initialization routine for SDK application.
//                  This callback will be invoked every restart.
//                  When "return TRUE;",  All SDK TASK work.
//                  When "return FALSE;", All SDK TASK have no function.                      
//                  Default: return TRUE.

int SDK_Init (int source)
{
    #ifdef DEMO_MTK_FLASH
    gFixEventCount = 1;
    gDataPtr = 0;
    #endif

    #ifdef DEMO_MTK_UART
    MTK_Set_NMEA_BaudRate(57600);
    #endif

    #ifdef DEMO_MTK_NMEA_MODIFY
    DEMO_SDK_Nmea_Set_Enable();
    #endif
 
    #ifdef DEMO_NMEA_DISABLE
    MTK_NMEA_Output_Disable();
    #endif
    
    #ifdef DEMO_NV_CAST
    memset(&gDB,NULL,sizeof(gDB));
    gCnt = 0;
    #endif
    
    #ifdef DEMO_MTK_LOGGER
    MTK_LOGGER_INIT();
    #endif

    #ifdef DEMO_NA_BASE
    DEMO_NA_Base();
    #endif

    return  TRUE;
}

//****************************************************************************
// SDK_TimerEvent  :  Sdk Timer functions Routine. Timer interval is 100ms

void SDK_TimerEvent(void)
{
    //------------------------------------------------
    // Add User TIMER TASK Here    

    #ifdef DEMO_MTK_SDK
    DEMO_SDK_Timer();
    #endif

    #ifdef DEMO_MTK_SENSOR_TASK
    DEMO_DR_DATA_PROC();    
    #endif
 
}

//****************************************************************************
// SDK_Main  :  Sdk Main functions Routine. 

void SDK_Main(void)
{
    //------------------------------------------------
    // Add User TASK Here

    #ifdef DEMO_MTK_SDK
    DEMO_SDK_MainLoop();  
    #endif

    #ifdef DEMO_MTK_FLASH  
    DEMO_SDK_Flash();
    #endif
   
    #ifdef DEMO_GPS_INFO
    DEMO_GPS_Info();
    #endif
    
    #ifdef DEMO_GLONASS_INFO
    DEMO_GLONASS_Info();
    #endif
    
    #ifdef DEMO_SBAS_INFO
    DEMO_SBAS_Info();
    #endif
    
    #ifdef DEMO_NV_CAST
    DEMO_NVRAM_CAST();
    #endif

    #ifdef DEMO_MTK_LOGGER
    DEMO_SDK_Logger();
    #endif

    #ifdef DEMO_NA_OUT_EPH
    DEMO_NA_Out_EPH();
    #endif

    #ifdef DEMO_MTK_SENSOR_TASK
    // Dead Reckoning Algorithm
    MTK_UART_OutputData("Running Dead Reckoning Algorithm.");   
    #endif

}

//****************************************************************************
// SDK_Receive_User_Nmea_Pkt  :  Receive User Defined NMEA Sentences function.
//                               pInBuff is the Received NMEA Sentences.
//                               length is the length of the sentence excluding
//                               the checksum
// Purpose:                      Parse received NMEA sentences.
//                               If Match User Defined Sentences, Return TRUE
//                               Else                           , Return FALSE    

int SDK_Receive_User_Nmea_Pkt(const char *pInBuff, unsigned length)
{
    //------------------------------------------------
    // Add User Defined NMEA Sentences Here

    #ifdef DEMO_MTK_SDK
    return (DEMO_SDK_RecvNmea(pInBuff));

    #elif  defined(DEMO_MTK_UART)
    return (DEMO_SDK_Echo(pInBuff, length));
    
    #elif defined( DEMO_BAUDRATE)
    return(Demo_Baudrate_Receive_Nmea(pInBuff,length));
    
    #else

    // Mismatch User Defined NMEA Sentences            
    return FALSE;
    #endif
}

//****************************************************************************
// SDK_Receive_User_DPort_Pkt   :  Receive User Defined NMEA Sentences function.
//                               pInBuff is the Received NMEA Sentences.
//                               length is the length of the sentence excluding
//                               the checksum
// Purpose:                      Parse received NMEA sentences.
//                               If Match User Defined Sentences, Return TRUE
//                               Else                           , Return FALSE    

int SDK_Receive_User_DPort_Pkt (const char *pInBuff, unsigned length)
{
    return 0;
}

//****************************************************************************
// SDK_Modify_NMEA : Modify Standard NMEA Sentenses function.
// Description :
//   fgNmeaType : Which NMEA sentense need to modified.
//   GPZDA_SET -> Set GPZDA sentense.
//   GPVTG_SET -> Set GPVTG sentense.
//   GPRMC_SET -> Set GPRMC sentense.
//   GPGSV_SET -> Set GPGSV sentense.
//   GPGSA_SET -> Set GPGSA sentense.
//   GPGLL_SET -> Set GPGLL sentense.
//   GPGGA_SET -> Set GPGGA sentense.
//   NmeaBuf    : NmeaBuf is the NMEA Sentenses.
// Return value : return how many bytes in New NMEA sentense.
//   If need to modify NMEA sentense, Return New NMEA buffer size
//   Else                           , Return 0
// Note: Remember using MTK_Nmea_Set_Enable() to enable the NMEA modification.
//       Please set a correct return value (see sample code), otherwise NMEA sentense will wrong.
                                    
int SDK_Modify_NMEA(unsigned char fgNmeaType, char *NmeaBuf )
{

    #ifdef DEMO_MTK_NMEA_MODIFY
    return (DEMO_SDK_Modify_NMEA(fgNmeaType, NmeaBuf));
    #else
    
    //------------------------------------------------
    // Add User Modified NMEA Sentences Here
    
    // No need to Modify NMEA Sentences            
    return FALSE;
    
    #endif

}

#ifdef DEMO_MTK_SDK

//****************************************************************************
// DEMO_SDK_Timer  :  Sdk Timer Demo Functions. 
// DEMO RESULT : 
// 60 Sec Issue Cold Start.  

void DEMO_SDK_Timer(void)
{
    if ( u4TimerCnt> 0)
    {
        if ( (u4TimerCnt % 600) == 0)  //  600 * 100msec = 60 sec
        {
            MTK_ColdStart();   //  Example: cold start TASK..
        }
    
        if ( (u4TimerCnt % 400) == 0 )  //  400 * 100msec = 40 sec
        {
            //  User defined TASK...   
        }
    }
   
    u4TimerCnt++;
}

//****************************************************************************
// DEMO_SDK_MainLoop  :  Sdk Main Loop Demo Functions. 
// DEMO RESULT : 
// Output The following Debug Message and NMEA Sentences:
// *** MTK GPS Receiver ***
// *** The Elevation Mask is 5 deg ***
// $PMTKSDK,1.00,00005,,A,,88,,,,,X*41

void DEMO_SDK_MainLoop(void)
{
    signed char ElevMask;

    //------------------------------------------------
    // Add User TASK Here
    MTK_UART_OutputData("*** MTK GPS Receiver ***");
    MTK_Get_Elev_Mask(&ElevMask);
    MTK_UART_OutputData("*** The Elevation Mask is %d deg ***", ElevMask);


    //------------------------------------------------
    // Add User Defined NMEA Sentence Here  
    MTK_NMEA_OutputData("PMTKSDK,1.00,%05d,%d,%d,%d,A,,88,,,,,X",
      ElevMask, MTK_Get_Avail_Stack(),
      MTK_UART_GetTxBufferFreeSpace(), MTK_UART_GetRxBufferFreeSpace());
}

//****************************************************************************
// DEMO_SDK_RecvNmea  :  Sdk NMEA Sentence Receiving Demo Functions. 
// DEMO RESULT : 
// (1) When HOST Issue "$PMTKSDK,1" , 
//     Then Receiver Output "$PMTKSDK,R,5*39".
// (2) When HOST Issue "PQUERY" , 
//     Then Receiver Output "$PHSK,999,888,777*1A".

int DEMO_SDK_RecvNmea(const char *pInBuff)
{
    signed char ElevMask;

    //------------------------------------------------
    // Check User Defined NMEA Sentence Here  

    //     *****     Example     *****
    //     User has defined 4 main NMEA Sentences.
    //     (1) $PMTKSDK
    //     (2) $PQUERY
    //     (3) $PMTKUSER
    //     (4) $PUSER
    if (strncmp(pInBuff, "$GNSSTEST", 9) == 0)
    {
        char command = *(pInBuff + 10);
        char cmd = *(pInBuff + 11);
        int GNSS_BitMask = atoi(&command);
        if (cmd >= '0' && cmd <= '9')
        {
            GNSS_BitMask = 10*GNSS_BitMask + atoi(&cmd);
        }
        //MTK_UART_OutputData("GNSSTEST receive: %d", cmd);
        if(0 == MTK_Set_GNSS_Mode(GNSS_BitMask))
        {
            MTK_UART_OutputData("GNSSTEST not support GNSSMASK: %d", GNSS_BitMask);
        }
        else
        {
            MTK_UART_OutputData("GNSSTEST GNSSMASK set ok: %d", GNSS_BitMask);
        }
        return TRUE; 
    }
    
    if (strncmp(pInBuff, "$GNSSQUERY", 10) == 0)
    {
       int GNSS_Mode = 0;
       MTK_Get_GNSS_Mode(&GNSS_Mode);
       MTK_UART_OutputData("Current GNSS_Mask:%d", GNSS_Mode);
    }
    
    
    if (strncmp(pInBuff, "$PMTKSDK", 8) == 0)  // Check User Defined Nmea Pkt Token 
    {
        //Example : $PMTKSDK,1 ===> Return Satellite Elevation-Mask
        if ( *(pInBuff + 9) == '1' )
        {
            MTK_Get_Elev_Mask(&ElevMask);
            MTK_NMEA_OutputData("PMTKSDK,R,%d", ElevMask); //Output Satellite Elevation-Mask Information
        }
        else if ( *(pInBuff + 9) == '2' )
        {
            //  User defined Action...    
        }
        //else if ( ... )
        //{
        //    //  User defined Action...    
        //}       
        else
        {
            // Input packet is invalid
            return FALSE;
        }
        
        // Input packet is valid
        return TRUE;       
    }
    else if (strncmp(pInBuff, "$PQUERY", 7) == 0)  // Check User Defined Nmea Pkt Token 
    {
        MTK_NMEA_OutputData("PHSK,999,888,777");  // Handshaking with the other Side
        return TRUE;
    }
    else if (strncmp(pInBuff, "$PMTKUSER", 9) == 0)  // Check User Defined Nmea Pkt Token 
    {
        //  User defined Action...
        return TRUE;
    }

    else if (strncmp(pInBuff, "$PUSER", 6) == 0)  // Check User Defined Nmea Pkt Token 
    {
        //  User defined Action...
        return TRUE;
    }
    //else if ( ... )
    //{
    //    //  User defined Action...   
    //    //  return TRUE; 
    //}   

    // Mismatch User Defined NMEA Sentences            
    return FALSE;
}
#endif /* DEMO_MTK_SDK */


#ifdef DEMO_MTK_FLASH

//****************************************************************************
// DEMO_SDK_Flash :  Sdk Flash Application Demo Functions. 
// DEMO RESULT :
// Application 1: 
// STEP 1:  MTK_FlashOpen().
// STEP 2:  Erase Data Sector.
// STEP 3:  Write a Updated data to Data Sector.
// STEP 4:  Read data from Data Sector.
// STEP 5:  Compare with the Original data which desire to write into flash.
// STEP 6:  If write data fail, then Output ERROR message.
// STEP 7:  If write data ok, then Output GOOD message.
// STEP 8:  MTK_FlashClose()

void DEMO_SDK_Flash(void)
{
    char data[DATA_SIZE], verify[DATA_SIZE];

    gFixEventCount++;
    if (!(gFixEventCount & 7))
    {
        // get data
        memset(data, 0, DATA_SIZE);
        *(unsigned*)&data[0] = gFixEventCount;
        *(unsigned*)&data[4] = gFixEventCount + 1;
        // write data
        AppendData(data);
        // read back
        GetCurrData(verify);
        // compare
        if (memcmp(data, verify, DATA_SIZE))
        {
            MTK_UART_OutputData("ERROR_%d", gFixEventCount);
        }
        else
        {
            MTK_UART_OutputData("GOOD_%d", gFixEventCount);
        }
    }
}

void AppendData (char Data[DATA_SIZE])
{
    unsigned  base;

    gDataPtr += DATA_SIZE;
    if (gDataPtr >= REGION_SIZE)
    {
        gDataPtr = 0;
    }

    MTK_FlashOpen();
    MTK_FlashTotalErase();
    MTK_FlashWrite(ADDR_DATA_OFFSET + gDataPtr, DATA_SIZE, Data);
    MTK_FlashClose();
}

void GetCurrData (char Data[DATA_SIZE])
{
   MTK_FlashOpen();
   MTK_FlashRead(ADDR_DATA_OFFSET + gDataPtr, DATA_SIZE, Data);
   MTK_FlashClose();
}
#endif /* DEMO_MTK_FLASH */


#ifdef  DEMO_MTK_UART

//****************************************************************************
// DEMO_SDK_Echo  :  echo the NMEA input to NMEA output
int DEMO_SDK_Echo(const char *pInBuff, unsigned length)
{
    MTK_UART_OutputRawData(pInBuff, length);
    return  TRUE;
}

#endif /* DEMO_MTK_UART */

#ifdef DEMO_MTK_NMEA_MODIFY
//****************************************************************************
// DEMO_SDK_Nmea_Set_Enable  :  Nmea Modification Setting Functions. 
// DEMO RESULT : 
// GPGLL, GPGGA, GPRMC, GPGSV, GPVTG, GPZDA and GPGSA sentense can be modified in SDK_Modify_NMEA().

void DEMO_SDK_Nmea_Set_Enable(void)
{
    unsigned char fgNmeaModifyBit;
    fgNmeaModifyBit = 0;
    fgNmeaModifyBit = fgNmeaModifyBit | GPGLL_SET | GPGGA_SET | GPRMC_SET | GPGSV_SET | GPVTG_SET | GPZDA_SET | GPGSA_SET;

    MTK_Nmea_Set_Enable(fgNmeaModifyBit);
}

//****************************************************************************
// DEMO_SDK_Modify_NMEA  :  Sdk NMEA Sentence Modification Demo Functions. 
// DEMO RESULT : 
// STEP 1:  Add a User Modify NMEA code in correct fgNmeaType. 
//          ex. if ( ( fgNmeaType & GPGLL_SET ) == GPGLL_SET ) ===> modify GPGLL sentense 
// STEP 2:  Return how many bytes in New NMEA sentense.
//          ex. return (strlen(buf)); ===> return new NMEA length            
//          After return a correct NMEA length, this function will automatically output the modified
//          NMEA sentense. Therefore, user no need to add MTK_XXX_OutputData() function here.
//          Note : If added MTK_XXX_OutputData() function here, then NMEA buffer will be corrupted!!      
//
// After Modification:
// $GPGLL,999.88,N,12.56789,E,141630.758,A,A*6D
//        ^^^^^^   ^^^^^^^^              ^ ^
// $GPGSV,3,1,12,09,79,065,46,21,61,260,45,18,12,080,49,26,25,045,40*76
//                                            ^^ ^^^ ^^           ^^
// $GPGSV,3,2,12,12,30,031,37,29,18,052,38,22,15,313,40,10,11,114,40*73
//                  ^^ ^^^
// $GPGSV,3,3,12,24,10,159,28,14,09,264,32,30,05,182,,06,03,205,*78
// $GPGGA,141630.758,2446.3742,N,12101.3681,E,1,10,9999.990,152.8,M,15.1,M,,*64
//                                                 ^^^^^^^^
// $GPRMC,141630.758,A,9946.3742,N,66601.3681,E,0.10,0.00,100107,,,A*68
//                     ^^          ^^^

int DEMO_SDK_Modify_NMEA(unsigned char fgNmeaType, char *NmeaBuf )
{
    short i; 
    char SentenceCnt =0;
    char buf[300], BufTemp[20];
    short ItemLen[40],Idx[40], ItemSum;
    double dTemp;
    char  *BufPtr;  
    short SVid,SNR,Elev,Azim;
      
    memcpy (buf, NmeaBuf, strlen(NmeaBuf));
    buf[strlen(NmeaBuf)] = 0;

    // GPGLL
    if ( ( fgNmeaType & GPGLL_SET ) == GPGLL_SET )
    {
        memset(ItemLen, NULL, sizeof(ItemLen));
        memset(Idx, NULL, sizeof(Idx));
        ItemSum =0;
        for ( i = 0;  i < strlen(NmeaBuf); i++)
        {
            if ( buf[i] == ',')
            {
                ItemLen[SentenceCnt] = i - ItemSum - SentenceCnt;
                ItemSum  += ItemLen[SentenceCnt];           
                SentenceCnt++;      
                Idx[SentenceCnt] = i + 1;              
            }      
        }

        ItemLen[SentenceCnt] = strlen(NmeaBuf) - Idx[SentenceCnt];

        ////////////////////////////////////////////////////
        //
        // Modify a new NMEA sentense. ( > 1 item )
        //
        ////////////////////////////////////////////////////
        // Use NMEA 3.01 spec type behaviour
        // Item 0 : GPGLL
        // Item 1 : Latitude
        // Item 2 : N/S
        // Item 3 : Lontitude
        // Item 4 : E/W
        // Item 5 : UTC of position
        // Item 6 : Status (A/V)
        // Item 7 : Mode indicator
                
        // Ex. GPGLL,8960.0000,N,00000.0000,E,235946.007,V,N
        //           ^           ----------   ^
        //           |           ItemLen=10   |
        //           |                        |
        //          Idx[1]=6                Idx[5]=31 
        //   Idx[0] = 0  ItemLen[0] = 5 
        //   Idx[1] = 6  ItemLen[1] = 9 
        //   Idx[2] = 16 ItemLen[2] = 1 
        //   Idx[3] = 18 ItemLen[3] = 10 
        //   Idx[4] = 29 ItemLen[4] = 1 
        //   Idx[5] = 31 ItemLen[5] = 10 
        //   Idx[6] = 42 ItemLen[6] = 1 
        
        // Assume item 1, 3, 6, 7 is modified.  
        BufPtr = buf;
        ItemSum =0;
        for ( i = 0;  i <= SentenceCnt; i++)
        {
            // Modified Item : 1,3,6,7
            if ( i == 1) 
            {  
                // Item 1 : Latitude
                memcpy( BufTemp , "999.88", 6);
                BufTemp[6] = 0;
                memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                BufPtr += strlen(BufTemp);
            }
            else if ( i == 3)
            {
                // Item 3 : Lontitude
                memcpy( BufTemp , "12.56789", 8);
                BufTemp[8] = 0;
                memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                BufPtr += strlen(BufTemp);
            }
            else if ( i == 6)
            {
                // Item 6 : Status (A/V)
                memset( BufPtr, 'A',1); // New Item 
                BufPtr ++;     
            }
            else if ( i == 7)
            {
                // Item 7 : Mode indicator
                memset( BufPtr, 'A',1); // New Item 
                BufPtr ++;     
            }        
            // Unchangeable Item : 0,2,4,5
            else
            {
                memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item using original source buffer : NmeaBuf
                BufPtr += ItemLen[i];
            }

            if ( i != SentenceCnt )
            {
                memset( BufPtr, ',',1); 
                BufPtr ++;
            }     
        }
        buf[BufPtr- buf] = 0;     
        memcpy (NmeaBuf, buf, strlen(buf));
        
        return (strlen(buf));   // Original length has change
    }
    // GPGSV
    else if ( ( fgNmeaType & GPGSV_SET ) == GPGSV_SET )
    {
        memset(ItemLen, NULL, sizeof(ItemLen));
        memset(Idx, NULL, sizeof(Idx));
        ItemSum =0;
        for ( i = 0;  i < strlen(NmeaBuf); i++)
        {
            if ( buf[i] == ',')
            {
                ItemLen[SentenceCnt] = i - ItemSum - SentenceCnt;
                ItemSum  += ItemLen[SentenceCnt];        
                SentenceCnt++;      
                Idx[SentenceCnt] = i + 1;
            }      
        }

        ItemLen[SentenceCnt] = strlen(NmeaBuf) - Idx[SentenceCnt];

        ////////////////////////////////////////////////////
        //
        // Modify a new NMEA sentense. ( > 1 item )
        //
        ////////////////////////////////////////////////////                
              
        // Assume SV 18,26,12 is modified.  
        BufPtr = buf;
        ItemSum =0;
        for ( i = 0;  i <= SentenceCnt; i++)
        {
            // Modified Item : 1,3,6,7
            if ( (i > 0) && ((i % 4)==0))  //SDid Item
            {            
                memcpy( BufTemp, NmeaBuf + Idx[i],ItemLen[i]); // get data from original source buffer : NmeaBuf
                BufTemp[ItemLen[i]] = 0;       
                SVid = atoi(BufTemp);
                
                if ( SVid == 18 ) // change Elev, Azim, SNR
                {
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item (SVid) using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];
                    i++;
                    
                    memset( BufPtr, ',',1); 
                    BufPtr ++;
           
                    // Get Elev value
                    memcpy( BufTemp, NmeaBuf + Idx[i],ItemLen[i]);
                    BufTemp[ItemLen[i]] = 0;
                    Elev = atoi(BufTemp);
                    
                    // Set Elev value                
                    Elev = 12;
                    sprintf(BufTemp,"%02d",Elev);
                    BufTemp[2] = 0;            
                    memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                    BufPtr += strlen(BufTemp);
                    i++;
                    
                    memset( BufPtr, ',',1); 
                    BufPtr ++;                

                    // Get Azim value                                                                  
                    memcpy( BufTemp, NmeaBuf + Idx[i],ItemLen[i]);
                    BufTemp[ItemLen[i]] = 0;
                    Azim = atoi(BufTemp);

                    // Set Azim value                                                                                  
                    Azim = 80;
                    sprintf(BufTemp,"%03d",Azim);
                    BufTemp[3] = 0;
                    memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                    BufPtr += strlen(BufTemp);
                    i++;
                    
                    memset( BufPtr, ',',1); 
                    BufPtr ++;                

                    // Get SNR value                                                                                                 
                    memcpy( BufTemp, NmeaBuf + Idx[i],ItemLen[i]);
                    BufTemp[ItemLen[i]] = 0;
                    SNR = atoi(BufTemp);
                
                    // Set SNR value                                                                                                 
                    if ( SNR < 49)
                    {
                        SNR = 49;
                    }                    
                    sprintf(BufTemp,"%02d",SNR);
                    BufTemp[2] = 0;
                    memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                    BufPtr += strlen(BufTemp);
                
                    if ( i != SentenceCnt )
                    {
                        memset( BufPtr, ',',1); 
                        BufPtr ++;                
                    }                                         
                }
                else if ( SVid == 26) // change SNR
                {
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item (SVid) using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];
                    i++;

                    memset( BufPtr, ',',1); 
                    BufPtr ++;
                
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item (Elev) using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];  
                    i++;                       

                    memset( BufPtr, ',',1); 
                    BufPtr ++;                
                
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item (Azim) using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];  
                    i++;
                    
                    memset( BufPtr, ',',1); 
                    BufPtr ++;                

                    // Set SNR value                                                                                                                                                           
                    SNR = 40;
                    sprintf(BufTemp,"%02d",SNR);
                    BufTemp[2] = 0;
                    memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                    BufPtr += strlen(BufTemp);
                
                    if ( i != SentenceCnt )
                    {
                        memset( BufPtr, ',',1); 
                        BufPtr ++;                
                    }                                    
                }        
                else if ( SVid == 12 ) // change Elev, Azim
                {
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item (SVid) using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];
                    i++;

                    memset( BufPtr, ',',1); 
                    BufPtr ++;

                    // Set Elev value                                            
                    Elev = 30;
                    sprintf(BufTemp,"%02d",Elev);
                    BufTemp[2] = 0;
                    memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                    BufPtr += strlen(BufTemp);
                    i++; 
                
                    memset( BufPtr, ',',1); 
                    BufPtr ++;                

                    // Set Azim value                                                
                    Azim = 31;
                    sprintf(BufTemp,"%03d",Azim);
                    BufTemp[3] = 0;
                    memcpy( BufPtr, BufTemp,strlen(BufTemp)); // New Item
                    BufPtr += strlen(BufTemp);
                    i++;

                    memset( BufPtr, ',',1); 
                    BufPtr ++;                
                                                    
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item (SNR) using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];  
 
                    if ( i != SentenceCnt )
                    {
                        memset( BufPtr, ',',1); 
                        BufPtr ++;                
                    }                                
                }
                else
                {
                    memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item using original source buffer : NmeaBuf
                    BufPtr += ItemLen[i];
                    if ( i != SentenceCnt )
                    {
                        memset( BufPtr, ',',1); 
                        BufPtr ++;
                    }     
                }
            }        
            // Unchangeable Item
            else
            {
                memcpy( BufPtr, NmeaBuf + Idx[i],ItemLen[i]); // Unchangeable Item using original source buffer : NmeaBuf
                BufPtr += ItemLen[i];
                if ( i != SentenceCnt )
                {
                    memset( BufPtr, ',',1); 
                    BufPtr ++;
                }     
            }
        }

        buf[BufPtr- buf] = 0;    
        memcpy (NmeaBuf, buf, strlen(buf));

        return (strlen(buf));   // Original length has change    
    }
    // GPGGA   
    else if ( ( fgNmeaType & GPGGA_SET ) == GPGGA_SET )
    {
        memset(ItemLen, NULL, sizeof(ItemLen));
        memset(Idx, NULL, sizeof(Idx));
        ItemSum =0;
        for ( i = 0;  i < strlen(NmeaBuf); i++)
        {
            if ( buf[i] == ',')
            {
                ItemLen[SentenceCnt] = i - ItemSum - SentenceCnt;
                ItemSum  += ItemLen[SentenceCnt];        
                SentenceCnt++;      
                Idx[SentenceCnt] = i + 1;     
            }
        }

        ItemLen[SentenceCnt] = strlen(NmeaBuf) - Idx[SentenceCnt];

        ////////////////////////////////////////////////////
        //
        // Only modify one item value.
        //
        ////////////////////////////////////////////////////
     
        // Get HDOP
        memcpy( BufTemp, buf + Idx[8],ItemLen[8]); 
        BufTemp[ItemLen[8]] = 0;
        dTemp = atof(BufTemp);
    
        if ( dTemp <= 1.5 )
        {
            dTemp = 9999.99;
            sprintf(BufTemp,"%4.3f,",dTemp);            
            BufTemp[9] = 0;
            memcpy(buf + Idx[8], BufTemp, strlen(BufTemp));                  
            memcpy(buf + Idx[8]+ strlen(BufTemp), NmeaBuf + Idx[9], strlen(NmeaBuf) - Idx[9] );  
            buf[ strlen(NmeaBuf) - ItemLen[8] + strlen(BufTemp) - 1] = 0; //BufTemp including ',' 
            // Modify Original NMEA Sentense
            memcpy (NmeaBuf, buf, strlen(buf));      
            return (strlen(buf));  // Original length has change        
        }       
    }
    // GPRMC
    else if ( ( fgNmeaType & GPRMC_SET ) == GPRMC_SET )
    {
        memset(ItemLen, NULL, sizeof(ItemLen));
        memset(Idx, NULL, sizeof(Idx));
        ItemSum =0;
        for ( i = 0;  i < strlen(NmeaBuf); i++)
        {
            if ( buf[i] == ',')
            {
                ItemLen[SentenceCnt] = i - ItemSum - SentenceCnt;
                ItemSum  += ItemLen[SentenceCnt];        
                SentenceCnt++;        
                Idx[SentenceCnt] = i + 1;
            }
        }
    
        ItemLen[SentenceCnt] = strlen(NmeaBuf) - Idx[SentenceCnt];
  
        ////////////////////////////////////////////////////
        //
        // Only modify a certain fixed item value.
        // Must be make sure NMEA sentense lenght is fixed. 
        // Otherwise, it will has some problem. 
        //
        ////////////////////////////////////////////////////
        
        // Get Latitude Value
        memcpy( BufTemp, buf + Idx[3],ItemLen[3]); 
        BufTemp[ItemLen[3]] = 0;
        dTemp = atof(BufTemp);
        
        // Set Latitude Value
        buf[Idx[3]+0] = '9';
        buf[Idx[3]+1] = '9';

        // Get Lontitude Value                
        memcpy( BufTemp, buf + Idx[5],ItemLen[5]); 
        BufTemp[ItemLen[5]] = 0;
        dTemp = atof(BufTemp);

        // Set Lontitude Value            
        buf[Idx[5]+0] = '6';
        buf[Idx[5]+1] = '6';
        buf[Idx[5]+2] = '6';    
        
        memcpy (NmeaBuf, buf, strlen(NmeaBuf));
        return (strlen(NmeaBuf));   // Original length has no change
    }        
    
    // if no need to modify NMEA, then Return 0.
    return (0);    
}

#endif /* DEMO_MTK_NMEA_MODIFY */

#ifdef DEMO_GPS_INFO
//****************************************************************************
// DEMO_GPS_Info :  GPS information Demo Functions. 
// DEMO RESULT :
//******* SV 2 ********
//*** SNR = 35 Eph = 1 DGP_Status = 0***
//******* SV 4 ********
//*** SNR = 32 Eph = 1 DGP_Status = 0***
//******* SV 9 ********
//*** SNR = 30 Eph = 0 DGP_Status = 0***
//******* SV 10 ********
//*** SNR = 25 Eph = 0 DGP_Status = 0***
//******* SV 12 ********
//*** SNR = 30 Eph = 0 DGP_Status = 0***
//******* SV 17 ********
//*** SNR = 32 Eph = 0 DGP_Status = 0***
//******* SV 20 ********
//*** SNR = 30 Eph = 1 DGP_Status = 0***
//******* SV 27 ********
//*** SNR = 16 Eph = 0 DGP_Status = 0***
//******* SV 28 ********
//*** SNR = 31 Eph = 1 DGP_Status = 0***

void DEMO_GPS_Info(void)
{
    unsigned char SNR[32], SVid[32], Eph[32],Alm[32], DGP_Status[32];
    int iGPS= 0;
         
    MTK_Get_Sat_SNR(SNR);
    MTK_Get_Sat_SVid(SVid);   
    MTK_Get_Sat_Eph_Info(Eph);
    MTK_Get_Sat_Alm_Info(Alm);  
    MTK_Get_Sat_DGP_Status(DGP_Status);
   
    for (iGPS = 0; iGPS < 32 ; iGPS++)
    {
        if (SVid[iGPS] == TRUE)
        {
            MTK_UART_OutputData("******* SV %d ********",iGPS+1);
            MTK_UART_OutputData("*** SNR = %02d Eph = %d Alm = %d DGP_Status = %d***",SNR[iGPS],Eph[iGPS],Alm[iGPS],DGP_Status[iGPS]);
        }
    }
}
#endif /* DEMO_GPS_INFO */

#ifdef DEMO_GLONASS_INFO
//****************************************************************************
// DEMO_GLONASS_Info :  GLONASS information Demo Functions. 
// DEMO RESULT :
//******* GLONASS SV 9 ********
//*** SNR=33 Eph=1 Alm=1 Used=1 Health=1 ***
//******* GLONASS SV 10 ********
//*** SNR=29 Eph=1 Alm=1 Used=1 Health=1 ***
//******* GLONASS SV 11 ********
//*** SNR=27 Eph=1 Alm=1 Used=1 Health=1 ***
//******* GLONASS SV 20 ********
//*** SNR=29 Eph=1 Alm=1 Used=1 Health=1 ***
//******* GLONASS SV 21 ********
//*** SNR=34 Eph=1 Alm=1 Used=1 Health=1 ***
//******* GLONASS SV 22 ********
//*** SNR=31 Eph=1 Alm=1 Used=1 Health=1 ***

void DEMO_GLONASS_Info(void)
{
    unsigned short iGLON= 0;
    unsigned char SNR[24], SVid[24], Eph[24], Alm[24], Used[24];
    unsigned int Health= 0;

    MTK_Get_GLON_Sat_SNR(SNR);
    MTK_Get_GLON_Sat_SVid(SVid);  //visable
    MTK_Get_GLON_Sat_Eph_Info(Eph);
    MTK_Get_GLON_Sat_Alm_Info(Alm);  
    MTK_Get_GLON_Sat_Health(&Health);
    MTK_Fix_Get_GLON_Sats_Used(Used);
   
    for (iGLON = 0 ; iGLON < 24 ; iGLON++)
    {
        if (SVid[iGLON] == TRUE)
        {              
            MTK_UART_OutputData("******* GLONASS SV %d ********",iGLON+1);
            MTK_UART_OutputData("*** SNR=%02d Eph=%d Alm=%d Used=%d Health=%d ***",
               SNR[iGLON],
               Eph[iGLON],
               Alm[iGLON],
               Used[iGLON],
               (Health & (1<<iGLON))?1:0  );
        }
    }
}
#endif /* DEMO_GLONASS_INFO */

#ifdef DEMO_SBAS_INFO
void DEMO_SBAS_Info(void)
{
    unsigned char SVid[15];
    unsigned char SNR[15];
    signed short Azim[15];
    signed char Elev[15];
    int i, NumSbas = 0;
    NumSbas = MTK_Get_SBAS_Sat_Info(SVid, SNR, Azim, Elev); 
    for (i = 0; i < NumSbas ; i++)
    {
        MTK_UART_OutputData("SBAS SVid = %d SNR = %d Azim = %d Elev = %d", SVid[i], SNR[i], Azim[i], Elev[i]);
    }
}
#endif /* DEMO_SBAS_INFO */


#ifdef DEMO_NA_BASE
void DEMO_NA_Base(void)
{
  // If the current role is a client receiver,
  // switch to a reference station
  if (MTK_Query_NA_Role() == 0)
  {
    MTK_Set_NA_Role(1); // Set the receiver to be a reference station

    MTK_Set_NA_SCHD(0,1,4); // out ephemeris every 1 sec, 4 SVs for each output.
    MTK_Set_NA_SCHD(1,1,1); // out almanac every 1 sec, 1 SV for each output.
    MTK_Set_NA_SCHD(2,1,1); // out reference time every 1 sec
    MTK_Set_NA_SCHD(3,1,1); // out reference location every 1 sec
    MTK_Set_NA_SCHD(5,8,1); // out klobuchar model every 8 secs
    MTK_Set_NA_SCHD(6,8,1); // out UTC model every 8 secs
    MTK_Set_NA_SCHD(7,8,1); // out bad satellite list every 8 secs
  }
}
#endif


#ifdef DEMO_NA_OUT_EPH
void DEMO_NA_Out_EPH()
{
  MTK_Out_NA_Eph();
}
#endif


#ifdef __cplusplus
   }
#endif

#ifdef DEMO_NV_CAST
//****************************************************************************
// DEMO_NV_CAST :  Sdk NV ram Application Demo Functions. 
// DEMO RESULT :
// Application 1: 
// STEP 1:  Get Current Elevation Mask
// STEP 2:  Read Data in NVRam
// STEP 3:  Output current data and that in NV-RAM through UART
// STEP 4:  Update Count and add ElevMask by 1 every 10 secs
//
// NOTE: When there is a restart, there is a check of Count value in
//       DEMO_NV_DB_Init(). If Count value in data base is larger than 
//       2000 at system-restart, there is an initialization of data base.


void DEMO_NVRAM_CAST(void)
{
    
    s_NV_DataBase NV_DB;  // Local variable to get Data in NV-RAM
    signed char ElevMask;
    
    DEMO_NV_DB_Init();
    memset(&NV_DB,0,sizeof(NV_DB));
    MTK_Get_Elev_Mask(&ElevMask);
    gDB.ElevMask = ElevMask;  // gDB is a global variable
    // Get Data in NV ram
    MTK_Read_NVRam(0,sizeof(NV_DB),&NV_DB);
    // show current and previous data
    MTK_UART_OutputData("NV-ElevMask:%d[%d]",NV_DB.ElevMask,NV_DB.Count);
    MTK_UART_OutputData("   ElevMask:%d[%d]",gDB.ElevMask,gDB.Count);
    gCnt += 1;
    gDB.Count = gCnt;    
    // update information in NV ram every 10 seconds
    // every 10 seconds, add ElevMask by 1 and update Count
    if((gCnt % 10) == 0) 
    {
        NV_DB.ElevMask++;
        NV_DB.Count = gCnt;
        MTK_Write_NVRam(0,sizeof(NV_DB),&NV_DB);    
    }
}

void DEMO_NV_DB_Init(void)
{
    s_NV_DataBase NV_DB;  // Local variable to get Data in NV-RAM
    
    memset(&NV_DB,0,sizeof(NV_DB));
    // Get Data in NV ram
    MTK_Read_NVRam(0,sizeof(NV_DB),&NV_DB);	
    // First, Reset NVRAM data if the value of Count in the data base is 
    // larger than 20000. This check will be done only if there is a restart
    if( ( NV_DB.Count > 20000 ) && (gCnt == 0) )
    {
        NV_DB.Count = 0;
        NV_DB.ElevMask = 0;
        MTK_Write_NVRam(0,sizeof(NV_DB),&NV_DB);
    }
}


#endif /* DEMO_NV_CAST */

#ifdef DEMO_MTK_LOGGER
void MTK_LOGGER_INIT(void)
{
    // Use can reassign the serial flash size and type for own choice
    // MTK firmware already auto detect serial flash size from 1MB to 64MB
    // which is JEDEC 0x9F command compatible
    // firmware already auto detect, user may overwrite the size and option as below example
    unsigned long u4SFlashID;
 
    MTK_Logger_Read_ID(0x9F, &u4SFlashID);
 
    if (u4SFlashID == 0xC2201500)  // MXIC - MX25L1605
    {
       MTK_Logger_Set_SFlash_Size(0x200000);
       MTK_Logger_Set_SFlash_Option(SFLASH_PAGE_WRT);
    }
    else if (u4SFlashID == 0xBF254100)  // SST - SST25VF016B
    {
      MTK_Logger_Set_SFlash_Size(0x200000);
      MTK_Logger_Set_SFlash_Option(SFLASH_WORD_AAI_WRT | SFLASH_SST_TYPE);
    }
    else
    {
     // handle other kind of serial flash as user desired
    }
}

void DEMO_SDK_Logger(void)
{
   unsigned short u2LoggerStatus;
   unsigned int u4BySecond;

    MTK_Logger_Query_Status(&u2LoggerStatus);
    
    MTK_Logger_Query_SEC(&u4BySecond);
    if (u4BySecond != 20)
    {
      MTK_Logger_Setup_Log_Ctl(3, 20);   // Set up recording by 2 sec
      MTK_Logger_Setup_Log_Ctl(4, 1000); // Set up recording by 100M
      MTK_Logger_Setup_Log_Ctl(5, 1500); // Set up recording by 150KM/Hr
    }

    if (u2LoggerStatus & MTK_LOGGER_NEED_ERASE)
    {
        MTK_Logger_Erase();
    }
    else if (u2LoggerStatus & MTK_LOGGER_FULL)
    {
        MTK_Logger_Stop();
    }
    else if (!(u2LoggerStatus & MTK_LOGGER_START))
    {
        MTK_Logger_Start();
    }
}
#endif  /*  DEMO_MTK_LOGGER  */

#ifdef DEMO_BAUDRATE
int Demo_Baudrate_Receive_Nmea(const char *pInBuff, unsigned length)
{
    if (strncmp(pInBuff, "$HLXBR", 6) == 0)  // Check User Defined Nmea Pkt Token
    {
       if(*(pInBuff+7) == '0')
       {
           MTK_Set_BaudRate_Base(0);
           return 1;
       }
       else if(*(pInBuff+7) == '1')
       {
           MTK_Set_BaudRate_Base(1);
           return 1;
       }
       else if(*(pInBuff+7) == '2')
       {
           MTK_Set_BaudRate_Base(2);
           return 1;
       }
       else if(*(pInBuff+7) == '3')
       {
           MTK_Set_BaudRate_Base(3);
           return 1;
       }
       else
       {
           return 0;
       }
    }
    return 0;
}
#endif

#ifdef DEMO_MTK_SENSOR_TASK
unsigned char DEMO_DR_DATA_PROC(void)
{
   
   // Collect Sensor Data
   SensorTaskIteration++;     

   return TRUE;

}
#endif


#endif /* MTK_SDK_C */
