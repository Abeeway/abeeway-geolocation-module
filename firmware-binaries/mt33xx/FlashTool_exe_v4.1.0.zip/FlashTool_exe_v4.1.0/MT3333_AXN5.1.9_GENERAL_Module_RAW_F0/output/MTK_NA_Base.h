/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2007]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_NA_BASE_H
#define MTK_NA_BASE_H

#ifdef __cplusplus
   extern "C" {
#endif

#include "MTK_SDK.h"


//****************************************************************************
// MTK_Set_NA_SCHD : Set assistance data scheduling
// Parameters: 
//    [Type] Assistance data type.
//           0: Ephemeris
//           1: Almanac
//           2: Reference time
//           3: Reference location
//           4: Reserved
//           5: Klobuchar model
//           6: UTC model
//           7: Bad satellite list
//    [Interval] Output interval [0 ~ 255](s).
//           0: Disable output
//           1 ~ 255: interval
//    [Number] Number of satellites for this output.
//           this argument only be meaningful for type 0 (Ephemeris) 
//           and 1 (Almanac).
//             
// Returns: zero(fail), nonzero(pass)
//
// Example1: Set Ephemeris output interval 1 second,
//           6 satellites for each output.
//          MTK_Set_NA_SCHD(0,1,6)
// Example2: Set reference location output interval 2 seconds
//          MTK_Set_NA_SCHD(3,2,1)
// Example3: Disable Bad Satellite List output
//          MTK_Set_NA_SCHD(7,0,1)
//****************************************************************************
unsigned char MTK_Set_NA_SCHD(
      int Type,      // Assistance data type 
      int Interval,  // Output interval (s)
      int Number);   // Number of satellites for this output


//****************************************************************************
// MTK_Query_NA_Role : Query current assistance service role
//             
// Returns: service role
//          0: Be a client
//          1: Be a reference Station
//****************************************************************************
int MTK_Query_NA_Role(void);


//****************************************************************************
// MTK_Set_NA_Role : Set assistance service role
// Parameters: 
//    [Role] service role
//           0: Be a client
//           1: Be a reference Station
//             
// Returns: zero(fail), nonzero(pass)
// Example: Set the receiver to be a reference station
//          MTK_Set_NA_Role(1)
//****************************************************************************
unsigned char MTK_Set_NA_Role(
      int Role);      // service role


//****************************************************************************
// MTK_Get_NA_Eph : Output a plurality of ephemeris data for those satellites in view
//             
//****************************************************************************
void MTK_Out_NA_Eph(void);

#ifdef __cplusplus
   }
#endif

#endif /* MTK_NA_BASE_H */
