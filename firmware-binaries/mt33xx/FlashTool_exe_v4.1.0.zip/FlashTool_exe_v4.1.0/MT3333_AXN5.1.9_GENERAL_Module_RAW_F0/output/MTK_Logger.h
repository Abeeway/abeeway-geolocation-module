/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_LOGGER_H
#define MTK_LOGGER_H

#ifdef __cplusplus
   extern "C" {
#endif


#include "MTK_SDK.h"

//****************************************************************************
//Serial Flash Options begin
//Write method option, please choose between one of below three kinds
#define SFLASH_PAGE_WRT       (0L)
#define SFLASH_BYTE_WRT       (1L)
#define SFLASH_WORD_AAI_WRT   (2L)

// Set to SST flash type will execute Write Status register enable when needed for SST
#define SFLASH_SST_TYPE       (4L)
//Serial Flash Options end

//****************************************************************************

// MTK Logger Status
#define MTK_LOGGER_NEED_ERASE     (1L << 0)
#define MTK_LOGGER_FULL           (1L << 1)
#define MTK_LOGGER_START          (1L << 2)
#define MTK_LOGGER_ENABLED        (1L << 3)
#define MTK_LOGGER_DISABLED       (1L << 4)

#define LOGGER_LAT_SET                     (1 << 0)
#define LOGGER_LON_SET                     (1 << 1)
#define LOGGER_HGT_SET                     (1 << 2)

typedef struct Log_Data
{
    double LAT; 
    double LON;
    double HGT;
} S_log_data;

//****************************************************************************
// MTK_Logger_Erase  :  Erase Serial Flash for logger function
// Description :
// Return value : 1 --> Erase OK
//                0 --> Erase Fail
// Example:
//

int  MTK_Logger_Erase (void);


//****************************************************************************
// MTK_Logger_Start  :  Start Logger functions
// Description :
// Return value : 1 --> Logger Start OK
//                0 --> Logger Start Fail
// Example:
//

int  MTK_Logger_Start (void);

//****************************************************************************
// MTK_Logger_Stop  :  Stop Logger functions
// Description :
// Return value : 1 --> Logger Stop OK
//                0 --> Logger Stop Fail
// Example:
//

int  MTK_Logger_Stop (void);

//****************************************************************************
// MTK_Logger_Enable  :  Enable logger function by SDK
// Description :
// Return value : 1 --> Enable OK
//                0 --> Enable Fail
// Example:
//    unsigned short u2LoggerStatus;
//    MTK_Logger_Query_Status (&u2LoggerStatus)
//
//    if (u2LoggerStatus & MTK_LOGGER_DISABLED)
//    {
//        MTK_Logger_Enable();
//    }
int  MTK_Logger_Enable (void);

//****************************************************************************
// MTK_Logger_Read_ID  :  Read Serial flash ID used for logger
// Description :
//
// Example:
//    unsigned long u4SflashID;
//    MTK_Logger_Read_ID (0x9F, &u4SflashID);  // 0x9F is JEDEC Read ID command
//    if (u4SflashID == 0xC2201500)
//    {
//        // This is MXIC 0xC22000 serial flash, do user actions here
//        MTK_Logger_Set_SFlash_Size(0x200000);  // Set serial flash size
//    }

void  MTK_Logger_Read_ID (unsigned char ucRIDCmd, unsigned long *u4SFlashID);

//****************************************************************************
// MTK_Logger_Set_SFlash_Size  :  Set Serial flash size (in bytes unit)
// Description : Assign serial flash size as user specification
//
// Example:
//    MTK_Logger_Set_SFlash_Size(0x200000);  // Set serial flash size as 2MB
//    
void  MTK_Logger_Set_SFlash_Size (unsigned long u4SFlashSize);

//****************************************************************************
// MTK_Logger_Set_SFlash_Option  :  Set Serial flash options
// Description :
//
// Example:
//    MTK_Logger_Set_SFlash_Option(SFLASH_WORD_AAI_WRT | SFLASH_SST_TYPE);  
//    
void  MTK_Logger_Set_SFlash_Option (unsigned long u4SFlashOption);

//****************************************************************************
// MTK_Logger_Setup_Log_Ctl  :  Setup logger control 
// Description :
// Return value : 1 --> Logger setup OK
//                0 --> Logger setup Fail
//
//---------------------------------------------------
//SETUP_LOG_CTL  |  Argument1    |  Argument2
//---------------+---------------+-------------------
//               |  1: LOG NOW   | Hex: RCD REASON
//---------------+---------------+-------------------
//               |  2: RCD FIELD | Hex: FMT_REG 
//               |               | (Refer to Logger Library User Manual Table 2)
//---------------+---------------+-------------------
//               |  3: BY SEC    | Dec: 0.1 SEC
//               |               | (0: no use)
//---------------+---------------+-------------------
//               |  4: BY DIS    | Dec: 0.1 METER
//               |               | (0: no use)
//---------------+---------------+-------------------
//               |  5: BY SPD    | Dec: 0.1 KM/H
//               |               | (0: no use)
//---------------+---------------+-------------------
//               |  6: RCD METHOD| 1: Overwrite
//               |               | 2: Full and Stop
//---------------------------------------------------
//
// Example:
//    MTK_Logger_Setup_Log_Ctl(3, 50);  // Setup recording by 5 sec
//    MTK_Logger_Setup_Log_Ctl(4, 100); // Setup recording by 10 meter
//    MTK_Logger_Setup_Log_Ctl(6, 1);   // Setup recording method as overwrite
int  MTK_Logger_Setup_Log_Ctl (unsigned long u4Arg1, unsigned long u4Arg2);

//****************************************************************************
// MTK_Logger_Query_Fmt_Reg  :  Get format register
// Description :
//
// Example:
//    unsigned long u4FormatRegister;
//    MTK_Logger_Query_Fmt_Reg(&u4FormatRegister);  
//    MTK_Logger_Setup_Log_Ctl(2, (u4FormatRegister | (1 << 12)));  // Add NSAT for recording
void  MTK_Logger_Query_Fmt_Reg (unsigned long *u4FormatRegister);

//****************************************************************************
// MTK_Logger_Query_SEC  :  Get (By Second) data value (0.1 sec in unit)
// Description :
//
// Example:
//    unsigned long u4BySecond;
//    MTK_Logger_Query_SEC(&u4BySecond);  
//    
void  MTK_Logger_Query_SEC (unsigned int *u4BySecond);

//****************************************************************************
// MTK_Logger_Query_DIS  :  Get (By Distance) data value (0.1 meter in unit)
// Description :
//
// Example:
//    unsigned long u4ByDistance;
//    MTK_Logger_Query_DIS(&u4ByDistance);  
//    
void  MTK_Logger_Query_DIS (unsigned int *u4ByDistance);

//****************************************************************************
// MTK_Logger_Query_SPD  :  Get (By Speed) data value (0.1 KM/H in uint)
// Description :
//
// Example:
//    unsigned long u4BySpeed;
//    MTK_Logger_Query_SPD(&u4BySpeed);  
//    
void  MTK_Logger_Query_SPD (unsigned int *u4BySpeed);

//****************************************************************************
// MTK_Logger_Query_Rcd_Method  :  Get recording method
// Description : RCD Method --> 1 : OVP (Overwrite)
//                              2 : STP (Full and Stop)
// Example:
//    unsigned short u2RcdMethod;
//    MTK_Logger_Query_Rcd_Method(&u2RcdMethod);  
//    if (u2RcdMethod == 1)
//    {
//        // Overwrite method
//    }
//    else if (u2RcdMethod == 2)
//    {
//        // Full and Stop method
//    }
void  MTK_Logger_Query_Rcd_Method (unsigned short *u2RcdMethod);

//****************************************************************************
// MTK_Logger_Query_Status  :  Query logger status
// Description :
//
// Example:
//    unsigned short u2LoggerStatus;
//    MTK_Logger_Query_Status (&u2LoggerStatus)
//
//    if (u2LoggerStatus & MTK_LOGGER_NEED_ERASE)
//    {
//        MTK_Logger_Erase();
//    }

void  MTK_Logger_Query_Status (unsigned short *u2LoggerStatus);

//****************************************************************************
// MTK_Logger_Query_Rcd_Addr  :  Get current log address for new recording
// Description :
//
// Example:
//    unsigned long u4NextWriteAddress;
//    MTK_Logger_Query_Rcd_Addr(&u4NextWriteAddress);  
//    
void  MTK_Logger_Query_Rcd_Addr (unsigned long *u4NextWriteAddress);

//****************************************************************************
// MTK_Logger_Write_String  :  Write a string into serial flash from next writable address
// Description : Maximum write length will be 256 bytes
// Return value : 1 --> Write OK
//                0 --> Write failure due to NWA is wrong
//                0xFF --> Write failure due to serial flash write action failed
//                0xEE --> Input string length is zero or NULL, no data to write
//
// Example:
//    unsigned long u4Vendor = 1234;
//    MTK_Logger_Write_String("VENDOR_DEFINE=%d",u4Vendor);
//
int MTK_Logger_Write_String (
   char       *data,          // i  - string to be formatted
   ...);                      // i  - variable arguments

//****************************************************************************
// MTK_Logger_Read_String  :  Read a string from serial flash from given address
// Description : Read buffer must be at least 4 bytes larger than the read length
// Return value : Pointer to the start of read data
//                
// Example:
//    unsigned char pReadBuf[0x104]; // Should allocated 4 bytes larger than the read length
//    unsigned char *pData = NULL;
//    pData = MTK_Logger_Read_String(0x1A00, 0x100, pReadBuf);
//
unsigned char * MTK_Logger_Read_String (unsigned long  u4ReadStartAddr, 
                                        unsigned short u2ReadLength, 
                                        unsigned char * pReadBuf);

//*************************************************************************************
// MTK_Logger_Sector_Erase  :  Erase Serial Flash for logger function (Use Sector Erase)
// Description : This function purely erases the specified sector (sector size is 64KB)
//               and does not write the sector pattern
// Return value : 1 --> Sector Erase OK
//                0 --> Sector Erase Fail
// Example:
// MTK_Logger_Sector_Erase(0); // Erase sector 0, address is 0x000000~0x00FFFF
// MTK_Logger_Sector_Erase(1); // Erase sector 1, address is 0x010000~0x01FFFF
//
int  MTK_Logger_Sector_Erase (unsigned char u1SectorNumber);

//****************************************************************************
// MTK_Logger_Raw_Write  :  Write a raw string(binary mode) into serial flash 
//                          in specified address
// Description : Write length should within the same sector
// Return value : 1 --> Write OK
//                0 --> Write failure
//
// Example:
//    unsigned char pTestData[] = {0x11, 0x22, 0x33, 0x44};
//    MTK_Logger_Raw_Write(0x10000, 4, pTestData);  // Write the pTestData at 0x10000 in serial flash
//    
int MTK_Logger_Raw_Write (
   unsigned long  u4WriteStartAddr,   // Write start address
   unsigned short u2WriteLength,      // Write length
   char           *WriteData);        // i  - data string to be written

//*************************************************************************************
// MTK_Logger_Product_Enable :  Initialize the MTK logger
// Description : This function will erase the first sector(sector 0) 
//               and write the sector pattern along with logger data initialization.
// Return value : None
//                
// Example:
//
void MTK_Logger_Product_Enable (void);

//*************************************************************************************
// MTK_Logger_Set_LOGPMTK :  Enable and Disable Logger PMTK 
// Description : This function will enable and disable Logger PMTK 
//  
// Return value : 1 --> Setting  OK
//                       0 --> Setting  failure       
//                
// Example:
//            u1logpmtk :  0     =>   Enable Logger PMTK 
//            u1logpmtk :   1    =>   Disable Logger PMTK 

int  MTK_Logger_LOG_PMTK_Disable(unsigned char u1logpmtk );

//****************************************************************************
// MTK_Logger_Set_Data  :  Modify data used in logger
// Description :  Use input data to modify corresponding data in logger  
//                Default modified data is set NULL.
//                If latitude or longitude data is invalid,
//                record raw data in logger.
//                
//                latitude < -(PI/2) or latitude > (PI/2)  --> invalid
//                longitude < -(PI) or longitude > (PI)    --> invalid
//                                   
//                  
// Return Value : 0 --> invalid input data or modification is not enabled
//                1 --> valid input data and modifidy data to be recorded in logger             
// Example: 
//                S_log_data datain;
//
//                datain.LAT=1.54; //valid latitude
//                datain.LON=9.71; //invalid longitude
//                datain.HGT=152.00; //valid height
//
//                //enable LAT/LON/HGT modification
//                fgLogModifyBit = fgLogModifyBit | LOGGER_LAT_SET | LOGGER_LON_SET |LOGGER_HGT_SET;
//                
//                MTK_Logger_SetData_Enable(fgLogModifyBit);
//  
//                if(MTK_Logger_Set_Data(&datain)) 
//                {
//                   MTK_UART_OutputData("LOG SET OK");  
//                }
//                else
//                {
//                   MTK_UART_OutputData("LOG SET FAIL");  
//                }
// Result:
//                "LOG SET FAIL", because input data is invalid(invalid longitude)
//                If datain.LON = 2.71 --> valid longitude, LOG SET OK
//
int MTK_Logger_Set_Data(S_log_data *data);

//****************************************************************************
// MTK_Logger_Get_Data  :  Get modified data used in logger
// Description :  Get modified data used in logger  
//            
//
// Example: 
//               S_log_data dataout;
//               MTK_Logger_Get_Data(&dataout);
//               -->dataout.LAT: Modified latitude used in logger
//               -->dataout.LON: Modified longitude used in logger
//               -->dataout.HGT: Modified height used in logger
//
void MTK_Logger_Get_Data(S_log_data *data);

//****************************************************************************
// MTK_Logger_Set_Enable  :  Enable data to be modified in logger
// Description : When fgLogModifyBit is set, the corresponding logger data
//               will be recorded with those set with MTK_Logger_Set_Data.
//                 
// Example: 
//       unsigned char fgLogModifyBit; 
//       fgLogModifyBit = fgLogModifyBit | LOGGER_LAT_SET | LOGGER_LON_SET |LOGGER_HGT_SET;
//       MTK_Logger_SetData_Enable(fgLogModifyBit);
//
// Results:
//       Latitude, Longitude, and Height will be recorded with user modified data in logger.
void MTK_Logger_SetData_Enable(unsigned char fgLogModifyBit);

#ifdef __cplusplus
   }
#endif

#endif /* MTK_LOGGER_H */
