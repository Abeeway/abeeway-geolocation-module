/***********************************************************************
*   This software/firmware and related documentation ("MediaTek Software") 
*   are protected under relevant copyright laws. The information contained 
*   herein is confidential and proprietary to MediaTek Inc. and/or its licensors.
*
*   Without the prior written permission of MediaTek Inc. and/or its licensors, 
*   any reproduction, modification, use or disclosure of MediaTek Software, and 
*   information contained herein, in whole or in part, shall be strictly prohibited.
*
*   MediaTek Inc. (C) [2005]. All rights reserved.
*
*************************************************************************/ 
/*****************************************************************************
BY OPENING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES THAT
THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS"
BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER
DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE SOFTWARE OF
ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR SUPPLIED WITH THE
MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY
WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR
ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION OR TO CONFORM TO
A PARTICULAR STANDARD OR OPEN FORUM.

BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE
LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT
MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR
REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK
FOR SUCH MEDIATEK SOFTWARE AT ISSUE.

THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH
THE LAWS OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS
PRINCIPLES.  ANY DISPUTES, CONTROVERSIES OR CLAIMS ARISING THEREOF AND RELATED
THERETO SHALL BE SETTLED BY ARBITRATION IN SAN FRANCISCO, CA, UNDER THE RULES
OF THE INTERNATIONAL CHAMBER OF COMMERCE (ICC).
*****************************************************************************/

#ifndef MTK_SDK_H
#define MTK_SDK_H

#ifdef __cplusplus
   extern "C" {
#endif


// define TRUE and FALSE
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

/** @defgroup sdk_define Define
  * @{
  */
 
/** @brief GPS state is invalid. */
#define GPS_STATE_INVALID 0
/** @brief GPS state is startup. */
#define GPS_STATE_STARTUP 1
/** @brief GPS state is running. */
#define GPS_STATE_RUNNING 2
/** @brief GPS state is sleep. */
#define GPS_STATE_SLEEP   3
/** @brief GPS state is restart. */
#define GPS_STATE_RESTART 4

/** @brief Get the 3-D position DOP. */  
#define CHOOSE_PDOP 0
/** @brief Get the DOP in horizontal direction. */  
#define CHOOSE_HDOP 1
/** @brief Get the DOP in vertical direction. */  
#define CHOOSE_VDOP 2
/** @brief Get the Geometrical DOP. */  
#define CHOOSE_GDOP 3
/** @brief Get the Time DOP. */  
#define CHOOSE_TDOP 4

/** @brief No fix (not enough SVs). */     
#define FIX_NONE 0
/** @brief Estimated mode (when SVs not enough after TTFF). */     
#define FIX_ESTIMATE 1
/** @brief Position fixed. */     
#define FIX_GPS 2
/** @brief Position fixed in DGPS mode. */     
#define FIX_DIFF 3
/** @brief no fix. */    
#define SV_NOFIX 0
/** @brief 2-dimensional fix. */    
#define SV_2DFIX 1
/** @brief 3-dimensional fix. */    
#define SV_3DFIX 2

/** @brief Set Other sentense. */
#define OTHER_SET                     (1 << 7)
/** @brief Set GPZDA sentense. */
#define GPZDA_SET                     (1 << 6)
/** @brief Set GPVTG sentense. */
#define GPVTG_SET                     (1 << 5)
/** @brief Set GPRMC sentense. */
#define GPRMC_SET                     (1 << 4)
/** @brief Set GPGSV sentense. */
#define GPGSV_SET                     (1 << 3)
/** @brief Set GPGSA sentense. */
#define GPGSA_SET                     (1 << 2)
/** @brief Set GPGLL sentense. */
#define GPGLL_SET                     (1 << 1)
/** @brief Set GPGGA sentense. */
#define GPGGA_SET                     (1 << 0)

/**
  * @}
  */

/** @defgroup sdk_enum Enums
  * @{
  */
  
/** @brief
 * This enum defines the type of excecption handler. 
 */
typedef enum
{
   DEFAULT_STATUS = 0,                       /**< None excecption. */
   FLOATING_POINT_INFINITY = 1,              /**< Floating point infinity excecption. */
   FLOAT_INPUT_ARGUMENT_NaN = 2,             /**< Float input argument error. */
   ATLEAST_ONE_FLOAT_INPUT_ARGUMENT_NaN = 3, /**< At last one float input argument error. */
   DOUBLE_INPUT_ARGUMENT_NaN = 4,            /**< Double input argument error. */
   ATLEAST_ONE_DOUBLE_INPUT_ARGUMENT_NaN = 5,/**< At last one double input argument error. */
   RT_RAISE_CALL = 6,                        /**< RT raise call excecption. */
   UNEXPECTED_HANDLER = 7                    /**< Unexpected excecption. */
}eExcecptionHandlerType;

/**
  * @}
  */

/** @defgroup sdk_struct Structures
  * @{
  */

/** @brief
 * This struct defines RTC time. 
 */
typedef struct srtc_t
{
    unsigned char    ucYEAR;         /**< RTC time -- year. UTC year minus 2000.*/
    unsigned char    ucMONTH;        /**< RTC time -- month. Value is 1 ~ 12.             */
    unsigned char    ucDAY;          /**< RTC time -- day. Value is 1 ~ 31.             */
    unsigned char    ucWEEK;         /**< RTC time -- week. Value is 0 ~ 6.             */
    unsigned char    ucHOUR;         /**< RTC time -- hour. Value is 0 ~ 23.             */
    unsigned char    ucMIN;          /**< RTC time -- minute. Value is 0 ~ 59.             */
    unsigned char    ucSEC;          /**< RTC time -- second. Value is 0 ~ 59.             */
    double           dfMSEC;         /**< RTC time -- smilli-second.       */
} s_MTK_RTC_T;

/** @brief
 * GPS kep parameter. The ephemeris (see ICD-GPS-200).
 */
typedef struct sgpskep_p
{

   double M0;                  /**< Mean anomaly at reference time [rad]. */
   double e;                   /**< Eccentricity [dimensionless]. */
   double sqrtA;               /**< Square root of the semi-major axis [m**1/2]. */
   double Omega0;              /**< Longitude of ascending node of orbit plane [rad]. */
   double i0;                  /**< Inclination angle at reference time [rad]. */
   double w;                   /**< Argument of perigee [rad].    */
   double OmegaDot;            /**< Rate of right ascention [rad/s]. */
   float Crs;                  /**< Amp of sin harmonic corr term orbit radius [m]. */
   float Cuc;                  /**< Amplitude of cos harm corr term arg of latitude [rad]. */
   float dn;                   /**< Delta n Mean motion diff from computed value [rad/s]. */
   float Cus;                  /**< Amplitude of sin harm corr term arg of latitude [rad]. */
   float Cis;                  /**< Amplitude of sin harm corr term ang of inclination [rad]. */
   float Cic;                  /**< Amplitude of cos harm corr term ang of inclination [rad]. */
   float Crc;                  /**< Amplitude of cos harm corr term orbit radius [m]. */
   float IDOT;                 /**< Rate of inclination angle [rad/s]. */
   int toe;                    /**< Reference Time of Week [Ephemeris Terms] [s]. */
   int toc;                    /**< Reference Time of Week [Clock Terms] [s]. */
   short WeekNo;               /**< Reference week number [weeks]. */
   unsigned char SVid;         /**< satellite id number [dimensionless]. */
   unsigned char IOD;          /**< Issue Of Data Counter [dimensionless]. */
                               
   double af0;                 /**< SV clock correction polynomial coefficient [s]. */
   double af1;                 /**< SV clock correction polynomial coefficient [s/s]. */
   double af2;                 /**< SV clock correction polynomial coefficient [s/s/s]. */
   float TGD;                  /**< L1 & L2 Correction term [s]. */
   unsigned char Fit;          /**< Fit interval [0=4 hours 1=6 hours]. */
   unsigned char FOM;          /**< Figure of Merit - Defines URA. */
   unsigned char Nav_Health;   /**< The 5 LSBs of the NAV data's health status from. */
} s_MTK_GPS_Kep_Para;

/** @brief
 * Beidou kep parameter.
 */
typedef struct sbdkep_p
{
   double M0;                 /**< Mean anomaly at reference time [rad]. */  
   double sqrtA;              /**< Square root of the semi-major axis [m**1/2]. */ 
   double Omega0;             /**< Longitude of ascending node of orbit plane [rad]. */ 
   double i0;                 /**< Inclination angle at reference time [rad]. */
   double w;                  /**< Argument of perigee [rad]. */
   double e;                  /**< Eccentricity [dimensionless]. */
   double OmegaDot;           /**< Rate of right ascention [rad/s]. */
   double af0;                /**< SV clock correction polynomial coefficient [s]. */
   double af1;                /**< SV clock correction polynomial coefficient [s/s]. */
   double af2;                /**< SV clock correction polynomial coefficient [s/s/s]. */
   double TGD1;               /**< L1 & L2 Correction term [s]. */
   double TGD2;               /**< L1 & L2 Correction term [s]. */
   double Crs;                /**< Amp of sin harmonic corr term orbit radius [m]. */
   double dn;                 /**< Delta n Mean motion diff from computed value [rad/s]. */
   double Cuc;                /**< Amplitude of cos harm corr term arg of latitude [rad]. */
   double Cus;                /**< Amplitude of sin harm corr term arg of latitude [rad]. */
   double Cic;                /**< Amplitude of cos harm corr term ang of inclination [rad]. */
   double Cis;                /**< Amplitude of sin harm corr term ang of inclination [rad]. */
   double Crc;                /**< Amplitude of cos harm corr term orbit radius [m]. */
   double IDOT;               /**< Rate of inclination angle [rad/s]. */
   int toc;                   /**< Reference Time of Week [Clock Terms] [s]. */
   int toe;                   /**< Reference Time of Week [Ephemeris Terms] [s]. */
   signed short WeekNo;       /**< Reference week number [weeks]. */
   unsigned char IODC;        /**< Issue Of Data Counter [dimensionless]. */
   unsigned char IODE;        /**< Issue Of Data Ephemeris. */
   unsigned char Nav_Health;  /**< The healthy. */
   unsigned char URA;         /**< User range error. */
   signed char a0;            /**< Klobuchar - alpha 0  (seconds)           / (2^-30). */
   signed char a1;            /**< Klobuchar - alpha 1  (sec/semi-circle)   / (2^-27/PI) . */
   signed char a2;            /**< Klobuchar - alpha 2  (sec/semi-circle^2) / (2^-24/PI^2). */
   signed char a3;            /**< Klobuchar - alpha 3  (sec/semi-circle^3) / (2^-24/PI^3). */
   signed char b0;            /**< Klobuchar - beta 0   (seconds)           / (2^11). */
   signed char b1;            /**< Klobuchar - beta 1   (sec/semi-circle)   / (2^14/PI). */
   signed char b2;            /**< Klobuchar - beta 2   (sec/semi-circle^2) / (2^16/PI^2). */
   signed char b3;            /**< Klobuchar - beta 3   (sec/semi-circle^3) / (2^16/PI^3). */
} s_MTK_BD_Kep_Para;

/** @brief
 * This struct defined GPS accuracy data.
 */
typedef struct sacc_t  //GPS Accuracy
{
   float Pos_2D_Var_Acc;    /**< Position accuracy in Horizontal Direction (Variance Only) [m].*/
   float Pos_3D_Var_Acc;    /**< Position accuracy in 3-D Direction (Variance Only) [m].*/
   float Pos_Vert_Var_Acc;  /**< Position accuracy in Vertical Direction (Variance Only) [m].*/
   float Pos_N_Acc;         /**< Position accuracy in North Direction (Variance Only) [m].*/
   float Pos_E_Acc;         /**< Position accuracy in East Direction (Variance Only) [m].*/
   float Pos_D_Acc;         /**< Position accuracy in vertical Direction (Variance Only) [m].*/
   float Vel_3D_Acc;        /**< 3-dimensional Speed Accuracy[m/s].*/
   float Vel_N_Acc;         /**< Velocity accuracy in North direction [m/s].*/
   float Vel_E_Acc;         /**< Velocity accuracy in East direction [m/s].*/
   float Vel_D_Acc;         /**< Velocity accuracy in vertical direction [m/s].*/
   float Course_Acc;        /**< Course/Heading [degrees].*/
   float Time_Acc;          /**< Time [ns].*/
} s_MTK_Acc_T;

/** @brief
 * GPS Navigation Message Binary Ionospheric data. Ionospheric model terms (See ICD-GPS-200)
 */
typedef struct sgpsion_p
{
   signed int GPS_secs;       /**< Time at which the complete message was decoded.(integer seconds since start of GPS week 0). */
   signed char a0;            /**< Klobuchar - alpha 0  (seconds)           / (2^-30). */
   signed char a1;            /**< Klobuchar - alpha 1  (sec/semi-circle)   / (2^-27/PI). */
   signed char a2;            /**< Klobuchar - alpha 2  (sec/semi-circle^2) / (2^-24/PI^2). */
   signed char a3;            /**< Klobuchar - alpha 3  (sec/semi-circle^3) / (2^-24/PI^3). */
   signed char b0;            /**< Klobuchar - beta 0   (seconds)           / (2^11). */
   signed char b1;            /**< Klobuchar - beta 1   (sec/semi-circle)   / (2^14/PI). */
   signed char b2;            /**< Klobuchar - beta 2   (sec/semi-circle^2) / (2^16/PI^2). */
   signed char b3;            /**< Klobuchar - beta 3   (sec/semi-circle^3) / (2^16/PI^3). */
}  s_MTK_GPS_Ion_Para;

/** @brief
 * This struct defined GLEO Time Offset.
 */
typedef struct sgleotimeoffset
{                 
   double A0G;             /**< constant term of the offset dT_systems.*/
   double A1G;             /**< rate of change of the offset dT_system.*/
   unsigned int t0G;       /**< reference time for GGTO reference.*/
   unsigned short WN0G;    /**< Week Number of GGTO reference.*/
}  s_MTK_GLEO_Time_Offset;

/**
  * @}
  */

/** @defgroup sdk_typedef Typedef
  * @{
  */
  

/** @brief  This defines the excecption handler. 
 *  @param [in] eExcecptionHandlerType: The value is defined in #eExcecptionHandlerType. This parameter is given by the GNSS system.
 *  @return  void.\n
 */
typedef void (*Excecption_Handler_ptr)(eExcecptionHandlerType);

/**
  * @}
  */
  
/** @defgroup sdk_function Function
  * @{
  * In this chapter, the available sources provided in the MTK SDK will be detailed. 
  * As shown in figure, there are five parts of the sources, and they are Main Task, Timer Task, UART, GPIO and GNSS Utilities. 
  * The first two, Main Task and Timer Task, are provided to enable the developers to add their own applications. 
  * UART and GPIO are peripheral of the GNSS system. Developers can program the UART output data and the high-low status of GPIO pins. 
  * Moreover, quantities of GNSS utilities that enable the developers to get or set the status of the GNSS navigation system are available.
  * @image html Architecture_of_GNSS_SDK.png
  */
/** @defgroup main_task Main Task
  * @{
  * There are three functions categorized in Main Task.\n
  * SDK_Init() is responsible for the initialization of global variables. Different from standard C programming, developers can 
  * initialize global variables in SDK_Init() only. \n
  * SDK_Main() is triggered by the GPS navigation system. As a result, the trigger frequency is just the fix-rate of navigation. 
  * For example, if the fix-rate is 1000 ms, the trigger frequency will be 1 Hz. In other words, the developers can change 
  * the execution rate of main task by configuring the fix-rate of navigation. 
  */
  
/**
 * @brief 
 * The hardware initialization routine for SDK application.\n This callback will be invoked every hardware restart.
 * @param[in] void.
 * @return  void.
 */
void SDK_Hw_Init (void);
  
/**      
 * @brief 
 * The initialization routine for SDK application.\n This callback will be invoked every restart.\n
 * Note that developers cannot assigned values to global variables at declaration.
 * @param[in] source  zero = called during power on start.\n nonzero = called during software restart.
 * @return TRUE: All SDK task work.\n 
           FALSE: All SDK task have no function.\n                   
           Default: return TRUE.
 * @par Example
 * @code
 * // Correct Usage of Global Variable 
 * double dfTest; 
 * int SDK_Init (void) 
 * { 
 *     dfTest = 1.0; 
 *     return TRUE; 
 * } 
 * 
 * //  Incorrect Usage of Global Variable 
 * double dfTest = 1.0; 
 * int SDK_Init (void) 
 * { 
 *     return TRUE; 
 * } 
 * @endcode
 * @note
 * The maximum total size of all global variables is 4096 bytes.
 */
int SDK_Init (int source);


/**
 * @brief
 * Sdk Main functions Routine. 
 * Developers can add applications in this function. \n
 * Note that this function is called with 1 Hz default frequency,\n
 * and developers can configure the frequency by setting different fix rate. 
 * @param[in] void.
 * @return 
 * void 
 * @par Example
 * @code
 * 
 * void SDK_Main(void) 
 * { 
 *     signed char ElevMask = 5; 
 *     MTK_UART_OutputData("*** MTK GPS Receiver ***"); 
 *     MTK_Set_Elev_Mask(ElevMask); 
 *     MTK_Get_Elev_Mask(&ElevMask); 
 *     MTK_NMEA_OutputData("PMTKSDK,ElevMask,%d", ElevMask); 
 * } 
 * 
 * Result:
 * > Result: 
 * *** MTK GPS Receiver *** 
 * PMTK SDK, ElevMask,5 
 * *** MTK GPS Receiver *** 
 * PMTK SDK, ElevMask,5 
 * ...
 * *** MTK GPS Receiver *** 
 * PMTK SDK, ElevMask,5
 * 
 * @endcode
 * @note
 * The fix-rate is 1000ms in this example.
 * 
 */
void SDK_Main(void);

/**
  * @}
  */

/** @defgroup timer_task Timer Task
  * @{
  * The MTK SDK also provides a timer task that enable developer to add regular executed functions. 
  * It is noted that the minimum interval of the timer task (counter) is 100 milliseconds. 
  * Developers can add their applications with different time interval in SDK_TimerEvent().
  */
  
/**
 * @brief
 * Timer functions Routine. Timer interval is 100ms.
 * Developers can add applications in this function, and execution frequency can be set as well.\n
 * The minimal interval of timer events is 100 milliseconds.\n
 * That is, developers can program different tasks executed with different timer intervals by counting corresponding timer events. 
 * @param[in] void.
 * @return 
 * void 
 * @par Example
 * @code
 * void SDK_TimerEvent(void) 
 * { 
 *     static unsigned long u4TimerCnt=0; 
 *     if ( u4TimerCnt> 0) 
 *     { 
 *         if ( (u4TimerCnt % 600) == 0)    //   600 * 100msec = 60 sec 
 *         { 
 *             MTK_ColdStart();               //    Example: cold start TASK.. 
 *         } 
 *         if ( (u4TimerCnt % 400) == 0 )   //     400 * 100msec = 40 sec 
 *         { 
 *             // User defined TASK... 
 *         } 
 *     } 
 *     u4TimerCnt++; 
 * } 
 * Result:
 * > Result 
 * The system will be restarted every 60 seconds, and user defined task is execute every 40 seconds. 
 * 
 * @endcode
 */
void SDK_TimerEvent(void);

/**
  * @}
  */

/** @defgroup receive_parse Receive and Parse User Packet
  * @{
  */
  
/**
 * @brief
 * Receiver application specific data from UART input.\n
 * The behavior of this callback function is determined by the OPTION_BYPASS_CHECKSUM value in the SDK_Callback.\n
 * If the OPTION_BYPASS_CHECKSUM is greater than zero, the MTK GPS Core will bypass the parser and redirect the 
 * raw data from UART input to this callback function.\n
 * If the OPTION_BYPASS_CHECKSUM is zero, this callback will receive user defined NMEA sentences. 
 * Non NMEA-like sentences will be discarded. The checksum field of every sentence will be removed.\n
 * @param[in] pInBuff is the base pointer of the received data.
 * @param[in] length is the length of the received data.
 * @return 
 * 1 --> Match user-defined setences. 
 * 0 --> Not matched.
 * @par Example
 * @code
 *   //Assume a user-defined SDK NMEA Sentences. $PMTKSDK 
 *   //Example :   $PMTKSDK,1      ==>?Output Satellite Elevation-Mask 
 *   if (strncmp(pInBuff, "$PMTKSDK", 8) == 0) 
 *   { 
 *       if ( *(pInBuff + 9) == '1' ) 
 *       { 
 *           MTK_Get_Elev_Mask(&ElevMask); 
 *           MTK_NMEA_OutputData("PMTKSDK,R,%d", ElevMask); 
 *           //Output Satellite Elevation-Mask Information 
 *       }
 *       else if ( *(pInBuff + 9) == '2' ) 
 *       { 
 *           // User defined Action... 
 *       } 
 *       else 
 *       { 
 *           return FALSE;     // Input packet is invalid 
 *       } 
 *       return TRUE;      // Input packet is valid 
 *   }
 * @endcode
 */
int SDK_Receive_User_Nmea_Pkt (const char *pInBuff, unsigned length);

/**
 * @brief Receive User Defined NMEA Sentences function from Data Port.
 * @param[in] pInBuff is the received NMEA sentences.
 * @param[in] length is the length of the received sentences. Use to check received NMEA sentences.
 * @return nonzero: If Match User Defined Sentences.
 *         0: else
 * @note
 * Please set "OPTION_ALLOW_SEPERATE_UART_PROCESS    EQU     1" in SDK_Callback.s file, if need to receive the data from UART1(DPort).
 */                                     
int SDK_Receive_User_DPort_Pkt (const char *pInBuff, unsigned length);
/**
  * @}
  */

/** @defgroup modify_nmea Modify NMEA Sentence
  * @{
  */
/**
 * @brief Modify Standard NMEA Sentenses function.
 * This function will be called before NMEA output. User can define functions to modify data in standard NMEA Sentences by putting them in this function. 
 * @param[in] fgNmeaType Which NMEA sentense need to modified.\n
 *                       #GPZDA_SET -> Set GPZDA sentense.\n
 *                       #GPVTG_SET -> Set GPVTG sentense.\n
 *                       #GPRMC_SET -> Set GPRMC sentense.\n
 *                       #GPGSV_SET -> Set GPGSV sentense.\n
 *                       #GPGSA_SET -> Set GPGSA sentense.\n
 *                       #GPGLL_SET -> Set GPGLL sentense.\n
 *                       #GPGGA_SET -> Set GPGGA sentense.\n
 * @param[in][out] char *NmeaBuf     input  -->   buffer that saves the standard NMEA sentence to be modified
 *      output  -->  buffer that saves the modified NMEA sentence.
 * @return return how many bytes in New NMEA sentense.\n
 *   If need to modify NMEA sentense, return New NMEA buffer size.\n
 *   Else return 0
 * @par Example
 * @code
 * int SDK_Modify_NMEA(unsigned char fgNmeaType, char *NmeaBuf )
 * {
 * 
 *     #ifdef DEMO_MTK_NMEA_MODIFY
 *     return (DEMO_SDK_Modify_NMEA(fgNmeaType, NmeaBuf));
 *     #else
 *     
 *     //------------------------------------------------
 *     // Add User Modified NMEA Sentences Here
 *     
 *     // No need to Modify NMEA Sentences            
 *     return FALSE;
 *     
 *     #endif
 * 
 * } 
 * @endcode
 * @note Remember using MTK_Nmea_Set_Enable() to enable the NMEA modification.\n
 *       Please set a correct return value (see sample code), otherwise NMEA sentence will wrong.
 */                                    
int SDK_Modify_NMEA(unsigned char fgNmeaType, char *NmeaBuf );
/**
  * @}
  */
 
/** @defgroup utilities Utilities
  * @{
  * In MTK GPS SDK, there are several functions provided to enable developers to get or set the status of the GPS navigation system. 
  * The details and examples of each supported utility function will be listed in the following subsections.
  */
  
/**
 * @brief
 * Hot start command for the navigation system. 
 * @param[in] void.
 * @return 
 * void 
 * @par Example
 * @code
 * // Example: Hot start TASK.. 
 * static unsigned long u4TimerCnt=0; 
 * if ( u4TimerCnt> 0) 
 * { 
 *     if ( (u4TimerCnt % 600) == 0) // 600 * 100msec = 60 sec 
 *     { 
 *         MTK_HotStart(); 
 *     } 
 * } 
 * u4TimerCnt++; 
 * Result:
 * The system is hot-restarted every 60 seconds.
 * @endcode
 */
void MTK_HotStart(void);

/**
 * @brief
 * Warm start command for the navigation system. 
 * @param[in] void.
 * @return    void.
 * @par Example
 * @code
 * // Example: Warm start TASK.. 
 * static unsigned long u4TimerCnt=0; 
 * if ( u4TimerCnt> 0) 
 * { 
 *     if ( (u4TimerCnt % 600) == 0) // 600 * 100msec = 60 sec 
 *     { 
 *         MTK_WarmStart(); 
 *     } 
 * } 
 * u4TimerCnt++; 
 * Result:
 * The system is warm-started every 60 seconds.
 * @endcode
 */
void MTK_WarmStart(void);

/**
 * @brief
 * Cold start command for the navigation system. 
 * @param[in] void.
 * @return    void.
 * @par Example
 * @code
 * // Example: Cold start TASK.. 
 * static unsigned long u4TimerCnt=0; 
 * if ( u4TimerCnt> 0) 
 * { 
 *     if ( (u4TimerCnt % 600) == 0) // 600 * 100msec = 60 sec 
 *     { 
 *     MTK_ClodStart(); 
 *     } 
 * } 
 * u4TimerCnt++; 
 * Result:
 * The system is Cold-started every 60 seconds.
 * @endcode
 */
void MTK_ColdStart(void);

/**
 * @brief
 * Full cold start command for the navigation system. 
 * @param[in] void.
 * @return    void.
 * @par Example
 * @code
 * // Example: Full cold start TASK.. 
 * static unsigned long u4TimerCnt=0; 
 * if ( u4TimerCnt> 0) 
 * { 
 *     if ( (u4TimerCnt % 600) == 0) // 600 * 100msec = 60 sec 
 *     { 
 *         MTK_FullClodStart(); 
 *     } 
 * } 
 * u4TimerCnt++; 
 * Result:
 * The system is full cold started every 60 seconds.
 * @endcode
 */
void MTK_FullColdStart(void);
/**
  * @}
  */

/** @defgroup flash_nvram Flash and NVRam
  * @{
  */
/**
 * @brief
 * Reset the ARM processor to enter the initial handshaking mode for the flash download.
 * After calling this function, all data in the volatile memory will be lost.
 * ARM processor will reset to enter the initial handshaking protocol.
 * @param[in] user_data:   optional user data that would be passed to the boot SDK.
 * @return 
 * void
 * @note
 *     After calling this function, all data in the volatile memory will be lost.
 *     ARM processor will reset to enter the initial handshaking protocol.
 */
void MTK_Begin_Flash_Download (int user_data);
/**
  * @}
  */
  
/** @defgroup uart UART
  * @{
  * UART is an abbreviation of "Universal Asynchronous Receiver/Transmitter". It is used in serial data communication, 
  * and a UART converts bytes of data to and from asynchronous start-stop bit streams represented as binary electrical impulses. 
  * UARTs are used in with other communication standards such as EIA RS-232 commonly. \n
  * In MTK SDK, there are several functions related to UART communication, such as UART data receive/output and NMEA 
  * sentences receive/output. The supported UART functions are listed in table, and the details and examples of each function 
  * will be listed in the following subsections.
  *
  * |Function Name |Description|
  * |--------------|-----------|
  * |MTK_NMEA_OutputData |Output NMEA sentences function|
  * |MTK_UART_OutputData |Output special sentences or debug messages function|
  * |MTK_UART_OutputRawData |Output binary data to the UART interface|
  * |MTK_UART_GetTxBufferFreeSpace |Checking how much empty space is in the UART Tx buffer|
  * |MTK_UART_GetRxBufferFreeSpace |Checking how much empty space is in the UART Rx buffer|
  * |MTK_DPort_OutputNmeaData |Data port output NMEA sentences function|
  * |MTK_DPort_OutputData |Output special sentences or debug messages function from Data Port|
  * |MTK_DPort_OutputRawData |Output binary data to the Data Port interface|
  * |MTK_DPort_GetTxBufferFreeSpace |Checking how much empty space is in the Data Port Tx buffer|
  * |MTK_DPort_GetRxBufferFreeSpace |Checking how much empty space is in the Data Port Rx buffer|
  * |MTK_UART_Tx_Idle |Check if the UART Tx is idle|
  * |MTK_DPort_Tx_Idle |Check if the Data Port Tx is idle|
  * |MTK_Set_UART_TX_Monitor |Set an indicator to start UART Tx ouput completed check|
  * |MTK_Get_UART_TX_Status |Return the UART Tx output completed or not|
  * |MTK_Set_DPort |Set Data Port Operation Mode|
  *
  */
/**
 * @brief Output NMEA Sentences functions.
 * @param[in]  data string to be formatted.
 * @param[in]  arguments variable arguments.
 * @note
 *  In the sentence, No need to include the '$' and '*' delimiters.
 *  This function assumes that the input string is between the '$' and '*' delimiters.
 *  '$', '*', checksum and <CR><LF> will be added automatically.
 * @par Example
 * @code
 *    ElevMask = 5;
 *    MTK_NMEA_OutputData("PMTKSDK,1.00,%05d,,A,,88,,,,,X", ElevMask);
 *    =====> $PMTKSDK,1.00,00005,,A,,88,,,,,X*41
 * @endcode
 */
void MTK_NMEA_OutputData(
   char       *data,
   ...);

/**
 * @brief Output Special Sentences or Debug Message functions.
 * @param[in]  data string to be formatted.
 * @param[in]  arguments variable arguments.
 * @note
 *  This function is similar to the standard library sprintf function.
 *  <CR><LF> will be added automatically after the input string.
 * @par Example
 * @code
 *    MTK_UART_OutputData("*** MTK GPS Receiver ***");
 *    =====> *** MTK GPS Receiver ***<CR><LF>
 *    ElevMask = 5;
 *    MTK_UART_OutputData("*** The Elevation Mask is %d deg ***", ElevMask);
 *    =====> *** The Elevation Mask is 5 deg ***<CR><LF>
 * @endcode
 */
void MTK_UART_OutputData(
   char       *data,
   ...);

/**
 * @brief Output binary data to the UART interface.
 * @param[in]  pInBuff pointer to the binary data for output.
 * @param[in]  length the length of the buffer.
 * @note
 *    This function sends the binary data directly to the UART output without manipulating the content.
 * @par Example
 * @code
 *    char buffer[8] = {0x07, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
 *    MTK_UART_OutputRawData(buffer, 8);
 *    =====> It will send 8 bytes binary data to the UART output
 * @endcode
 */
void MTK_UART_OutputRawData(
   const char *pInBuff,
   unsigned length);

/**
 * @brief Checking how much empty space is in the UART Tx buffer.
 * This function is used to check how many free spaces are in the UART Tx buffer, which can help user for some debugging purpose. The unit is character. 
 * @param[in] void.
 * @return    Tx buffer free space.
 * @note
 *     Checking how much empty space is in the UART Tx buffer
 *     This function is intended for the debugging purpose.
 */
unsigned MTK_UART_GetTxBufferFreeSpace (void);

/**
 * @brief Checking how much empty space is in the UART Rx buffer.
 * This function is used to check how many free spaces are in the UART Rx buffer, which can help user for some debugging purpose. The unit is character. 
 * @param void.
 * @return Rx buffer free space.
 * @note
 *     Checking how much empty space is in the UART Rx buffer
 *     This function is intended for the debugging purpose.
 */
unsigned MTK_UART_GetRxBufferFreeSpace (void);

/**
 * @brief Data Port Output NMEA Sentences functions.
 * @param[in] data string to be formatted
 * @param[in] arguments variable arguments
 * @note
 *  In the sentence, No need to include the '$' and '*' delimiters.
 *  This function assumes that the input string is between the '$' and '*' delimiters.
 *  '$', '*', checksum and <CR><LF> will be added automatically.
 * @par Example
 * @code
 *    ElevMask = 5;
 *    MTK_DPort_OutputNmeaData("PMTKSDK,1.00,%05d,,A,,88,,,,,X", ElevMask);
 *    =====> $PMTKSDK,1.00,00005,,A,,88,,,,,X*41
 * @endcode
 * @note
 * Please set "OPTION_ALLOW_SEPERATE_UART_PROCESS    EQU     1" in SDK_Callback.s file, if need to output data by UART1(DPort).
 */
void MTK_DPort_OutputNmeaData(
   char       *data,
   ...);

/**
 * @brief Output Special Sentences or Debug Message functions from Data Port.
 * @param[in] data string to be formatted.
 * @param[in] arguments variable arguments.
 * @note
 *  This function is similar to the standard library sprintf function.
 *  <CR><LF> will be added automatically after the input string.
 * @par Example
 * @code
 *    MTK_DPort_OutputData("*** MTK GPS Receiver ***");
 *    =====> *** MTK GPS Receiver ***<CR><LF>
 *    ElevMask = 5;
 *    MTK_UART_OutputData("*** The Elevation Mask is %d deg ***", ElevMask);
 *    =====> *** The Elevation Mask is 5 deg ***<CR><LF>
 * @endcode
 * @note
 * Please set "OPTION_ALLOW_SEPERATE_UART_PROCESS    EQU     1" in SDK_Callback.s file, if need to output data by UART1(DPort).
 * 
 */
void MTK_DPort_OutputData(
   char       *data,
   ...);
   
/**
 * @brief Output binary data to the Data Port interface.
 * @param[in] pInBuff pointer to the binary data for output.
 * @param[in] length the length of the buffer.
 * @note
 *    This function sends the binary data directly to the UART output without
 *      manipulating the content
 * @par Example
 * @code
 *    char buffer[8] = {0x07, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66};
 *    MTK_ DPort_OutputRawData ( buffer, 8);
 *    =====> It will send 8 bytes binary data to the data port output
 * @endcode
 */
void MTK_DPort_OutputRawData(
   const char *pInBuff,
   unsigned length);

/**
 * @brief Checking how much empty space is in the data PortUART Tx buffer.
 * @return UART Tx buffer empty space. 
 * @note
 *     Checking how much empty space is in the UART Tx buffer. The unit is character.
 *     This function is intended for the debugging purpose.
 */
unsigned MTK_DPort_GetTxBufferFreeSpace (void);


/**
 * @brief Checking how much empty space is in the data Port UART Rx buffer.
 * @return UART Rx buffer empty space. 
 * @note
 *     Checking how much empty space is in the UART Rx buffer. The unit is character.
 *     This function is intended for the debugging purpose.
 */
unsigned MTK_DPort_GetRxBufferFreeSpace (void);

/**
  * @}
  */

/** @defgroup utilities Utilities
  * @{
  * In MTK GPS SDK, there are several functions provided to enable developers to get or set the status of the GPS navigation system. 
  * The details and examples of each supported utility function will be listed in the following subsections.
  */
  
/**
 * @brief Get the last satellite Elevation-Mask Set.
 * @param ElevMask The elevation mask of the last set will be stored in ElevMask.
 * @par       Example
 * @code
 *     signed char ElevMask;
 *     signed char TmpElevMask;
 *     MTK_Get_Elev_Mask(&ElevMask);
 *     MTK_NMEA_OutputData("SDK,ElevMask,%d", ElevMask);
 *     TmpElevMask = ElevMask;
 *     MTK_Set_Elev_Mask(10);
 *     MTK_Get_Elev_Mask(&ElevMask);
 *     MTK_NMEA_OutputData("SDK,ElevMask,%d", ElevMask);
 *     MTK_Set_Elev_Mask(TmpElevMask);
 * 
 *     =====> $SDK,ElevMask,5*65
 *            $SDK,ElevMask,10*51
 * @endcode
 */
void MTK_Get_Elev_Mask(signed char *ElevMask );

/**
 * @brief
 * Set the satellite Elevation-Mask. The unit of elevation mask is "degrees." The magnitude of elevation mask should be smaller than 90 degrees. 
 * @param[in] ElevMask The new value of elevation mask.
 * @note
 *  The unit of elevation mask is "degrees." The maginitude of elevation mask 
 *  should be smaller than 90 degrees.
 * @return 
 * TRUE: The value of new elevation mask is allowed 
 * FALSE: The value of new elevation mask is NOT allowed 
 * @par       Example
 * @code
 *     signed char ElevMask;
 *     signed char TmpElevMask;
 *     MTK_Get_Elev_Mask(&ElevMask);
 *     MTK_NMEA_OutputData("SDK,ElevMask,%d", ElevMask);
 *     TmpElevMask = ElevMask;
 *     MTK_Set_Elev_Mask(10);
 *     MTK_Get_Elev_Mask(&ElevMask);
 *     MTK_NMEA_OutputData("SDK,ElevMask,%d", ElevMask);
 *     MTK_Set_Elev_Mask(TmpElevMask);
 * 
 *     =====> $SDK,ElevMask,5*65
 *            $SDK,ElevMask,10*51
 * @endcode
 */
unsigned char MTK_Set_Elev_Mask(signed char ElevMask );

/**
 * @brief Get the current differential mode.
 * Get the differential mode of GPS system. Currently, there are three differential modes of GPS, and they are listed below: 
 * 0: Diff_NONE, 
 * 1: Diff_RTCM, 
 * 2: Diff_WAAS, 
 * Default value is "Diff_NONE." 
 * @param[out] DiffMode Store the differential mode of GPS system 
 * @return 
 * void 
 * @par       Example
 * @code
 *    MTK_NMEA_OutputData("DgpsMode,%d", DiffMode);
 *    MTK_Set_Diff_Mode(2);
 *    MTK_Get_Diff_Mode(&DiffMode);
 *    MTK_NMEA_OutputData("DgpsMode,%d", DiffMode);
 * 
 *  =====> DgpsMode,0*1F
 *         DgpsMode,2*1F
 * @endcode
 */
void MTK_Get_Diff_Mode(unsigned char *DiffMode );

/**
 * @brief
 * Set the differential mode of GPS. Since there are three modes supported currently, the user can pass an argument "DiffMode" to set different differential modes of GPS navigation. The corresponding numbers to the three supported modes are listed below: 
 * 0: Diff_NONE, 
 * 1: Diff_RTCM, 
 * 2: Diff_WAAS, 
 * Default value is "Diff_NONE". If an un-supported mode is chosen, return 0. Otherwise, return 1.
 * Besides, if developers do not use appropriate fix interval in WAAS or NONE mode when using high baud rate, it also returns 0. In "Diff_RTCM" mode, the fix interval should greater than 500ms. However, the fix interval should not smaller than 200ms during the "Diff_WAAS" mode. 
 * @param[in] DiffMode New value of differential mode. (0~2) 
 * @return 
 * 1 --> Setting of the differential mode is allowed 
 * 0 --> Setting of the differential mode is NOT allowed 
 * @par Example
 * @code
 *    MTK_NMEA_OutputData("DgpsMode,%d", DiffMode);
 *    MTK_Set_Diff_Mode(2);
 *    MTK_Get_Diff_Mode(&DiffMode);
 *    MTK_NMEA_OutputData("DgpsMode,%d", DiffMode);
 * 
 *  =====> $DgpsMode,0*1F
 *         $DgpsMode,2*1F
 * @endcode
 */
unsigned char MTK_Set_Diff_Mode(unsigned char DiffMode );

/**
 * @brief
 * Get the time difference between UTC and GPS time. 
 * @param[out] UTC_Delta Store the value of time difference. 
 * @return 
 * void 
 * @par Example
 * @code
 *  MTK_Get_UTC_Delta_Time(&UTC_Delta);
 *  MTK_NMEA_OutputData("SDK,UTC,%f", UTC_Delta);
 * 
 *  =====> $SDK,UTC,14.000000*35
 * @endcode
 */
void MTK_Get_UTC_Delta_Time(double *UTC_Delta);

/**
 * @brief
 * Get TOW (Time of week) and WN (Week number) information. 
 * @param[out] TOW time of week.
 * @param[out] WN week number.
 * @return 
 * void 
 * @par Example
 * @code
 *  double TOW = 0.0f;
 *  int WN = 0;
 *  MTK_Get_TOW_WN ( &TOW, &WN);
 *  MTK_UART_OutputData("SDK,WN:%d TOW:%10.15f", WN,TOW );
 *  =====> SDK,WN:1410 TOW:235673.000000000000000
 * @endcode
 */
void MTK_Get_TOW_WN ( double *TOW, int *WN);

/**
 * @brief
 * Set the GPS time. User should give the date and time of GPS that is desired to be set, and the format of them are YYYYMMDD and HHMMSS, respectively. "timeRMS" is the Estimated RMS-error of the above time and date. The corresponding Week Number (WN) and Time of Week (TOW) of the user-set date and time are also stored in the output arguments. 
 * @param[in] Date the user-set date in format YYYYMMDD.
 * @param[in] Time the user-set time in format HHMMSS.
 * @param[in] timeRMS estimated-RMS of the user-set date and time.
 * @param[out] ReturnWN corresponding WN of the user-set date.
 * @param[out] ReturnTOW corresponding TOW of the user-set time and date.
 * @note  User should give the date and time of GPS that you want to set, and 
 *              the format of them are YYYYMMDD and HHMMSS, respectively. timeRMS is 
 *              the Estimated RMS-error of the above time and date. We also output the 
 *              corresponding Week Number (WN) and Time of Week (TOW) of the user-set 
 *              date and time.
 * @return 
 * true   -->  The user-set time and date are reasonable 
 * false  -->  The input time or date is NOT allows
 * @par       Example1
 * @code
 *     RT = MTK_Translate_GPS_Time ( 20061022,235959,1,&WN,&TOW);
 *     if (RT)
 *     {
 *     MTK_NMEA_OutputData("SDK,WN,%05d", WN);
 *     MTK_NMEA_OutputData("SDK,TOW,%05d", TOW);
 *     }
 *     else
 *     {
 *     MTK_NMEA_OutputData("SDK,XXXX");
 *     }
 * 
 *     =====> $SDK,WN,01397*7B
 *            $SDK,TOW,604799*17
 * @endcode
 *
 * @par       Example2 (No leapyear in 2006)
 * @code
 *     RT = MTK_Translate_GPS_Time ( 20060229,235959,1,&WN,&TOW);
 *     if (RT)
 *     {
 *     MTK_NMEA_OutputData("SDK,WN,%05d", WN);
 *     MTK_NMEA_OutputData("SDK,TOW,%05d", TOW);
 *     }
 *     else
 *     {
 *     MTK_NMEA_OutputData("SDK,XXXX");
 *     }
 * 
 *     =====> $SDK,XXXX*72
 * @endcode           
 * @note
 * The user-set time and date in Example1 is reasonable, but the date in the second example is not allowed. Since there is no leap year in 2006, there are only 28 days in February. 
 * Developers can only set the GPS time between 1999/08/31 to 2038/11/19 because the system allows WN between 1024 to 3072. 
 * It is recommended not to set the time continuously. Developers had better set the time at system start up, and details are shown in Tutorial.
 */
unsigned char MTK_Translate_GPS_Time(
   unsigned int Date,
   unsigned int Time,
   float timeRMS,
   unsigned int *ReturnWN,
   unsigned int *ReturnTOW);
 /**
  * @}
  */

/**
  * @}
  */

/** @addtogroup sdk_struct Structures
  * @{
  */
/** @brief This structure defines UTC time.*/
typedef struct MTK_UTC
{
   unsigned char   Year;          /**< UTC time -- year. Year minus 2000.*/
   unsigned char   Month;         /**< UTC time -- month. Value is 1 ~ 12.*/
   unsigned char   Day;           /**< UTC time -- day. Value is 1 ~ 31.*/
   unsigned char   Hour;          /**< UTC time -- hour. Value is 0 ~ 23.*/
   unsigned char   Min;           /**< UTC time -- minute. Value is 0 ~ 59.*/
   unsigned char   Sec;           /**< UTC time -- second. Value is 0 ~ 59.*/
   unsigned short  MSec;          /**< RTC time -- smilli-second. Value is 0 ~ 999.*/
} MTK_UTC;                        
/**
  * @}
  */

/** @addtogroup sdk_function Function
  * @{
  */
  
/** @defgroup utilities Utilities
  * @{
  */
  
/**
 * @brief
 * Get Coordinated Universal Time (UTC) from the internal real-time clock. 
 * @param[out] pUTC ouput UTC data.
 * @note Before obtaining the first 3D fix, large scale time adjustments may
 *        happen. In the scenario, the time continuity is not guaranteed.
 * @par       Example
 * @code
 *     MTK_UTC utc;
 *     MTK_Get_UTC(&utc);
 *     MTK_UART_OutputData("Time=%02d:%02d:%02d.%03d", utc.Hour, utc.Min,
 *        utc.Sec, utc.MSec);
 * @endcode 
 */
void MTK_Get_UTC (MTK_UTC* pUTC);

/**
 * @brief
 * Set the fix rate of position fixes. The unit of fix rate is Hz. The maximal value is 10 Hz, and minimal value is 0.1 Hz. 
 * @param[in] FixRate Value of new fix-rate. The unit of FixRate is Hz. Range from 0.1Hz to 10Hz.
 * @return 
 * 1 --> If the new fix-rate is allowed. 
 * 0 --> The new fix-rate is NOT allowed or the setting is NOT successful. 
 * @note  If the data rate of NMEA sentences is larger than the NMEA baud rate at
 *        the specified fix update rate, it will return FALSE
 * @par       Example
 * @code
 *     float FixRate;
 *     MTK_Set_Fix_Rate(3.0);
 *     MTK_Get_Fix_Rate(&FixRate);
 *     MTK_NMEA_OutputData("SDK,FixRate,%.1f", FixRate);
 *    
 *     =====> $SDK,FixRate,3.0*04
  * @endcode 
 */
unsigned char MTK_Set_Fix_Rate(unsigned char FixRate);

/**
 * @brief
 * Get the fix rate of position fixes. The unit of fix rate is Hz. 
 * @param FixRate Value of fix-rate in the system. The unit of FixRate is Hz.
 * @return 
 * void 
 * @par       Example
 * @code
 *     float FixRate;
 *     MTK_Set_Fix_Rate(3.0);
 *     MTK_Get_Fix_Rate(&FixRate);
 *     MTK_NMEA_OutputData("SDK,FixRate,%.1f", FixRate);
 *    
 *     =====> $SDK,FixRate,3.0*04
 * @endcode 
 * @note
 * The default value of fix-rate is 1Hz.
 */
void MTK_Get_Fix_Rate(unsigned char *FixRate);
   
/** 
 * @brief
 * Get the execution state of the system. There are five states to describe the system state. 
 * @return Value : \n
 *     0: GPS_INVALID_EXE, Initial invalid state. Must be set before use.\n
 *     1: GPS_STARTUP, GPS is Initializing.\n
 *     2: GPS_RUNNING, GPS is Running normally.\n
 *     3: GPS_SLEEP, GPS is in a low power Sleep mode.\n
 *     4: GPS_RESTART, GPS is Re-Starting after sleep.\n
 * @note When this function is called, the return value are 0~5. The meaning 
 *       of the return value are listed above.
 * @par       Example
 * @code
 *     unsigned char exe_state;
 *     exe_state = MTK_Get_Execution_State();
 *     MTK_NMEA_OutputData("SDK,exe_state,%05d", exe_state);
 * 
 *     =====>  $SDK,exe_state,00001*3F
 * @endcode 
 */
unsigned char MTK_Get_Execution_State   (void);   

/**
 * @brief Get the number of visible satellites.
 * @param[out] SatsVisible Store the number of visible satellites.
 * @par       Example
 * @code
 *     unsigned char SatsVisible;
 *     MTK_Get_Sats_Visible   (&SatsVisible);
 *     MTK_NMEA_OutputData("SDK,Visible,%05d", SatsVisible);
 * 
 *     =====> $SDK,Visible,00010*21
 * @endcode 
 */
void MTK_Get_Sats_Visible   (unsigned char *SatsVisible);   

/**
 * @brief
 * Get the version of released program. This function will return the version number as following format: 
 * "Mcore_(MAJOR_VERSION).(MINOR_VERSION),(Build_ID)" 
 * @param[out] GpsRelease String of at least 14 characters to store the released version number. 
 * @return 
 * void 
 * @par Example
 * @code
 *     char s[14];
 *     MTK_GPS_Get_Release(s);
 *     MTK_NMEA_OutputData("SDK,Release,%s", s); 
 *      *  with Build_ID 9999 in CoreBuilder
 *     =====> $SDK,Release,SDK AXN_2.10_3339_1207301,0000*6C
 * @endcode 
 */
void MTK_GPS_Get_Release (char GpsRelease[30]);

/**
 * @brief
 * Get the health information of all satellites. \n
 * The default values are "1". That is, all satellites are healthy in default setting.
 * The value will be set to "0" only when the satellite is tracked and the health data in subframe is "unhealthy". 
 * @param[out] GpsHeath is an pointer with 32-bit unsigned integer format.
 *          When this function is called, the health information of all
 *          satellites (1 ~ 32) are list from LSB to MSB of GpsHealth.\n
 *          0 : unhealthy (tracked and the health data is unhealthy).\n
 *          1 : may not tracked or tracked with health data "healthy".\n
 * @return 
 * void 
 * @par       Example
 * @code
 *     unsigned int GpsHealth;
 *     MTK_Get_Sat_Health(&GpsHealth);
 *     MTK_NMEA_OutputData("SDK,GpsHealth,%8x", GpsHealth);
 * 
 *     =====> $SDK,GpsHealth,fffffffb*22
 *     Note that "fffffffb" means that SV3 is unhealthy. 
 * @endcode 
 */
void MTK_Get_Sat_Health (unsigned int *GpsHealth);

/**
 * @brief Get the tracked SV of GPS satellites.
 * @param[out] TrackedSV Tracked sats list.
 * @note   TrackedSV is arrays with 32 unsigned char. 
 * @par       Example
 * @code
 *     unsigned char TrackedSV[32];
 *     MTK_Get_Sat_Tracked(TrackedSV);
 *     MTK_UART_OutputData("SV17 Tracked or not = %d", TrackedSV[16]);
 *     
 *  =====> SV17 Tracked or not = 1 =====> 1 means SV17 is tracked, otherwise, it will show 0.
 * @endcode 
 */
void MTK_Get_Sat_Tracked (unsigned char TrackedSV[32]);

/**
 * @brief
 * Get the Azimuth and Elevation angles of all satellites. "Azim" and "Elev" are arrays with 32 signed char and signed short, respectively 
 * @param[out] Azim[32] The azimuth angles of all 32 satellites. 
 * @param[out] Elev[32] The elevation angles of all 32 satellites.
 * @return 
 * void 
 * @par Example
 * @code
 *     unsigned char count = 0;
 *     signed short Azim[32];
 *     signed char Elev[32];
 *     MTK_Get_Sat_AzEl(Azim, Elev);
 *     MTK_NMEA_OutputData("SDK,Azim%d,,%d",count, (int)(*(Azim+count)));
 *     MTK_NMEA_OutputData("SDK,Elev%d,%d",count, (int)(*(Elev+count)));
 *     count++;
 *     count = count % 32;
 * 
 * =====> $SDK,Azim7,,219*40
 *        $SDK,Elev7,32*52
 *        $SDK,Azim8,,-400*6C
 *        $SDK,Elev8,-99*71
 *        $SDK,Azim9,,-400*6D
 *        $SDK,Elev9,-99*70
 *        $SDK,Azim10,,39*46
 *        $SDK,Elev10,37*61
 *        $SDK,Azim11,,-400*54
 *        $SDK,Elev11,-99*49
 *        ...........
 *        //This example only show part of the print information
 * @endcode 
 * @note
 * The default value of azimuth and elevation angles are -400 and -99, respectively.
 */
void MTK_Get_Sat_AzEl (signed short Azim[32], signed char Elev[32]);

/**
 * @brief
 * Get the SNR of all satellites. SNR will be given in an array with 32 unsigned char. 
 * @param[out] SNR is arrays to save the SNR of 32 satellites.
 * @return 
 * void 
 * @par       Example
 * @code
 *     unsigned char SNR[32];
 *     MTK_Get_Sat_SNR(SNR);
 *      // Get SNR of SV 17
 *     MTK_UART_OutputData("SV17: SNR = %d", SNR[16]);
 *     
 *  =====> SV17: SNR = 38
 * @endcode 
 */
void MTK_Get_Sat_SNR (unsigned char SNR[32]);

/**
 * @brief Get the SVid of all satellites.
 * This function will tell user the status of all satellites whether they are visible or not. The status will save in an array with 32 unsigned char. 
 * @param[out] SVid is an array to save the status of 32 satellites.\n
 *              0       ---> This SV is Not Visible.\n
 *              1       ---> This SV is Visible.\n
 * @return 
 * void 
 * @par       Example
 * @code

 *     unsigned char SVid[32];
 *     MTK_Get_Sat_SVid(SVid);
 *      * Get SVid of SV
 *     MTK_UART_OutputData("SDK: SVid = %d", SVid[16]);
 *  =====> SDK: SVid = 1  ---> SV17 is visible. 
 * @endcode 
 */
void MTK_Get_Sat_SVid (unsigned char SVid[32]);

/**
 * @brief
 * Get the information of SBAS satellites about SVid, SNR, azimuth, elevation. 
 * @param[out] SVid Save the PRN number. \n
 * @param[out] SNR Save the SNR.
 * @param[out] Azim Save the azimuth.
 * @param[out] Elev Save the elevation.
 * @return Value : Number of SBAS satellite
 * @par       Example
 * @code
 *     unsigned char SVid[15];
 *     unsigned char SNR[15];
 *     signed short Azim[15];
 *     signed char Elev[15];
 *     int i, NumSbas = 0;
 *     NumSbas = MTK_Get_SBAS_Sat_Info(SVid, SNR, Azim, Elev); 
 *     for (i = 0; i < NumSbas ; i++)
 *     {
 *         MTK_UART_OutputData("SBAS SVid = %d SNR = %d Azim = %d Elev = %d", SVid[i], SNR[i], Azim[i], Elev[i]);
 *     }
 * @endcode 
 */
int MTK_Get_SBAS_Sat_Info (unsigned char SVid[15], unsigned char SNR[15], signed short Azim[15], signed char Elev[15]);

/**
 * @brief
 * Get the information whether satellites have ephemeris or not. The information will save in an array with 32 unsigned char.
 * @param[out] Eph save the information of all satellites.\n
 *              0       ---> This SV has no Ephemeris.\n
 *              1       ---> This SV has Ephemeris.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Eph[32];
 *     MTK_Get_Sat_Eph_Info(Eph);
 *     MTK_UART_OutputData("SDK: Eph = %d", Eph[16]);
 *  =====> SDK: Eph = 1  ---> SV17 has Ephemeris. 
 * @endcode 
 */
void MTK_Get_Sat_Eph_Info (unsigned char Eph[32]);


/**
 * @brief
 * Get the information whether satellites have almanac or not. The information will save in an array with 32 unsigned char.
 * @param[out] Alm save the information of all satellites.\n
 *              0       ---> This SV has no almanac.\n
 *              1       ---> This SV has almanac.\n
 * @par       Example
 * @code
 *     unsigned char Alm[32];
 *     MTK_Get_Sat_Alm_Info(Alm);
 *     MTK_UART_OutputData("SDK: Alm = %d", Alm[16]);
 *  =====> SDK: Alm = 1  ---> SV17 has Almanac. 
 * @endcode 
 */
void MTK_Get_Sat_Alm_Info (unsigned char Alm[32]);


/**
 * @brief
 * Get the information whether satellites have differential correction or not. The information will save in an array with 32 unsigned char.
 * @param[out] DGP_Status save the information of all satellites.\n
 *              0       ---> This SV has no Differential Correction.\n
 *              1       ---> This SV has Differential Correction.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char DGP_Status[32];
 *     MTK_Get_Sat_Eph_Info(DGP_Status);
 *     MTK_UART_OutputData("SDK: DGP_Status = %d", DGP_Status[16]);
 *
 *  =====> SDK: DGP_Status = 1  ---> SV17 has Differential Correction. 
 * @endcode 
 */
void MTK_Get_Sat_DGP_Status (unsigned char DGP_Status[32]);

/**
 * @brief Get the number of satellites used after fix.
 * @param[out] NumSatsUsed Store the number of satellites used after fix.
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char NumSatsUsed;
 *     MTK_Fix_Get_Num_Sats_Used (&NumSatsUsed);
 *     MTK_NMEA_OutputData("SDK,SV_Used,%05d", NumSatsUsed);
 * 
 *     =====> $SDK,SV_Used,00011*20
 *     In the above example, there are 11 satellites used for position fix.
 * @endcode 
 */
void MTK_Fix_Get_Num_Sats_Used (unsigned char *NumSatsUsed);

/**
 * @brief Get active satellites (used for fix calculation).
 * @param[out] SVid array to save information of all satellites.\n
 *              SVid[x]=0 ---> Satellite PRN 'x+1' is non-active.\n
 *              SVid[x]=1 ---> Satellite PRN 'x+1' is active.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SVid[32];
 *     MTK_Fix_Get_Sats_Used(SVid);
 *     MTK_UART_OutputData("SDK: SV#17 used=%d", SVid[16]);
 * @endcode 
 */
void MTK_Fix_Get_Sats_Used (unsigned char SVid[32]);

/**
 * @brief Get the DOP (Dilution of Precision) in 3-D position, horizontal, vertical, geometrical, and time.
 * @note The recommanded DOP is stored in DOPValue and use ChoosePHV to choose 
 *         which DOP value to get
 * @param[in] ChoosePHV type of DOP information which one need to get.\n
 *        ChoosePHV = #CHOOSE_PDOP -> get the 3-D position DOP.\n
 *        ChoosePHV = #CHOOSE_HDOP -> get the DOP in horizontal direction.\n
 *        ChoosePHV = #CHOOSE_VDOP -> get the DOP in vertical direction.\n
 *        ChoosePHV = #CHOOSE_GDOP -> get the Geometrical DOP.\n
 *        ChoosePHV = #CHOOSE_TDOP -> get the Time DOP.\n
 * @param[out] DOPValue The DOP value of user selected DOP mode.
 * @return 
 * void 
 * @par       Example
 * @code
 *     float DOPValueP,DOPValueH,DOPValueV;
 *     MTK_Get_DOP (CHOOSE_PDOP, &DOPValueP);
 *     MTK_Get_DOP (CHOOSE_HDOP, &DOPValueH);
 *     MTK_Get_DOP (CHOOSE_VDOP, &DOPValueV);
 *     MTK_Get_DOP (CHOOSE_HDOP, &DOPValueG);
 *     MTK_Get_DOP (CHOOSE_VDOP, &DOPValueT);
 *     MTK_NMEA_OutputData("SDK,PDOP,%f", DOPValueP);
 *     MTK_NMEA_OutputData("SDK,HDOP,%f", DOPValueH);
 *     MTK_NMEA_OutputData("SDK,VDOP,%f", DOPValueV);
 *     MTK_NMEA_OutputData("SDK,HDOP,%f", DOPValueG);
 *     MTK_NMEA_OutputData("SDK,VDOP,%f", DOPValueT);
 * 
 *     =====> $SDK,PDOP,1.985563*4E
 *            $SDK,HDOP,1.018353*5E
 *            $SDK,VDOP,1.704528*40
 *            $SDK,GDOP,1.555009*6A
 *            $SDK,TDOP,0.626787*7E
 * @endcode 
 */
void MTK_Get_DOP (unsigned char ChoosePHV, float *DOPValue);

/**
 * @brief Set HDOP Threshold function.
 * This function can set the threshold of HDOP by input a nonzero value. If input 0, the threshold of HDOP will be canceled.
 * @param HDOPThValue 0 = Cancled the HDOP value limitation.\n
 *               Other value = Set the HDOP Threshold.\n
 * @return 
 * void 
 * @par       Example
 * @code
 *     MTK_Set_HDOP_Threshold(1.0);
 * @endcode 
 */
void MTK_Set_HDOP_Threshold(float HDOPThValue);

/**
 * @brief Get HDOP Threshold function.
 * @return Value: HDOP Threshold Value
 * @par       Example
 * @code
 *     float temp;
 *     temp=MTK_Get_HDOP_Threshold();
 *     MTK_UART_OutputData("HDOP Value,%f\n",temp); 
 * @endcode 
 */
float MTK_Get_HDOP_Threshold(void);

/**
 * @brief Get Latitude and Longitude. 
 * This function can get the position information about latitude and longitude. User can get latitude and longitude information in radian unit by input DisplayMode = 0, or in degree/min unit like standard NMEA GGA sentence by input DisplayMode = 1.
 * @param[in] DisplayMode 0 -> output Latitude and Longitude in radian unit\n
 *                         1 -> output Latitude and Longitude in degree/min unit like standard NMEA GGA sentence\n
 * @param[out] Latitude latitude value.
 * @param[out] longitude value.
 * @param[out] LatDir  'N' for North, and 'S' for South
 * @param[out] LongDir 'E' for East, and 'W' for West         
 * @return 
 * void
 * @par       Example
 * @code
 *     double Latitude = 0.0f;
 *     double Longitude = 0.0f;
 *     unsigned char LatDir,LongDir;
 *     MTK_Get_Pos ( 1,&Latitude, &Longitude,&LatDir,&LongDir);
 *     MTK_NMEA_OutputData("SDK,Lat:%c%f,Long:%c%f",LatDir,Latitude,LongDir,Longitude);
 * 
 *     =====> $SDK,Lat:N2446.374069,Long:E12101.369866*1A
 * @endcode 
 */
void MTK_Get_Pos ( unsigned char DisplayMode, double *Latitude, double *Longitude,unsigned char *LatDir, unsigned char *LongDir);

/**
 * @brief
 * Get WGS84 altitude of the current position. Altitude unit is meter.
 * @param[out] Altitude WGS84 altitude of the current position.
 * @return 
 * void
 * @par       Example
 * @code
 *     double Altitude = 0.0f;
 *     MTK_Get_Altitude(&Altitude);
 *     MTK_NMEA_OutputData("SDK,Altitude:%f",Altitude);
 * 
 *     =====> $SDK,Altitude:184.748670*61
 * @endcode 
 */
void MTK_Get_Altitude (double *Altitude);

/**
 * @brief
 * Get mean sea level of the current position. Unit is meter.
 * @param[out] MSL mean sea level of the current position.
 * @return 
 * void
 * @par       Example
 * @code
 *     double MSL = 0.0f;
 *     MTK_Get_Mean_Sea_Level(&MSL);
 *     MTK_NMEA_OutputData("SDK,MSL:%f",MSL);
 * @endcode 
 */
void MTK_Get_Mean_Sea_Level (double *MSL);

/** 
 * @brief
 * Get mean sea level correction of current position (unit in meter) which is the same as "height of geoid" field of the GGA sentence.
 * mean_sea_level = WGS84_altitude - mean_sea_level_correction.
 * @param[out] geoid mean sea level of the current position.
 * @return 
 * void
 * @par       Example
 * @code
 *     double geoid = 0.0f;
 *     MTK_Get_Mean_Sea_Level_Correction(&geoid);
 *     MTK_NMEA_OutputData("SDK,geoid:%f",geoid);
 * @endcode 
 */
void MTK_Get_Mean_Sea_Level_Correction (double *geoid);

/**
 * @brief Get horizontal 2D speed (km/hr).
 * @param[out] SpeedH2D horizontal 2D speed (km/hr).
 * @return 
 * void
 * @par       Example
 * @code
 * 
 *     float SpeedH2D = 0;
 *     MTK_Get_Speed ( &SpeedH2D);
 *     MTK_NMEA_OutputData("SDK,Speed2D:%f",SpeedH2D);
 * 
 *     =====> $SDK,Speed2D:0.094191*62
 * @endcode 
 */
void MTK_Get_Speed ( float *SpeedH2D);
  
/**
 * @brief Get WGS84 ECEF X/Y/Z Velocity [m/s].
 * @param[out] Speed WGS84 ECEF X/Y/Z Velocity [m/s]
 * @par       Example
 * @code
 *     float Speed[3];    * Speed[0]: X-axis   Speed[1]:Y-axis   Speed[2]: Z-axis
 *     MTK_Get_ECEF_Speed (Speed);
 *     MTK_NMEA_OutputData("SDK, Vx:%.2f, Vy:%.2f, Vz:%.2f",Speed[0],Speed[1],Speed[2]);
 * 
 *     =====> $SDK,Vx:-0.14,Vy:0.24,Vz:2.35*53
 * @endcode 
 */
void MTK_Get_ECEF_Speed (float Speed[3]);
  
/**
 * @brief
 * Get the information of heading direction. The value of heading is a fractional number between 0 and 360.
 * @param[out] Heading The value of heading is fractional number between 0 to 360.
 * @return 
 * void
 * @par       Example
 * @code
 *     float Heading = 0;
 *     MTK_Get_Heading ( &Heading);
 *     MTK_NMEA_OutputData("SDK,heading:%f",Heading);
 * 
 *     =====> $SDK,heading:30.030000*3E
 * @endcode 
 */
void MTK_Get_Heading ( float *Heading);

/**
 * @brief
 * Get the fix type and fix mode. There are 4 Fix Modes and 3 Fix Types.
 * @param[out] FixMode  FIX_NONE 0     -> No fix (not enough SVs).\n
 *               FIX_ESTIMATE 1 -> Estimated mode (when SVs not enough after TTFF).\n
 *               FIX_GPS 2      -> Position fixed  .\n
 *               FIX_DIFF 3     -> Position fixed in DGPS mode.\n
 * 
 * @param[out] FixType  SV_NOFIX 0     -> no fix.\n
 *               SV_2DFIX 1     -> 2-dimensional fix.\n
 *               SV_3DFIX 2     -> 3-dimensional fix.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char fixtype = 0, fixmode =0;
 *     MTK_Get_FixStatus(&fixmode,&fixtype);
 *     MTK_NMEA_OutputData("SDK,mode:%d,type:%d",fixmode,fixtype);
 * 
 *     =====> $SDK,mode:2,type:2*45   *  3D-fix without DGPS
 *     =====> $SDK,mode:2,type:1*46   *  2D-fix without DGPS
 *     =====> $SDK,mode:1,type:0*44   *  not enough SVs, estimate position
 * @endcode 
 */
void MTK_Get_FixStatus ( unsigned char *FixMode, unsigned char *FixType);

/**
 * @brief
 * Get the duration since last DGPS update which is the same as the "dgps_age" field of the GGA sentence. The age unit is second.
 * @param[out] DGPS_Age output DGPS age. It is the same as the "dgps_age" field of the GGA sentence
 * @return 
 * void
 * @par       Example
 * @code
 *     float dgps_age;
 *     MTK_Get_DGPS_Age(&dgps_age);
 *     MTK_NMEA_OutputData("SDK,dgps_age:%f",dgps_age);
 *     =====> $SDK,mode:1,type:0*44   *  not enough SVs, estimate position
 * @endcode 
 */
void MTK_Get_DGPS_Age (float *DGPS_Age);

/**
 * @brief DGPS reference station ID number.
 * @param[out] StationID output DGPS reference station ID.
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned short dgps_id;
 *     MTK_Get_DGPS_StationID(&dgps_id);
 *     MTK_NMEA_OutputData("SDK,dgps_station_id:%d",dgps_id);
 * @endcode 
 */
void MTK_Get_DGPS_StationID (unsigned short *StationID);

/**
 * @brief Specify the timeout of the RTCM correction data.
 * @note If the differential correction mode is RTCM, the time-out
 *               value specifies the expiration time of the processed RTCM
 *               correction data.
 * @param[in] timeout the DGPS time-out value in seconds
 * @return 
 * void
 * @par Example
 * @code
 *     MTK_Set_DGPS_Timeout(60);   // DGPS time out is 60 seconds
 * @endcode 
 */
void MTK_Set_DGPS_Timeout (unsigned char timeout);

/**
 * @brief Set the NMEA port baud rate.
 * @param[in] baudrate baudrate in bps. Valid values are 4800, 9600, 14400, 19200,
 *         38400, 57600, 115200, 460800, 562500, 921600
 * @return  zero(fail), nonzero(pass)
 * @par Example
 * @code
 * MTK_Set_NMEA_BaudRate(115200);  // NMEA baud rate is 115200bps.
 * @endcode
 */
int  MTK_Set_NMEA_BaudRate (unsigned baudrate);

/**
 * @brief Nmea Data Modification Enable functions.
 * Enable user to modify NMEA data and set a flag to choose which type of NMEA sentence need to be modified. 
 * When Setting fgNmeaModifyBit to flag below, then the NMEA sentence modification of SDK_Modify_NMEA() is valid.
 * @param[in] fgNmeaModifyBit Flag to choose which type of NMEA sentence need to be modified.\n
 *    If multiple sentences need be modified, please integrate them by using "|" as same as the example below.\n
 *    #GPZDA_SET -> Set GPZDA sentense.\n
 *    #GPVTG_SET -> Set GPVTG sentense.\n
 *    #GPRMC_SET -> Set GPRMC sentense.\n
 *    #GPGSV_SET -> Set GPGSV sentense.\n
 *    #GPGSA_SET -> Set GPGSA sentense.\n
 *    #GPGLL_SET -> Set GPGLL sentense.\n
 *    #GPGGA_SET -> Set GPGGA sentense.\n
 * @return 
 * void 
 * @par       Example
 * @code
 *     unsigned char fgNmeaModifyBit;
 *     fgNmeaModifyBit = 0;
 *     fgNmeaModifyBit = fgNmeaModifyBit | GPGGA_SET | GPRMC_SET ;
 *     MTK_Nmea_Set_Enable(fgNmeaModifyBit);
 *     =====> GPRMC and GPGGA sentences can be modified in SDK_Modify_NMEA().
 * @endcode 
 * @note
 * This function should be called before using SDK_Modify_NMEA().
 */
void MTK_Nmea_Set_Enable(unsigned char fgNmeaModifyBit);

/**
 * @brief
 * User can use this function to choose whether use Beidou D2 correction data or not.
 * @param[in] UsedD2Corr user defined flag.\n
 *  UsedD2Corr =1, Enable D2 correction data.\n
 *  UsedD2Corr =0, Disable D2 correction data.\n
 * @return 
 * void
 * @par Example
 * @code
 *     unsigned char UsedD2Corr = 1;
 *     MTK_D2_Set_Enable(UsedD2Corr);  
 *     =====>Beidou D2 correction data will be used.
 * 
 * @endcode
 */
void MTK_D2_Set_Enable(unsigned char UsedD2Corr);


/**
 * @brief Set the output period of the NMEA sentences.
 * Set the output period of GLL, RMC, VTG, GSA, GSV, GGA, ZDA sentences.
 * By specified corresponding value of input array, user can choose these 7 sentences to output every fix or every two fix.
 * @param[in] period Corresponding to seven sentences.\n
 *     period[0]: GLL period\n
 *     period[1]: RMC period\n
 *     period[2]: VTG period\n
 *     period[3]: GSA period\n
 *     period[4]: GSV period\n
 *     period[5]: GGA period\n
 *     period[6]: ZDA period\n
 * @note For example, setting the period value to 1 means this sentence will
 *     appear every fix, 2 means the sentence appears every two fixes.\n
 *     Setting the period to 0 will disable the sentence.
 * @par       Example
 * @code
 *     char period[7] = {1, 1, 1, 1, 1, 1, 0};
 *     MTK_NMEA_Set_Output_Period(period);
 * =====> GLL, RMC, VTG, GSA, GSV, GGA sentences will appear every fix. ZDA sentence will not appear.
 * @endcode 
 */
void MTK_NMEA_Set_Output_Period (const unsigned char period[7]);

/**
 * @brief Disable the NMEA output.
 * Use this function to disable all NMEA sentences output if NMEA sentence is undesired.
 * @return 
 * void
 * @par Example
 * @code
 *  MTK_NMEA_Output_Disable () 
 *  =====> The UART port will not output any NMEA sentence.
 * @endcode
 */
void MTK_NMEA_Output_Disable (void);
/**
  * @}
  */

/** @defgroup uart UART
  * @{
  */
/**
 * @brief
 * This function is used to check if the UART Tx is idle. 
 * @return 
 * zero: busy.
 * nonzero: idle; UART Tx buffer is empty.
 */
int MTK_UART_Tx_Idle (void);

/**
 * @brief
 * This function is used to check if the Data Port UART Tx is idle. 
 * @return  
 * zero: busy.
 * nonzero: idle; Data Port UART Tx buffer is empty.
 */
int MTK_DPort_Tx_Idle (void);
/**
  * @}
  */

/** @defgroup phase_out Phase out
  * @{
  */  
/**
 * @brief Phase out
 */
int MTK_Is_UART_Output_By_BT (void);

/**
 * @brief Phase out.
 */
int MTK_Set_GpsCanOff (unsigned char GpsCanOff );

/**
 * @brief Phase out.
 */
unsigned char MTK_Get_GpsCanOff (void);

/**
 * @brief Phase out.
 */
int MTK_Set_BtCanLink (unsigned char BtCanLink);

/**
 * @brief Phase out.
 */
unsigned char MTK_Get_BtCanLink (void);

/**
 * @brief  Phase out.
 */
int MTK_Get_BT_Status (void);

/**
 * @brief  Phase out.
 */
void MTK_Set_BtGpsOff_Time (unsigned int BtGpsOffTime, unsigned int BtInitGpsOffTime);
/**
  * @}
  */

/** @defgroup uart UART
  * @{
  */
  
/**
 * @brief  Set an indictor to start UART TX ouput completed check.\n 
 *         MTK_Set_UART_TX_Monitor should always called before use MTK_Get_UART_TX_Status.\n
 * @param UART_TX_Check_Stat An indictor to show UART TX ouptu check status
 *                           zero     : disable UART TX output check
 *                           non zero : enable  UART TX ouput completed check
 *         PortNum  The port can set to 0,1,2,3,7,8,9,10,11,12,13,15
 *                     The GIO will pull low after TX output finished.
 * @return  1 : setting OK.\n
 *            0 : setting NG\n
 * @par       Example
 * @code
 *     unsigned char UART_TX_Check_Stat = 1;
 *     unsigned char fgsetOK = 0;
 *     unsigned int GIOasTXInd = 0x0002; 
 *     fgsetOK = MTK_Set_UART_TX_Monitor(UART_TX_Check_Stat,GIOasTXInd);
 *     // Use GIO 1 as TX indictor
  * @endcode
 */
unsigned char MTK_Set_UART_TX_Monitor (unsigned char UART_TX_Check_Stat,unsigned char PortNum);

/**
 * @brief
 * Return the UART TX output status. Parameter will be set as 1 while UART TX output complete and as 0 while not complete. 
 * @note The function MTK_Set_UART_TX_Monitor must be called before using this function. 
 * @param UART_TX_empty  0 : UART TX output not finished\n
 *                           1 : UART TX output completed
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char UART_TX_Check_Stat = 1;
 *     unsigned char fgsetOK = 0;
 *     unsigned char PortNum = 1; 
 *     volatile unsigned char UART_TX_empty = 0;
 * 
 *     // set TX output monitor before TX send completed
 *     fgsetOK = MTK_Set_UART_TX_Monitor(UART_TX_Check_Stat,PortNum);
 *     MTK_NMEA_OutputData("SDK,fgsetOK,%d", fgsetOK);
 * 
 *     UART_TX_empty  = 0;
 *     //wait TX output finished
 *     do
 *     {
 *        MTK_Get_UART_TX_Status(&UART_TX_empty);
 *     }
 *     while (UART_TX_empty == 0)
 * @endcode
 */
void MTK_Get_UART_TX_Status (unsigned char *UART_TX_empty);
/**
  * @}
  */
  
/** @defgroup utilities Utilities
  * @{
  */
    
/**
 * @brief
 * User can choose whether to speed up the processor or not by set an input flag. "Turbo mode" mearns speed up the processor to the maximum (faster processing speed; but higher power consumption). "Normal mode" is the normal operation mode.
 * @param[in] bTurbo     TRUE=turbo,  FALSE=normal
 * @return 
 * void
 * @par Example
 * @code
 * int bTurbo = 1;
 * MTK_Set_Turbo_Mode (bTurbo);
 * =====> Processor will work in Turbo mode.
 * 
 * @endcode
 */
void MTK_Set_Turbo_Mode (int bTurbo);

/**
 * @brief
 * Get the free stack space for use by the SDK application software. The unit is byte.
 * @return 
 *     return how many free spaces in stack.
 * @par       Example
 * @code
 *     int stksize = MTK_Get_Avail_Stack();
 *     if (stksize <= 0)
 *     {
 *        MTK_NMEA_OutputData("Available stack: %d", stksize);
 *     }
 * @endcode
 */
int MTK_Get_Avail_Stack (void);

/**
 * @brief  Get the time when the SDK FW was built.
 *         The primary purpose for this function is version control.
 * @param  utc output build time in structure format.
 * @param  szTime output build time in yyyymmddhhmm format.
 * @note   'utc' and 'szTime' parameter can be NULL
 */
void MTK_Get_BuildTime (MTK_UTC* utc, char szTime[16]);
/**
  * @}
  */
  
/** @defgroup phase_out Phase out
  * @{
  */
    
/**
 * @brief  Phase out.
 */
int MTK_Set_BaudRate_Base (int multiply);
/**
  * @}
  */
 
/** @defgroup utilities Utilities
  * @{
  */

/**
 * @brief
 * Bypass checksum in UART receiving (binary protocol).
 * @param[in]  fgBypass  flag to determine whether bypass checksum or not.
 * 1-> bypass; 0 -> check checksum  
 * @return 
 * 1    -->    succeeded
 * 0    -->    failed
 */
int MTK_Set_BypassChecksum(unsigned char fgBypass);

/**
 * @brief
 * Get estimated position error in both horizontal and vertical direction. The unit is meters. 
 * @param[out]   EPE_2D   Estimated horizontal position error.\n
 * @param[out]   EPE_Vert Estimated vertical position error.
 * @return 
 * void
 * @par Example
 * @code
 * float EPE_2D;
 * float EPE_Vert;
 * MTK_Get_EPE (&EPE_2D, &EPE_Vert);
 * @endcode
 */
void MTK_Get_EPE (float *EPE_2D, float *EPE_Vert);

/**
 * @brief  Set type of intelligent power saving mode.
 * User can use this function to choose whether let chip work in intelligent power saving mode or not.  If input Type is 1, power saving mode will be enable. No power saving mode will be chosen while input Type is 0.

 * @param[in]  Type  Types of Intelligent power saving mode.
 * 1   -->   power saving mode
 * 0   -->   no power saving
 * @return 
 * 1   -->   succeed
 * 0   -->   fail
 * @par Example
 * @code
 * int Type = 1;
 * MTK_Set_Intelligent_PowerSaving (Type);
 * Result:
 * > Result
 * -->   chip will work in power saving mode.
 * 
 * 
 * @endcode
 */
int MTK_Set_Intelligent_PowerSaving (int Type);

/**
 * @brief  Get type of intelligent power saving mode.
 * @return  return current intelligent power saving mode            
 * 1   -->   power saving mode
 * 0   -->   no power saving
 * @par Example
 * @code
 * int SetType = 1;
 * int GetType;
 * MTK_Set_Intelligent_PowerSaving (Type);
 * GetType = MTK_Set_Intelligent_PowerSaving ();
 * MTK_UART_OutputData("***Type is %d***", GetType);
 * Result:
 * -->   ***Type is 1***
 * 
 * @endcode
 */
int MTK_Get_Intelligent_PowerSaving (void);

/**
 * @brief  Bypass checksum in Data Port receiving (binary protocol).
 * @param  fgBypass  flag to determine whether bypass checksum or not.\n
 * @return 
 * 1    -->    succeeded
 * 0    -->    failed
 */
int MTK_Set_BypassDPortChecksum(unsigned char fgBypass);

/**
 * @brief  Set SDK in SDK Acc mode. This mode will disable the functions and only SDK function user defined will run.
 * @param  fgAcc  flag to determine whether work in SDK Acc mode or not. \n
 * 1-> SDK Acc mode; 0 -> normal mode   
 * @return 
 * 1    -->    succeeded
 * 0    -->    failed
 */
int MTK_Set_SdkAcc(unsigned char fgAcc);
/**
  * @}
  */
  
  
/** @defgroup uart UART
  * @{
  */
/**
 * @brief
 * Set the operation mode of Data Port. 
 * @param    ucInType   set input type.\n
 *                      0 ==> No input\n
 *                      1 ==> RTCM In\n
 *                      3 ==> UART In\n
 * @param    ucOutType  set output type.\n
 *                      0 ==> No output\n
 *                      3 ==> UART Out\n
 * @param    baudrate:   4800, 9600, 14400, 19200, 38400, 57600, 115200, 230400, 460800, 921600   \n 
 * @return 
 * nonzero   -->   success
 * zero      -->   failure
 * @par Example
 * @code
 * MTK_Set_DPort (1,3,115200);
 * Result:
 * -->    Data port will be set in RTCM in, NMEA out, and baud rate is 115200bps.
 * @endcode
 */
int MTK_Set_DPort(unsigned char ucInType, unsigned char ucOutType, unsigned int baudrate);
/**
  * @}
  */
  
/** @defgroup utilities Utilities
  * @{
  */
  
/**
 * @brief  Get Leap second information.
 * @param[in]    SVType  0 --> GPS, 1 --> Beidou, default --> GPS
 * @param[out] PreLeapSecond  Current leap second\n 
 * @param[out] UpdateLeapSecond  Next leap second\n 
 * @param[out] LeapSecondStatus  Leap indicator, 1 means updated from broadcast data\n 
 * @return value  0: fail to get leap second, 1: setting success
 */
int MTK_Get_LEAP_SECOND_INFO(unsigned int SVType, unsigned int* PreLeapSecond, unsigned int* UpdateLeapSecond, unsigned int* LeapSecondStatus);
/**
  * @}
  */
  

/** @defgroup phase_out Phase out
  * @{
  */  
/**
 * @brief Phase out
 */
void MTK_Get_GLON_KP_WORD(unsigned char* KP);
/**
  * @}
  */

/** @defgroup utilities Utilities
  * @{
  */
/**
 * @brief  Set RTC timer interval.
 * @param    uTriggerType 0 : External\n
 *                        1 : Reserved
 * @param    uInternal   0~2047000 (msec)
 * @return         0   : Successfully\n
 *                 1   : Config RTC timer write failed \n
 *                 2   : Config RTC timer trigger failed\n
 */
int MTK_Set_RTC_Timer(unsigned char uTriggerType, unsigned int uInternal);


/**
 * @brief  Get RTC Time from MTK Chip.
 * @param[out] RTC  output RTC information. If successfully read RTC, return a non-zero value
 * @return 
 * true   :  succeed
 * false  :  fail 
 * @par       Example
 * @code
 *     int Status;
 *     s_MTK_RTC_T RTC;
 *     Status = MTK_Get_RTC_Time(&RTC);
 *     if (Status > 0)
 *     {
 *        MTK_NMEA_OutputData("SDK,RTC,Year,%d,Month,%d,Day,%d,Hour,%d,Min,%d,Sec,%d",
 *        RTC.ucYEAR,RTC.ucMONTH,RTC.ucDAY,RTC.ucHOUR,RTC.ucMIN,RTC.ucSEC );
 *     }
 * @endcode
 */
int MTK_Get_RTC_Time (s_MTK_RTC_T *RTC);


/**
 * @brief  Get the health information of all QZSS satellites.
 * @note   The default values of all satellites are healthy. That is, 
 *          all the health values are "1". The value will be set to "0"
 *          only when the satellite is tracked and the health data in 
 *          subframe is "unhealthy"
 * 
 * @param[out] QZSSHealth output health information of QZSS satellites.\n
 *          When this function is called, the health information of all
 *          satellites (1 ~ 5) are list from LSB to MSB of GpsHealth.\n
 *          0 : unhealthy (tracked and the health data is unhealthy)\n
 *          1 : may not tracked or tracked with health data "healthy"\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned int QZSSHealth;
 *     MTK_Get_QZSS_Sat_Health(&QZSSHealth);
 *     MTK_NMEA_OutputData("SDK,GpsHealth,%8x", QZSSHealth);
 * 
 *     =====> $SDK,GpsHealth,fffffffb*22
 * @endcode
 */
void MTK_Get_QZSS_Sat_Health (unsigned int *QZSSHealth);


/**
 * @brief   Get the Azimuth and Elevation angles of all QZSS satellites.
 * @param[out]   Azim output Azimuth of all QZSS satellites. 
 * @param[out]   Elev output Elevation of all QZSS satellites. 
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char count = 0;
 *     signed short Azim[5];
 *     signed char Elev[5];
 *     MTK_Get_QZSS_Sat_AzEl(Azim, Elev);
 *     MTK_NMEA_OutputData("SDK,Azim%d,%d",count, (int)(*(Azim+count)));
 *     MTK_NMEA_OutputData("SDK,Elev%d,%d",count, (int)(*(Elev+count)));
 *     count++;
 *     count = count % 5;
 * 
 * =====> $SDK,Azim1,219*40
 *        $SDK,Elev1,32*52
 *        $SDK,Azim2,-400*6C
 *        $SDK,Elev2,-99*71
 *        $SDK,Azim3,-400*6D
 *        $SDK,Elev3,-99*70
 *        $SDK,Azim4,-400*46
 *        $SDK,Elev4,-99*61
 *        $SDK,Azim5,-400*54
 *        $SDK,Elev5,-99*49
 *        ...........
 * // This example only show part of the print information
 * @endcode
 */
void MTK_Get_QZSS_Sat_AzEl (signed short Azim[5], signed char Elev[5]);


/**
 * @brief   Get the accurate SNR of all QZSS satellites.
 * @param[out]   SNR output accurate SNR of all QZSS satellites.. 
 * @return 
 * void
 * @par       Example
 * @code
 *     float SNR[5];
 *     MTK_Get_QZSS_Sat_Accurate_SNR(SNR);
 *     //Get SNR of SV 1
 *     MTK_UART_OutputData("QZSS,SV1: SNR = %lf", SNR[0]);
 *     
 *  =====>QZSS,SV1: SNR = 38.1
 * @endcode
 */
void MTK_Get_QZSS_Sat_Accurate_SNR ( float SNR[5]);


/**
 * @brief   Get the SNR of all QZSS satellites.
 * @param[out]   SNR output SNR of all QZSS satellites. 
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SNR[5];
 *     MTK_Get_QZSS_Sat_SNR(SNR);
 *      // Get SNR of SV 1
 *     MTK_UART_OutputData("QZSS,SV1: SNR = %d", SNR[0]);
 *     
 *  =====>QZSS,SV1: SNR = 38
 * @endcode
 */
void MTK_Get_QZSS_Sat_SNR (unsigned char SNR[5]);


/**
 * @brief   Get the SVid of all QZSS satellites.
 * This function will tell user the status of all QZSS satellites whether they are visible or not. The status will save in an array with 5 unsigned char.
 * @param[out]  SVid array to save the status of all QZSS satellites.\n
 *              0       ---> This SV is Not Visible.\n
 *              1       ---> This SV is Visible.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SVid[5];
 *     MTK_Get_QZSS_Sat_SVid(SVid);
 *      // Get SVid of SV
 *     MTK_UART_OutputData("SDK: QZSS#1,SVid = %d", SVid[5]);
 *  =====> SDK: QZSS#1,SVid = 1  ---> SV17 is visible. 
 * @endcode
 */
void MTK_Get_QZSS_Sat_SVid (unsigned char SVid[5]);


/**
 * @brief
 * Get the tracking status of all QZSS satellites. CodeLock, FreqLock and CarrLock are the arrays with 5 unsigned char which are corresponding to 5 QZSS satellites.
 * @param[out] CodeLock[5]:   0 --> no tracking      1  -->  tracking
 * @param[out] FreqLock[5]:    0 --> no tracking      1  -->  tracking
 * @param[out] CarrLock[5]:    0 --> no tracking      1  -->  tracking
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char CodeLock[5],FreqLock[5],CarrLock[5];
 *     MTK_Get_QZSS_Tracking_Status(CodeLock,FreqLock,CarrLock);
 *     // Get tracking status of SV
 *     MTK_UART_OutputData("SDK: QZSS#1,CodeLock = %d FreqLock = %d CarrLock = %d", CodeLock[0],CodeLock[0],CodeLock[0]);
 *
 *  =====> SDK: QZSS#1,CodeLock = 1 FreqLock = 1 CarrLock = 0  
 *         ---> SV1's Code and Freq are in tracking state, but carrier is not in tracking state. 
 * @endcode
 */
void MTK_Get_QZSS_Tracking_Status (unsigned char CodeLock[5],unsigned char FreqLock[5],unsigned char CarrLock[5]);


/**
 * @brief
 * Get the information whether satellites has Ephemeris or not. Eph is arrays with 5 unsigned char which are corresponding to 5 QZSS satellites.
 * @param[out]  Eph output flags of ephemeris information.\n
 *              0       ---> This SV has no Ephemeris.\n
 *              1       ---> This SV has Ephemeris.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Eph[5];
 *     MTK_Get_QZSS_Sat_Eph_Info(Eph);
 *     MTK_UART_OutputData("SDK: Eph#1 = %d", Eph[0]);
 *
 *  =====> SDK: QZSS,Eph#1 = 1  ---> QZSS#1 has Ephemeris. 
 * @endcode
 */
void MTK_Get_QZSS_Sat_Eph_Info (unsigned char Eph[5]);



/**
 * @brief
 * Get the information whether QZSS satellites has Almanac or not. Alm is arrays with 5 unsigned char which are corresponding to 5 QZSS satellites.
 * @param[out]   Alm output flags of Almanac information.\n
 *              0       ---> This SV has no almanac.\n
 *              1       ---> This SV has almanac.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Alm[5];
 *     MTK_Get_QZSS_Sat_Alm_Info(Alm);
 *     MTK_UART_OutputData("SDK: QZSS,Alm#1 = %d", Alm[0]);
 *
 *  =====> SDK: QZSS,Alm#1 = 1  ---> QZSS#1 has Almanac. 
 * @endcode
 */
void MTK_Get_QZSS_Sat_Alm_Info (unsigned char Alm[5]);


/**
 * @brief
 * Get active QZSS satellites (used for fix calculation). SVid is an array with 5 unsigned chars which are corresponding to 5 QZSS satellites.
 * @param[out]   SVid output status of active QZSS satellites.\n
 *              SVid[x]=0 ---> Satellite PRN 'x+1' is non-active\n
 *              SVid[x]=1 ---> Satellite PRN 'x+1' is active\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SVid[5];
 *     MTK_Fix_Get_QZSS_Sats_Used(SVid);
 *     MTK_UART_OutputData("SDK: QZSS,SV#1 used=%d", SVid[0]);
 * @endcode
 */
void MTK_Fix_Get_QZSS_Sats_Used (unsigned char SVid[5]);


/**
 * @brief Get the health information of all GLONASS satellites.\n
 * The default values of all satellites are healthy. That is, 
 *          all the health values are "1". The value will be set to "0"
 *          only when the satellite is tracked and the health data in 
 *          subframe is "unhealthy".
 * @param[out] health is an pointer with 32-bit unsigned integer format.\n
 *          When this function is called, the health information of all
 *          satellites (1 ~ 24) are list from LSB to MSB of health\n
 *          0 : unhealthy (tracked and the health data is unhealthy)\n
 *          1 : may not tracked or tracked with health data "healthy"\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned int health;
 *     MTK_Get_GLON_Sat_Health(&health);
 *     MTK_NMEA_OutputData("SDK,GlonHealth,%8x", health);
 * 
 *     =====> $SDK,GlonHealth,0000fffb*22
 * @endcode
 */
void MTK_Get_GLON_Sat_Health (unsigned int *health);

/**
 * @brief   Get the tracked SV of GLONASS satellites.
 * @param   TrackedSV is arrays with 24 unsigned char. 
 * @par       Example
 * @code
 *     unsigned char TrackedSV[24];
 *     MTK_Get_GLON_Sat_Tracked(TrackedSV);
 *     MTK_UART_OutputData("SV12 Tracked or not = %d", TrackedSV[11]);
 *     
 *  =====> SV12 Tracked or not = 1 =====> 1 means SV12 is tracked, otherwise, it will show 0.
 * @endcode
 */
void MTK_Get_GLON_Sat_Tracked (unsigned char TrackedSV[24]);

/**
 * @brief
 * Get the Azimuth and Elevation angles of all GLONASS satellites. 
 * "Azim" and "Elev" are arrays with 24 signed char and signed short which are corresponding to 24 GLONASS satellites.
 * @param[out]   Azim output azimuth. 
 * @param[out]   Elev output elevation. 
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char count = 0;
 *     signed short Azim[24];
 *     signed char Elev[24];
 *     MTK_Get_GLON_Sat_AzEl(Azim, Elev);
 *     MTK_NMEA_OutputData("SDK,Azim%d,%d",count, (int)(*(Azim+count)));
 *     MTK_NMEA_OutputData("SDK,Elev%d,%d",count, (int)(*(Elev+count)));
 *     count++;
 *     count = count % 24;
 * 
 * =====> $SDK,Azim1,219*40
 *        $SDK,Elev1,32*52
 *        $SDK,Azim2,-400*6C
 *        $SDK,Elev2,-99*71
 *        $SDK,Azim3,-400*6D
 *        $SDK,Elev3,-99*70
 *        $SDK,Azim4,-400*46
 *        $SDK,Elev4,-99*61
 *        $SDK,Azim5,-400*54
 *        $SDK,Elev5,-99*49
 *        ...........
 * //This example only show part of the print information
 * @endcode
 */
void MTK_Get_GLON_Sat_AzEl (signed short Azim[24], signed char Elev[24]);


/**
 * @brief   Get the SNR of all GLONASS satellites.
 * @param   SNR output SNR of all GLONASS satellites.
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SNR[24];
 *     MTK_Get_GLON_Sat_SNR(SNR);
 *      * Get SNR of SV 1
 *     MTK_UART_OutputData("GLON,SV1: SNR = %d", SNR[0]);
 *     
 *  =====>GLON,SV1: SNR = 38
 * @endcode
 */
void MTK_Get_GLON_Sat_SNR (unsigned char SNR[24]);


/**
 * @brief   Get the SVid of all GLONASS satellites.
 * This function will tell user the status of all GLONASS satellites whether they are visible or not. The status will save in an array with 24 unsigned char.
 * @param[out] SVid array to save the status of all GLONASS satellites.\n
 *              0       ---> This SV is Not Visible.\n
 *              1       ---> This SV is Visible.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SVid[24];
 *     MTK_Get_GLON_Sat_SVid(SVid);
 *      // Get SVid of SV
 *     MTK_UART_OutputData("SDK: GLON#1,SVid = %d", SVid[23]);
 *  =====> SDK: GLON#1,SVid = 1  ---> SV24 is visible. 
 * @endcode
 */
void MTK_Get_GLON_Sat_SVid (unsigned char SVid[24]);


/**
 * @brief
 * Get the information whether satellites has Ephemeris or not. Eph is arrays with 24 unsigned char which are corresponding to 24 GLONASS satellites.
 * @param[out]   Eph output flags of ephemeris information.\n
 *              0       ---> This SV has no Ephemeris.\n
 *              1       ---> This SV has Ephemeris.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Eph[24];
 *     MTK_Get_GLON_Sat_Eph_Info(Eph);
 *     MTK_UART_OutputData("SDK: Eph#1 = %d", Eph[0]);
 *
 *  =====> SDK: GLON,Eph#1 = 1  ---> GLON#1 has Ephemeris. 
 * @endcode
 */
void MTK_Get_GLON_Sat_Eph_Info (unsigned char Eph[24]);


/**
 * @brief
 * Get the information whether GLONASS satellites has Almanac or not. \n
 * Alm is arrays with 24 unsigned char which are corresponding to 24 GLONASS satellites.
 * @param[out]   Alm output flags of Almanac information.\n
 *              0       ---> This SV has no almanac.\n
 *              1       ---> This SV has almanac.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Alm[24];
 *     MTK_Get_GLON_Sat_Alm_Info(Alm);
 *     MTK_UART_OutputData("SDK: GLON,Alm#1 = %d", Alm[0]);
 *
 *  =====> SDK: GLON,Alm#1 = 1  ---> GLON#1 has Almanac. 
 * @endcode
 */
void MTK_Get_GLON_Sat_Alm_Info (unsigned char Alm[24]);


/**
 * @brief
 * Get active GLONASS satellites (used for fix calculation). SVid is an array with 24 unsigned chars which are corresponding to 24 GLONASS satellites.
 * @param[out]   SVid output status of active GLONASS satellites.\n
 *              SVid[x]=0 ---> Satellite PRN 'x+1' is non-active\n
 *              SVid[x]=1 ---> Satellite PRN 'x+1' is active\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SVid[24];
 *     MTK_Fix_Get_GLON_Sats_Used(SVid);
 *     MTK_UART_OutputData("SDK: GLON,SV#1 used=%d", SVid[0]);
 * @endcode
 */
void MTK_Fix_Get_GLON_Sats_Used (unsigned char SVid[24]);


/**
 * @brief Get the health information of all GALILEO satellites.\n
 * The default values of all satellites are healthy. That is, 
 *          all the health values are "1". The value will be set to "0"
 *          only when the satellite is tracked and the health data in 
 *          subframe is "unhealthy"
 * @param  health is an pointer with 32-bit unsigned integer format.\n
 *          When this function is called, the health information of all
 *          satellites (1 ~ 53) are list from LSB to MSB of health\n
 *          0 : unhealthy (tracked and the health data is unhealthy)\n
 *          1 : may not tracked or tracked with health data "healthy"\n
 * @par       Example
 * @code
 *     unsigned int health;
 *     MTK_Get_GLEO_Sat_Health(&health);
 *     MTK_NMEA_OutputData("SDK,health,%8x", health);
 * 
 *     =====> $SDK,health,0000fffb*22
 * @endcode
 */
void MTK_Get_GLEO_Sat_Health (unsigned int *health);


/**
 * @brief   Get the Azimuth and Elevation angles of all GALILEO satellites.
 * @param   Azim is arrays with [30] signed char and signed short, respectively
 * @param   Elev is arrays with [30] signed char and signed short, respectively
 * @par       Example
 * @code
 *     unsigned char count = 0;
 *     signed short Azim[30];
 *     signed char Elev[30];
 *     MTK_Get_GLEO_Sat_AzEl(Azim, Elev);
 *     MTK_NMEA_OutputData("SDK,Azim%d,%d",count, (int)(*(Azim+count)));
 *     MTK_NMEA_OutputData("SDK,Elev%d,%d",count, (int)(*(Elev+count)));
 *     count++;
 *     count = count % 30;
 * 
 * =====> $SDK,Azim1,219*40
 *        $SDK,Elev1,32*52
 *        $SDK,Azim2,-400*6C
 *        $SDK,Elev2,-99*71
 *        $SDK,Azim3,-400*6D
 *        $SDK,Elev3,-99*70
 *        $SDK,Azim4,-400*46
 *        $SDK,Elev4,-99*61
 *        $SDK,Azim5,-400*54
 *        $SDK,Elev5,-99*49
 *        ...........
 * //This example only show part of the print information
 * @endcode
 */
void MTK_Get_GLEO_Sat_AzEl (signed short Azim[30], signed char Elev[30]);


/**
 * @brief   Get the SNR of all GALILEO satellites.
 * @param   SNR is arrays with [30] unsigned char.
 * @par       Example
 * @code
 *     unsigned char SNR[30];
 *     MTK_Get_Sat_SNR(SNR);
 *      * Get SNR of SV 1
 *     MTK_UART_OutputData("GLEO,SV1: SNR = %d", SNR[0]);
 *     
 *  =====>GLEO,SV1: SNR = 38
 * @endcode
 */
void MTK_Get_GLEO_Sat_SNR (unsigned char SNR[30]);


/**
 * @brief   Get the SVid of all GALILEO satellites.
 * @param   SVid is an array with [30] unsigned char.\n
 *              0       ---> This SV is Not Visible.\n
 *              1       ---> This SV is Visible.\n
 * @par       Example
 * @code
 *     unsigned char SVid[30];
 *     MTK_Get_GLEO_Sat_SVid(SVid);
 *      * Get SVid of SV
 *     MTK_UART_OutputData("SDK: GLEO#1,SVid = %d", SVid[30]);
 *  =====> SDK: GLEO#1,SVid = 1  ---> SV17 is visible. 
 * @endcode
 */
void MTK_Get_GLEO_Sat_SVid (unsigned char SVid[30]);



/**
 * @brief   Get the information whether satellites has Ephemeris or not.
 * @param   Eph is arrays with [30] unsigned char.\n
 *              0       ---> This SV has no Ephemeris.\n
 *              1       ---> This SV has Ephemeris.\n
 * @par       Example
 * @code
 *     unsigned char Eph[30];
 *     MTK_Get_GLEO_Sat_Eph_Info(Eph);
 *     MTK_UART_OutputData("SDK: Eph#1 = %d", Eph[0]);
 *  =====> SDK: GLEO,Eph#1 = 1  ---> GLEO#1 has Ephemeris. 
 * @endcode
 */
void MTK_Get_GLEO_Sat_Eph_Info (unsigned char Eph[30]);


/**
 * @brief   Get the information whether GALILEO satellites has Almanac or not.
 * @param   Alm is arrays with [30] unsigned char.\n
 *              0       ---> This SV has no almanac.\n
 *              1       ---> This SV has almanac.\n
 * @par       Example
 * @code
 *     unsigned char Alm[30];
 *     MTK_Get_GLEO_Sat_Alm_Info(Alm);
 *     MTK_UART_OutputData("SDK: GLEO,Alm#1 = %d", Alm[0]);
 *  =====> SDK: GLEO,Alm#1 = 1  ---> GLEO#1 has Almanac. 
 * @endcode
 */
void MTK_Get_GLEO_Sat_Alm_Info (unsigned char Alm[30]);


/**
 * @brief  get active GALILEO satellites (used for fix calculation).
 * @param   Used is an array with [30] unsigned chars.\n
 *              used[x]=0 ---> Satellite PRN 'x+1' is non-active\n
 *              used[x]=1 ---> Satellite PRN 'x+1' is active\n
 * @par       Example
 * @code
 *     unsigned char used[30];
 *     MTK_Fix_Get_GLEO_Sats_Used(used);
 *     MTK_UART_OutputData("SDK: GLEO,SV#1 used=%d", used[0]);
 * @endcode
 */
void MTK_Fix_Get_GLEO_Sats_Used (unsigned char Used[30]);


 
/**
 * @brief Get the health information of all BEIDOU satellites.\n
 * The default values of all satellites are healthy. That is, 
 *          all the health values are "1". The value will be set to "0"
 *          only when the satellite is tracked and the health data in 
 *          subframe is "unhealthy"
 * 
 * @param[out]   health is an pointer with 337 unsigned char.\n
 *          When this function is called, the health information of all
 *          satellites (1 ~ 37) are list in the health array.\n
 *          0 : unhealthy (tracked and the health data is unhealthy)\n
 *          1 : may not tracked or tracked with health data "healthy"\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char health[37];
 *     MTK_Get_BEDO_Sat_Health(health);
 *     MTK_NMEA_OutputData("SDK,SV1,health,%d", health[0]);
 * 
 *     =====> $SDK,SV1,1
 * @endcode
 */
void MTK_Get_BEDO_Sat_Health (unsigned char health[37]);

/**
 * @brief   Get the tracked SV of Beidou satellites.
 * @param    TrackedSV is arrays with 30 unsigned char. 
 * @par       Example
 * @code
 *     unsigned char TrackedSV[30];
 *     MTK_Get_BEDO_Sat_Tracked(TrackedSV);
 *     MTK_UART_OutputData("SV12 Tracked or not = %d", TrackedSV[11]);
 *     
 *  =====> SV12 Tracked or not = 1 =====> 1 means SV12 is tracked, otherwise, it will show 0.
 * @endcode
 */
void MTK_Get_BEDO_Sat_Tracked (unsigned char TrackedSV[30]);

/**
 * @brief
 * Get the Azimuth and Elevation angles of all BEIDOU satellites. 
 * "Azim" and "Elev" are arrays with 37 signed char and signed short which are corresponding to 37 BEIDOU satellites.
 * @param[out]   Azim output azimuth
 * @param[out]   Elev output elevation
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char count = 0;
 *     signed short Azim[37];
 *     signed char Elev[37];
 *     MTK_Get_BEDO_Sat_AzEl(Azim, Elev);
 *     MTK_NMEA_OutputData("SDK,Azim%d,%d",count, (int)(*(Azim+count)));
 *     MTK_NMEA_OutputData("SDK,Elev%d,%d",count, (int)(*(Elev+count)));
 *     count++;
 *     count = count % 37;
 * 
 * =====> $SDK,Azim1,219*40
 *        $SDK,Elev1,32*52
 *        $SDK,Azim2,-400*6C
 *        $SDK,Elev2,-99*71
 *        $SDK,Azim3,-400*6D
 *        $SDK,Elev3,-99*70
 *        $SDK,Azim4,-400*46
 *        $SDK,Elev4,-99*61
 *        $SDK,Azim5,-400*54
 *        $SDK,Elev5,-99*49
 *        ...........
 * //This example only show part of the print information
 * @endcode
 */
void MTK_Get_BEDO_Sat_AzEl (signed short Azim[37], signed char Elev[37]);


/**
 * @brief   Get the SNR of all BEIDOU satellites.
 * @param[out]   SNR output SNR of all BEIDOU satellites.
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SNR[37];
 *     MTK_Get_Sat_SNR(SNR);
 *      * Get SNR of SV 1
 *     MTK_UART_OutputData("BEDO,SV1: SNR = %d", SNR[0]);
 *     
 *  =====>BEDO,SV1: SNR = 38
 * @endcode
 */
void MTK_Get_BEDO_Sat_SNR (unsigned char SNR[37]);


/**
 * @brief   Get the SVid of all BEIDOU satellites.
 * This function will tell user the status of all BEIDOU satellites whether they are visible or not. The status will save in an array with 37 unsigned char.
 * @param[out]   SVid  status of all BEIDOU satellites.\n
 *              0       ---> This SV is Not Visible.\n
 *              1       ---> This SV is Visible.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char SVid[37];
 *     MTK_Get_BEDO_Sat_SVid(SVid);
 *      // Get SVid of SV
 *     MTK_UART_OutputData("SDK: BEDO#1,SVid = %d", SVid[35]);
 *  =====> SDK: BEDO#1,SVid = 1  ---> SV36 is visible. 
 * @endcode
 */
void MTK_Get_BEDO_Sat_SVid (unsigned char SVid[37]);


/**
 * @brief
 * Get the information whether satellites has Ephemeris or not. Eph is arrays with 37 unsigned char which are corresponding to 37 BEIDOU satellites.
 * @param[out]   Eph output flags of ephemeris information.\n
 *              0       ---> This SV has no Ephemeris.\n
 *              1       ---> This SV has Ephemeris.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Eph[37];
 *     MTK_Get_BEDO_Sat_Eph_Info(Eph);
 *     MTK_UART_OutputData("SDK: Eph#1 = %d", Eph[0]);
 *
 *  =====> SDK: BEDO,Eph#1 = 1  ---> BEDO#1 has Ephemeris. 
 * @endcode
 */
void MTK_Get_BEDO_Sat_Eph_Info (unsigned char Eph[37]);


/**
 * @brief
 * Get the information whether BEIDOU satellites has Almanac or not. Alm is arrays with 37 unsigned char which are corresponding to 37 BEIDOU satellites.
 * @param[out]   Alm output flags of Almanac information.\n
 *              0       ---> This SV has no almanac.\n
 *              1       ---> This SV has almanac.\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char Alm[37];
 *     MTK_Get_BEDO_Sat_Alm_Info(Alm);
 *     MTK_UART_OutputData("SDK: BEDO,Alm#1 = %d", Alm[0]);
 *
 *  =====> SDK: BEDO,Alm#1 = 1  ---> BEDO#1 has Almanac. 
 * @endcode
 */
void MTK_Get_BEDO_Sat_Alm_Info (unsigned char Alm[37]);


/**
 * @brief
 * Get active BEIDOU satellites (used for fix calculation). Used is an array with 37 unsigned chars which are corresponding to 37 BEIDOU satellites.
 * @param[out]  Used output status of active BEIDOU satellites.\n
 *              used[x]=0 ---> Satellite PRN 'x+1' is non-active\n
 *              used[x]=1 ---> Satellite PRN 'x+1' is active\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char used[37];
 *     MTK_Fix_Get_BEDO_Sats_Used(used);
 *     MTK_UART_OutputData("SDK: BEDO,SV#1 used=%d", used[0]);
 * @endcode
 */
void MTK_Fix_Get_BEDO_Sats_Used (unsigned char Used[37]);


/**
 * @brief   Set MTK Kernel Navigation Mode.\n
 * User can choose the most suitable mode depends on the actual application condition. Currently four optional modes have been provided for user.\n
 * 'normal mode':  For general purpose.\n
 * 'fitness mode': For running and walking purpose that the low-speed (< 5m/s) movement will have more effect on the position calculation.\n
 * 'aviation mode': For high-dynamic purpose that the large-acceleration movement will have more effect on the position calculation.\n
 * 'balloon mode':  For high-altitude balloon purpose that the vertical movement will have more effect on the position calculation.\n
 * 'Stationary mode': For stationary applications that zero dynamics is assumed.\n
 * @param[in]  NavigationMode 0  : normal mode\n
 *                      1  : fitness mode\n             
 *                      2  : aviation mode\n
 *                      3  : balloon mode\n
 *                      4  : Stationary mode\n 
 * @return 0 : Setting fail\n
 *         1 : setting OK
 * @par       Example
 * @code
 *     unsigned char NavigationMode;
 *     NavigationMode = 1;
 *     MTK_Set_Navigation_Mode(NavigationMode);
 * @endcode
 */
int MTK_Set_Navigation_Mode(unsigned char NavigationMode);


/**
 * @brief
 * Get MTK Kernel Navigation Mode. Currently four optional modes have been provided for user. 
 * 'normal mode':  default mode which used in normal condition.
 * 'fitness mode':   will get better performance in slow motion condition.
 * 'aviation mode': will get better performance in very fast motion condition.
 * 'bloom mode':    will get better performance in very high altitude condition.
 * @param[out]  NavigationMode 0  : normal mode\n
 *                      1  : fitness mode\n             
 *                      2  : aviation mode\n
 *                      3  : balloon mode\n 
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char NavigationMode;
 *     MTK_Get_Navigation_Mode(&NavigationMode);
 *     MTK_UART_OutputData("SDK: NaviMode,%d", NavigationMode);
 * @endcode
 */
void MTK_Get_Navigation_Mode(unsigned char *NavigationMode);

/**
 * @brief
 * Set EASY status. EASY function will help to fast fix.
 * @param[in]   EnableEasy EasyStatus = 0 ---> Disable EASY function\n
 *          EnableEasy = 1 ---> Enable EASY function\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char EnableEasy;
 *     EnableEasy = 1;
 *     MTK_Set_EASY_Status(EnableEasy);
 * @endcode
 */
void MTK_Set_EASY_Status (unsigned char EnableEasy);

/**
 * @brief
 * Get EASY status. EASY function will help to fast fix.
 * @param[out]   EasyStatus EasyStatus = 0 ---> EASY function is disable\n
 *         EasyStatus = 1 ---> EASY function is enable\n
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char EasyStatus;
 *     MTK_Get_EASY_Status(&EasyStatus);
 *     MTK_UART_OutputData("SDK: EasyStatus = %d", EasyStatus);
 * @endcode
 */
void MTK_Get_EASY_Status (unsigned char *EasyStatus);

/**
 * @brief
 * User can set which aiding data type should be used by calling this function. There are three types provide for user: EPO, BEE, EASY.
 * @param[in] fgEnableEPO  fgEnableEPO = 1 : accept EPO data.   fgEnableEPO = 0 : reject EPO data
 * @param[in] fgEnableBEE  fgEnableBEE = 1 : accept BEE data.   fgEnableBEE = 0 : reject BEE data
 * @param[in] fgEnableEASY fgEnableEASY = 1 : accept EASY data.  fgEnableEASY = 0: reject EASY data
 * @note BEE and EASY function are mutual exclusion. The priority of BEE is large than EASY.\n
 * @return 
 * void
 * @par       Example
 * @code
 *  MTK_Set_Prediction_Type(1,0,0)  : Enable EPO  
 *  MTK_Set_Prediction_Type(1,1,0)  : Enable EPO + BEE
 *  MTK_Set_Prediction_Type(1,0,1)  : Enable EPO + EASY
 *  MTK_set_prediction_type(1,1,1)  : Enable EPO + BEE  (Because BEE and EASY are mutual exclusion, EASY are disabled in this case )
 *  MTK_Set_Prediction_Type(0,1,0)  : Enable BEE
 *  MTK_Set_Prediction_Type(0,0,1)  : Enable EASY
 *  MTK_Set_Prediction_Type(0,0,0)  : Disable all aiding function
 * @endcode
 */
void MTK_Set_Prediction_Type(unsigned char fgEnableEPO, unsigned char fgEnableBEE, unsigned char fgEnableEASY);

/**
 * @brief
 * User can get which aiding data type is being used by calling this function. There are three types provide for user: EPO, BEE, EASY.
 * @param[out] fgEnableEPO  fgEnableEPO = 1 : accept EPO data.   fgEnableEPO = 0 : reject EPO data
 * @param[out] fgEnableBEE  fgEnableBEE = 1 : accept BEE data.   fgEnableBEE = 0 : reject BEE data
 * @param[out] fgEnableEASY fgEnableEASY = 1 : accept EASY data.  fgEnableEASY = 0: reject EASY data
 * @return 
 * void
 * @par       Example
 * @code
 *     unsigned char fgEnableEPO;
 *     unsigned char fgEnableBEE;
 *     unsigned char fgEnableEASY;
 * 
 *     MTK_Get_Prediction_Type(&fgEnableEPO,&fgEnableBEE,&fgEnableEASY);
 *     MTK_UART_OutputData("SDK: fgEnableEPO = %d,fgEnableBEE = %d, fgEnableEASY = %d", fgEnableEPO, fgEnableBEE, fgEnableEASY);
 * @endcode
 */
void MTK_Get_Prediction_Type(unsigned char *fgEnableEPO, unsigned char *fgEnableBEE, unsigned char *fgEnableEASY);

/**
 * @brief Set SNR Mask Value.
 * @param[in] SNR_MASK SNR Mask Value
 * @return 0,Set SNR Mask Fail    1,Set SNR Mask Success
 * @note the valid value of SNR Mask is from 9 to 37
 */
int MTK_Set_SNR_Mask (unsigned char SNR_MASK);

/**
 * @brief  Get SNR Mask Value.
 * @param[out] SNR_MASK SNR Mask Value
 */
void MTK_Get_SNR_Mask (unsigned char *SNR_MASK);
  
/**
 * @brief    
 * User can send PMTK command through SDK. 
 * @param[in] pBuff the pointer of PMTK string buffer. The buffer will include PMTK Command ACK String.
 * @return
 *     0 means fail, 1 means success.
 * @par Example
 * @code
 *     char pBuff[128]="$PMTK101*31";
 *     MTK_Set_PMTK_CMD(pBuff);
 * @endcode
 * @note 
 *     Buffer length should be 128 bytes.
 */
int MTK_Set_PMTK_CMD(char *pBuff);

/**
 * @brief  Set NMEA sentence output.
 * User can determine which type of NMEA sentence should be output and output period of each sentence. Input parameter is an 18 unsigned int array which is corresponding to multiple type of NMEA sentences.
 * @param[in] NmeaOut NmeaOut[18] input array must be have 18 variables\n
 *           Index: 0 GLL, 1 RMC, 2 VTG, 3 GGA, 4 GSA, 5 GSV, 6 ZDA, 7 GST, 8 GRS, 9 PMTKCHN, 10 DTM, 11 GBS, 12 GPACCURACY, 11~17 Reserved.\n
 *           Value of variables\n
 *               0 - Disabled or not supported sentence\n
 *               1 - Output once every one position fix\n
 *               2 - Output once every two position fixes\n
 *               3 - Output once every three position fixes\n
 *               4 - Output once every four position fixes\n
 *               5 - Output once every five position fixes\n
 * @return   0 means fail, 1 means success
 * @par       Example
 * @code
 *      unsigned int NmeaOut[18];
 *      MTK_Set_NMEA_Output(NmeaOut);
 * @endcode
 * @note  Settings of GST and GRS are only valid when firmware support GST/GRS sentences.
 */
int MTK_Set_NMEA_Output(unsigned int NmeaOut[]);


/**
 * @brief  Get NMEA sentence output info.
 * User can get the configuration of NMEA sentences output. Output parameter is an 18 unsigned int array which is corresponding to multiple type of NMEA sentences.
 * @param[out] NmeaOut NmeaOut[18], output array must be have 18 variables\n
 *           Index: 0 GLL, 1 RMC, 2 VTG, 3 GGA, 4 GSA, 5 GSV, 6 ZDA, 7 GST, 8 GRS, 9 PMTKCHN, 10 DTM, 11 GBS, 12 GPACCURACY, 11~17 Reserved\n
 *           Value of variables\n
 *               0 - Disabled or not supported sentence\n
 *               1 - Output once every one position fix\n
 *               2 - Output once every two position fixes\n
 *               3 - Output once every three position fixes\n
 *               4 - Output once every four position fixes\n
 *               5 - Output once every five position fixes\n
 * @return   0 means fail, 1 means success
 * @par       Example
 * @code
 *       unsigned int NmeaOut[18];
 *       MTK_Get_NMEA_Output(NmeaOut);
 * @endcode
 * @note  The info of GST and GRS can be gotten when firmware support GST/GRS sentences.
 */
int MTK_Get_NMEA_Output(unsigned int NmeaOut[]);

/**
 * @brief
 * Get Clock Status. This function will return where the clock information was gotten from.
 * @return   0 - no clock; 1 - RTC  ; 2 - Synced to GPS ; 3 - From GPS fix
 */
int MTK_Get_Clock_Status(void);

/**
 * @brief  Set GNSS search mode.
 * User can choose which navigation system should be used by calling this function. Input is a 32-bit bitmap corresponding to multiple navigation system.
 * @param[in] GNSS_BitMask bit value 0:disable 1:enable\n
 *              Bit 0: Set GPS\n
 *              Bit 1: Set GLONASS\n
 *              Bit 2: Set BEIDOU\n
 *              Bit 3: Set GALILEO\n
 *              Bit 4~31:reserved\n
 * @return   0 - fail   1 - success
 * @par Example
 * @code
 *     int GNSS_BitMask = 0;
 *     GNSS_BitMask = GNSS_BitMask | 0x01 | 0x02;
 *     Result:
 *     -->     GPS and GLONASS satellites will be used to fix.
 * @endcode
 * @note
 * Currently it can't support BEIDOU and GLONASS at the same time. AG3331 can't support GALILEO.
 */
int MTK_Set_GNSS_Mode(int GNSS_BitMask);

/**
 * @brief
 * User can choose which customized sentence should be output. It's suggest to use this function in SDK_Init();
 * @param[in] BitMask Customization sentence Bit mask, bit value 0:output  1:don't output\n
 *              Bit 0:MTKGPS sentence\n
 *              Bit 1:GPTXT\n
 *              Bit 2~31:reserved\n
 * @return   0 - fail   1 - success
 * @par Example
 * @code
 * int BitMask = 0;
 * BitMask = BitMask | 0x01;
 * Result:
 * -->     GPTXT will be output, and MTKGPS sentences will not.
 * @endcode
 */
int MTK_Set_CustomizationStn_Output(int BitMask);

/**
 * @brief
 * User can get velocity of three directions ( north, east, down).
 * @param[out] North_Vel      North velocity. Unit: m/s.
 * @param[out] East_Vel       East velocity. Unit: m/s.
 * @param[out] Down_Vel      Down velocity. Unit: m/s.
 * @return 
 * void
 * @par Example
 * @code
 * double North_Vel;
 * double East_Vel;
 * double Down_Vel;
 * MTK_Get_NED_Velocity (&North_Vel, &East_Vel, &Down_Vel);
 * @endcode
 */
void MTK_Get_NED_Velocity ( double *North_Vel, double *East_Vel, double *Down_Vel);

/**
 * @brief  Bypass PMTK command handle.
 * User can use this function to enable or disable PMTK command (default enable). 
 * @param[in] Flag  default Flag = 0;\n
 * @param[in] Flag:   Flag = 1, Bypass PMTK command handle\n
 * Flag = 0, don't Bypass PMTK command handle (default)
 * @return 
 * void
 */
void MTK_Set_Bypass_PMTK_Handle(unsigned char Flag);

/**
 * @brief    
 * Query AIC result.
 * @param[out] Jamming_Freq jamming frequency(MHz), zero means no jamming detect
 * @return 
 * void
 * @par       Example
 * @code
 *     float Jamming_Freq[12];
 *     MTK_Get_AIC_Result (Jamming_Freq);
 *     MTK_UART_OutputData("SDK: Jamming_Freq = %f", Jamming_Freq[i]);
 * @endcode
 */
void MTK_Get_AIC_Result(float Jamming_Freq[12]);

/**
 * @brief  Enable/Disable PPS sync NMEA feature.
 * @param  EnableSyncNMEA 0 = Disable\n
 *                                 1 = Enable\n
 * @return  0 = Set Fail.\n
 *           1 = Set Success.\n
 */
unsigned char MTK_Set_SYNC_PPS_NMEA (unsigned char EnableSyncNMEA);

/**
 * @brief    
 * Set Speed in NMEA sentences to be prompt.
 * @param[in]            
 *     Enable_Prompt_Speed = 0 ---> Disable\n
 *     = 1 ---> Enable
 * @return 
 *     1: Success    0: Failure
 * @par       Example
 * @code
 *     unsigned char Enable_Prompt_Speed;
 *     Enable_Prompt_Speed = 1;
 *     MTK_Set_NMEA_Prompt_Speed(Enable_Prompt_Speed);
 * @endcode
 */
unsigned char MTK_Set_NMEA_Prompt_Speed(unsigned char Enable_Prompt_Speed);

/**
 * @brief    
 * Get setting of prompt speed in NMEA sentences.
 * @param[out]            
 *     Enable_Prompt_Speed = 0 ---> Disable\n
 *      = 1 ---> Enable
 * @par       Example
 * @code
 *     unsigned char Enable_Prompt_Speed;
 *     MTK_Get_NMEA_Prompt_Speed(&Enable_Prompt_Speed);
 *     MTK_UART_OutputData("SDK: Enable_Prompt_Speed = %d", Enable_Prompt_Speed);
 * @endcode
 */
void MTK_Get_NMEA_Prompt_Speed(unsigned char *Enable_Prompt_Speed);

/**
 * @brief    
 * Get a single GPS ephemeris. Return the most recently processed GPS Ephemeris sub-
 * frame data-block. The data is the 8 words from the GPS navigation message sub-frame
 * 1,2 and 3 (24 words in total) following the Hand-Over Word (HOW). The 8 most significant
 * parity-bits have been removed.
 * @param[in]            
 *     SVID   Input which GPS satellite's ephemeris you want to get.
 * @param[out]          
 *     word[24]  The buffer to save the ephemeris data of specific satellite.
 * @return 
 *     0 means fail, 1 means success.
 * @par       Example
 * @code
 *     unsigned int SVid;
 *     unsigned int Word[24];
 *     SVid = 5;
 *     MTK_Get_GPS_EPH(SVid, Word); 
 * @endcode
 * @note
 * The input SVID must be between 1 and 32. If MTK GPS Chip doesn't have the ephemeris of the chosen satellite, it will return 0.
 */
int MTK_Get_GPS_EPH(unsigned int SVID, unsigned int word[24]);

/**
 * @brief    
 * Get a single GPS ephemeris. Return the most recently processed GPS Ephemeris sub-
 * frame data-block and Hand-Over Word (HOW) of first subframe. The Ephemeris data is the 
 * 8 words from the GPS navigation message sub-frame 1,2 and 3 (24 words in total) following 
 * the Hand-Over Word (HOW). The 8 most significant parity-bits have been removed.
 * parity-bits have been removed.
 * @param[in]            
 *     SVID   Input which GPS satellite's ephemeris you want to get.
 * @param[out]          
 *     HOW       The Hand-Over Word of first subframe
 *     word[24]  The buffer to save the ephemeris data of specific satellite.
 * @return 
 *     0 means fail, 1 means success.
 * @par       Example
 * @code
 *     unsigned int SVid;
 *     unsigned int HOW;
 *     unsigned int Word[24];
 *     SVid = 5;
 *     MTK_Get_GPS_EPH_HOW(SVid, &HOW, Word); 
 * @endcode
 * @note
 * The input GPS SVID must be between 1 and 32. The supported QZSS SVID is 33.
 * If MTK GPS Chip doesn't have the ephemeris of the chosen satellite, it will return 0.
 */
int MTK_Get_GPS_EPH_HOW(unsigned int SVID, unsigned int *HOW, unsigned int word[24]);

/**
 * @brief    
 * Get a single GLONASS ephemeris.
 * @param[in]            
 *     SVID    Input which GLONASS satellite's ephemeris you want to get.
 * @param[out]          
 *     word[15]  The buffer to save the ephemeris of specific satellite. Every word contains
 *                     32 bits, every three words make up a string. The detailed description please
 *                     refer to MTK_GPS_SDK_Mannual_Customer.\n
 *                     word[0]~word[3] make up string 1.\n
 *                     ......\n
 *                     word[13]~word[14] make up string 5.\n
 *                     The first word of a string contain bit1~32.\n
 *                     The second word of a string contain bit33~64.
 *                     The third word of a string contains bit65~72, the last eight bits of word is valid.
 * @return 
 *     0 means fail, 1 means success.
 * @par       Example
 * @code
 *     unsigned int SVid;
 *     unsigned int Word[15];
 *     MTK_Get_GLO_EPH(SVid, Word);
 * @endcode
 * @note
 * The input SVID must be between 1 and 24. If MTK GPS Chip doesn't have the
 *           ephemeris of the chosen satellite, it will return 0.
 */
int MTK_Get_GLO_EPH(unsigned int  SVID, unsigned int word[15]);

/**
 * @brief Get a single Beidou ephemeris. Returns the most recently processed Beidou Ephemeris sub-frame data-block.\n 
 *     The data of MEO/IGSO is 7 words from the Beidou navigation message sub-frame 1, 2 and 3 (21 words in total).\n 
 *     The data of GEO is from pages 1~10 of sub-frame 1 following Pnum1.\n 
 *     All the parity-bits in navigation message have been removed.\n
 * @param[in]            
 *     SVID  Input which Beidou satellite's ephemeris you want to get.
 * @param[out]         
 *     Word[30] The buffer to save the ephemeris data of specific satellite.
 *  @return
 *     0 means fail, 1 means success.
 * @par       Example
 * @code
 *     unsigned ret;
 *     unsigned int SVid;
 *     unsigned int Word[30];
 *     SVid = 5;
 *     MTK_Get_BD_EPH(SVid, Word);
 *     ret = MTK_Get_BD_EPH(SVid, Word);  
 *     if ( ret > 0 )
 *     {
 *        if (SVid<=5)
 *        {
 *           MTK_NMEA_OutputData("BD,GEO,EPH,%2d,%8X,%8X,%2X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X",SVid
 *             ,Word[0],Word[1],Word[2]
 *             ,Word[3],Word[4],Word[5]
 *             ,Word[6],Word[7],Word[8]
 *             ,Word[9],Word[10],Word[11]
 *             ,Word[12],Word[13],Word[14]
 *             ,Word[15],Word[16],Word[17]
 *             ,Word[18],Word[19],Word[20]
 *             ,Word[21],Word[22],Word[23]
 *             ,Word[24],Word[25],Word[26]
 *             ,Word[27],Word[28],Word[29]);  
 *        }
 *        else
 *        {
 *           MTK_NMEA_OutputData("BD,MEO/IGSO,EPH,%2d,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X",SVid
 *             ,Word[0],Word[1],Word[2],Word[3],Word[4],Word[5],Word[6]
 *             ,Word[7],Word[8],Word[9],Word[10],Word[11],Word[12],Word[13]
 *             ,Word[14],Word[15],Word[16],Word[17],Word[18],Word[19],Word[20]);
 *        }
 *     }
 * @endcode
 * @note
 * The input SVID must be between 1 and 30. If MTK GPS Chip doesn't have the ephemeris of the chosen satellite, it will return 0.
 */
int MTK_Get_BD_EPH(unsigned int SVID, unsigned int Word[30]);

/**
 * @brief Get a single Beidou ephemeris. Returns the most recently processed Beidou Ephemeris sub-frame data-block and\n 
 *     Seconds Of Week (SOW) of first subframe.
 *     The data of MEO/IGSO is 7 words from the Beidou navigation message sub-frame 1, 2 and 3 (21 words in total).\n 
 *     The data of GEO is from pages 1~10 of sub-frame 1 following Pnum1.\n 
 *     All the parity-bits in navigation message have been removed.\n
 * @param[in]            
 *     SVID  Input which Beidou satellite's ephemeris you want to get.
 * @param[out]         
 *     SOW      The Seconds Of Week (SOW) of first subframe
 *     Word[30] The buffer to save the ephemeris data of specific satellite.
 *  @return
 *     0 means fail, 1 means success.
 * @par       Example
 * @code
 *     unsigned ret;
 *     unsigned int SVid;
 *     unsigned int SOW;
 *     unsigned int Word[30];
 *     SVid = 5;
 *     ret = MTK_Get_BD_EPH_SOW(SVid, &SOW, Word);  
 *     if ( ret > 0 )
 *     {
 *        if (SVid<=5)
 *        {
 *           MTK_NMEA_OutputData("BD,GEO,EPH,%2d,%8X,%8X,%2X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X,%08X,%08X,%02X",SVid
 *             ,Word[0],Word[1],Word[2]
 *             ,Word[3],Word[4],Word[5]
 *             ,Word[6],Word[7],Word[8]
 *             ,Word[9],Word[10],Word[11]
 *             ,Word[12],Word[13],Word[14]
 *             ,Word[15],Word[16],Word[17]
 *             ,Word[18],Word[19],Word[20]
 *             ,Word[21],Word[22],Word[23]
 *             ,Word[24],Word[25],Word[26]
 *             ,Word[27],Word[28],Word[29]);  
 *        }
 *        else
 *        {
 *           MTK_NMEA_OutputData("BD,MEO/IGSO,EPH,%2d,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X,%08X",SVid
 *             ,Word[0],Word[1],Word[2],Word[3],Word[4],Word[5],Word[6]
 *             ,Word[7],Word[8],Word[9],Word[10],Word[11],Word[12],Word[13]
 *             ,Word[14],Word[15],Word[16],Word[17],Word[18],Word[19],Word[20]);
 *        }
 *     }
 * @endcode
 * @note
 * The input SVID must be between 1 and 30. If MTK GPS Chip doesn't have the ephemeris of the chosen satellite, it will return 0.
 */
int MTK_Get_BD_EPH_SOW(unsigned int SVID, unsigned int *SOW, unsigned int Word[30]);

/**
 * @brief
 * Get GPS Kep parameter.
 * @param[in]  
 *    SVID GPS satellite PRN (1~32).
 * @param[out] 
 *    pKep GPS Kep parameter.
 * @return  
 *    zero(fail), nonzero(pass)
 * @par Example
 * @code
 * int SVid = 5;
 * s_MTK_GPS_Kep_Para pKep;
 * MTK_Get_GPS_Kep_Paremeter (SVid, &pKep);
 * @endcode
 */
int MTK_Get_GPS_Kep_Paremeter (int SVID, s_MTK_GPS_Kep_Para* pKep);

/**
 * @brief
 * Get Beidou Kep parameter.
 * @param[in]  
 *    SVID Beidou satellite PRN (1~30)
 * @param[out] 
 *    pKep Beidou Kep parameter
 * @return  
 *     zero(fail), nonzero(pass)
 * @par Example
 * @code
 * int SVid = 5;
 * s_MTK_BD_Kep_Para pKep;
 * MTK_Get_BD_Kep_Paremeter (SVid, &pKep);
 * @endcode
 */
int MTK_Get_BD_Kep_Paremeter (int SVID, s_MTK_BD_Kep_Para* pKep);

/**
 * @brief    
 * Get baudrate of NMEA port (Uart0).
 * @return            
 *     int   baudrate of NMEA port
 * @par       Example
 * @code
 *     int BaudRate;
 *     BaudRate = MTK_Get_NMEA_BaudRate();
 *     MTK_UART_OutputData("SDK: NMEA_Baudrate = %d", BaudRate);
 * @endcode
 */
 int MTK_Get_NMEA_BaudRate(void);

/**
 * @brief    
 * Get position fix in ECEF coordinates (units: meters).
 * @param[out] Pos position fix in ECEF coordinates (units: meters).\n
 * Pos[0]: position fix in x-axis of ECEF coordinates (units: meters).\n
 * Pos[1]: position fix in y-axis of ECEF coordinates (units: meters).\n
 * Pos[2]: position fix in z-axis of ECEF coordinates (units: meters).\n
 * @par       Example
 * @code
 *     double Pos[3];
 *     MTK_Get_ECEF_Pos(Pos);
 *     MTK_UART_OutputData("SDK: ECEF_Pos = (%f, %f, %f)", Pos[0], Pos[1], Pos[2]);
 * @endcode
 */
 void MTK_Get_ECEF_Pos(double Pos[3]);

/**
 * @brief    
 * Get velocity in ECEF coordinates (units: meters/second).
 * @param[out]            
 *     Vel Velocity in ECEF coordinates (units: meters/second).
 * @return 
 * void
 * @par       Example
 * @code
 *     double Vel[3];
 *     MTK_Get_ECEF_Vel(Vel);
 *     MTK_UART_OutputData("SDK: ECEF_Vel = (%f, %f, %f)", Vel[0], Vel[1], Vel[2]);
 * @endcode
 */
void MTK_Get_ECEF_Vel(double Vel[3]);
  
/**
 * @brief    
 * Get ionospheric parameters.
 * @param[out]            
 *     Ionospheric parameters.
 *  @return
 *     0 means fail, 1 means success.
 * @par       Example
 * @code
 *     s_MTK_GPS_Ion_Para ION;
 *     int ret;
 *     
 *     ret = MTK_Get_GPS_IONO(&ION);
 *     if ( ret )
 *     {
 *        MTK_NMEA_OutputData("SDK,%d,%d,%d,%d,%d,%d,%d,%d", ION.a0, ION.a1, ION.a2, ION.a3, ION.b0, ION.b1, ION.b2, ION.b3);
 *     }
 * @endcode
 */
unsigned char MTK_Get_GPS_IONO(s_MTK_GPS_Ion_Para* ION);

/**
 * @brief  Get GNSS search mode.
 * @param[out]  GNSS_BitMask bit value 0:disable 1:enable\n
 *              Bit 0:GPS\n
 *              Bit 1:GLONA\nSS
 *              Bit 2:BEIDOU\n
 *              Bit 3:GALILEO\n
 *              Bit 4~31:reserved\n
 * @return   0 - fail   1 - success
 * @par       Example
 * @code
 *      int GNSS_Mode = 0;
 *      MTK_Get_GNSS_Mode(&GNSS_Mode);
 *      if(GNSS_Mode & 0x01) ....  * search GPS
 *      if(GNSS_Mode & 0x02) ....  * search GLONASS
 *      if(GNSS_Mode & 0x04) ....  * search Beidou
 *      if(GNSS_Mode & 0x08) ....  * search Galileo
 * @endcode
 */
int MTK_Get_GNSS_Mode(int *GNSS_BitMask);

/**
 * @brief   Enter the CW jammer estimation mode.
 * @param arg1 1 = enable Jammer test
 * @param arg2 unused
 * @return  nonzero (success); zero (failure)
 * @par       Example
 * @code
 *         MTK_Enter_Jammer_Test (1,0);    //Start Jamming scan
 * @endcode
 * @note  Please call MTK_Get_Jammer_Result() to retrieve the result
 *         Once the MTK_Get_Jammer_Result() is able to return the number of
 *         jammers, the system leaves the test mode automatically.
 */
unsigned char MTK_Enter_Jammer_Test (unsigned short arg1, unsigned short arg2);

/**
 * @brief   Obtain the CW jammer estimation result.
 * @return  the number (0~195) of jammer peaks if ready
 *           0 means no jammer detected
 *           negative if not ready
 * @note Caller provides 'Freq' and 'JNR' to get the result
 *           'Freq' is the jammer frequency offset in KHz, the base frequence is 1573379250Hz
 *           'JNR' of the same index is the associated JNR value
 *           JNR[.] = 0 means the data of the index is not valid
 *           If the returned number is greater than 0, the Freq[.] and JNR[.]
 *           are being filled the result from the index 0, 1, 2, sequentially.
 *           For example, if the return value is 2, the (Freq[0],JNR[0]) is the
 *           first peak. The (Freq[1], JNR[1]) is the second jammer peak.
 */
int MTK_Get_Jammer_Result (short Freq[195], unsigned short JNR[195]);

/**
 * @brief    
 * Get accuracy value.
 * @param[out]            
 *     Accuracy accuracy parameter. please refer to struct s_MTK_Acc_T.
 * @par       Example
 * @code
 *     s_MTK_Acc_T Accuracy;
 *     MTK_Get_Acc (&Accuracy);
 * @endcode
 */
void MTK_Get_Acc(s_MTK_Acc_T *Accuracy);

/**
 * @brief  Set GNSS Low Power(GLP) Mode status.
 * @param   Type  0 ---> Disable GLP function.\n
 *                3 ---> Enable GLP function.
 * @note
 *      (1) In order to achieve minimum current consumption value,
 *          Please use the following settings. \n
 *              - (a) MTK_Set_Elev_Mask(10);               : to prevent search low elevation angle. \n
 *              - (b) MTK_Set_Intelligent_PowerSaving(1);  : to prevent tracking too many satellites. \n
 *              - (c) MTK_Set_Diff_Mode(0);                : SBAS data collection will fail in FLP operation.  \n
 *              - (d) Provide EPO data                     : It will help the receiver to reduce more power. \n \n
 *      
 *      (2) The GNSS low power mode function setting is not kept in the non-vol.   \n
 *          Please call this function in SDK_Init every start. \n \n
 * 
 *      (3) It is not supported to enable in non 1Hz mode \n
 *  
 * @return value 0 : Setting GLP Type fail ;  \n
 *               1 : Setting OK \n
 * 
 * @par       Example
 * @code
 *     int Type;
 *     Type = 3;  
 *     MTK_Set_GNSS_Low_Power_Mode(Type);
 * @endcode
 */
int MTK_Set_GNSS_Low_Power_Mode (int Type);

/**
 * @brief  Get the GNSS Low Power(GLP) Mode status.
 * @return current GNSS Low Power Mode status
 * @param   Type  0 ---> GLP function is disabled\n
 *                3 ---> GLP function is enabled
 * @par       Example
 * @code
 *     int Type;
 *     MTK_Get_GNSS_Low_Power_Mode (&Type);
 *     MTK_UART_OutputData("SDK: GNSS_Low_Power_Mode = %d", Type);
 * @endcode
 */
void MTK_Get_GNSS_Low_Power_Mode (int *Type);


/**
 * @brief  Select GIO to control externl LNA.
 * @param GIO Selection can be GIO 0,1,2,3,4,5
 * @param EnableOrDisable  Enable or Disable this function\n
 *                  0 : Disable\n
 *                  1 : Enable\n
 * @par       Example
 * @code
 *     MTK_Set_GIO_CONTROL_EXT_LNA(5,1);  => Enable GIO5 to control external LNA 
 *     //This function must be called in the SDK_Hw_Init.
 * @endcode
 */
void MTK_Set_GIO_CONTROL_EXT_LNA(unsigned char GIO, unsigned char EnableOrDisable);

/**
 * @brief  GIO selection which is to control externl LNA.
 * @param GIO Selection can be GIO 0,1,2,3,4,5
 * @param EnableOrDisable  Enable or Disable this function\n
 *                  0 : Disable\n
 *                  1 : Enable\n
 * @par       Example
 * @code
 *     unsigned char GIO;
 *     unsigned char EnableOrDisable;
 *     MTK_Get_GIO_CONTROL_EXT_LNA(&GIO,&EnableOrDisable);
 * @endcode
 */
void MTK_Get_GIO_CONTROL_EXT_LNA(unsigned char *GIO, unsigned char *EnableOrDisable);

/**
 * @brief  Get the indicator to check whether there are any jammers
 * @param JamIndicator 
 *              0 : No support / Unknown status\n
 *              1 : No jammer, healthy status\n
 *              2 : Warning status\n
 *              3 : Critical status\n
 * @par       Example :
 * @code
 *    unsigned char JamIndicator;
 *    MTK_Get_Jamming_Indicator(&JamIndicator);
 * @endcode 
 */
void MTK_Get_Jamming_Indicator(unsigned char *JamIndicator);

/**
 * @brief    
 * Get satellite information of all 32 channels, include number of SV used, SVID, elevation, azimuth and CNR.\n
 * Current only support GPS(1~32), QZSS(193~195) and GLONASS(65~88), 
 * Signal quality indicator:
 *   0: No signal
 *   1: Searching signal       
 *   2: Signal aquired       
 *   3: Signal detected but unusable  
 *   4: Code locked       
 *   5: Code and carrier locked  
 * @param SVNumUsed number of SV used for positioning
 * @param SVID id of satelite
 * @param Elev elevation
 * @param Azim azimuth
 * @param CNR carrier noise ratio
 * @par       Example
 * @code
 *     int ChnNum;
 *     unsigned int SVID[32];
 *     int Elev[32];
 *     unsigned int Azim[32];
 *     unsigned int CNR[32];
 *     unsigned int SQI[32];
 *     MTK_Get_SVINFO(&ChnNum, SVID, Elev, Azim, CNR, SQI);
 * @endcode
 */
void MTK_Get_SVINFO(int *ChnNum, unsigned int SVID[32], int Elev[32], unsigned int Azim[32], unsigned int CNR[32],unsigned int SQI[32]);

/**
 * @brief    
 * Get position fix in ECEF coordinates (units: meters).
 * @param[out] Pos position fix in ECEF coordinates (units: meters).\n
 * Pos[0]: position fix in x-axis of ECEF coordinates (units: meters).\n
 * Pos[1]: position fix in y-axis of ECEF coordinates (units: meters).\n
 * Pos[2]: position fix in z-axis of ECEF coordinates (units: meters).\n
 * @return 
 * void
 * @par       Example
 * @code
 *     double Pos[3];
 *     MTK_Get_ECEF_Pos(Pos);
 *     MTK_UART_OutputData("SDK: ECEF_Pos = (%f, %f, %f)", Pos[0], Pos[1], Pos[2]);
 * @endcode
 */
void MTK_Get_ECEF_Pos(double Pos[3]);

/**
 * @brief    
 * Get velocity in ECEF coordinates (units: meters/second).
 * @param[out]            
 *     Vel Velocity in ECEF coordinates (units: meters/second).
 * @return 
 * void
 * @par       Example
 * @code
 *     double Vel[3];
 *     MTK_Get_ECEF_Vel(Vel);
 *     MTK_UART_OutputData("SDK: ECEF_Vel = (%f, %f, %f)", Vel[0], Vel[1], Vel[2]);
 * @endcode
 */
void MTK_Get_ECEF_Vel(double Vel[3]);
  
/**
 * @brief    
 * Get system timer tick (units: 10 millisecond).
 * @par       Example
 * @code
 *     unsigned int SystemTimerTick;
 *     MTK_Get_System_Timer_Tick(&SystemTimerTick);
 *     MTK_UART_OutputData("SDK: SystemTimerTick = %d", SystemTimerTick);
 * @endcode
 */
void MTK_Get_System_Timer_Tick(unsigned int *SystemTimerTick);

/**
 * @brief
 * Query / Set Start Week Number.
 * @param StartWN 0 --> Query week number, non zero value --> Set week number.
 * @return 0 --> Invalid Setting.\n
 *         non zero value --> Current week number setting.\n
 * @note The week number setting must be larger than the default FW setting.
 */
unsigned long MTK_Start_Week_Number_Setting(unsigned long StartWN);

/**
 * @brief
 * Get Galileo/GPS time offset
 * @par       Example
 * @code
 *     s_MTK_GLEO_Time_Offset Galileo_Time_Offset;
 *     MTK_Get_GLEO_Time_Offsets(&Galileo_Time_Offset);
 *     MTK_UART_OutputData("SDK: Galileo_Time_Offset = %f,%f,%d,%d",Galileo_Time_Offset.A0G,Galileo_Time_Offset.A1G,Galileo_Time_Offset.t0G,Galileo_Time_Offset.WN0G);
 * @endcode
 */
unsigned char MTK_Get_GLEO_Time_Offsets(s_MTK_GLEO_Time_Offset *GLEO_Time_Offset);

/**
 * @brief
 * Disable/Enable position output in high sensitivity tracking mode
 * @param   Disable_Position_Output  1 ---> Disable\n
 *                                   0 ---> Enable (Default)
 * @return
 * 1: Success    0: Failure
 * @par       Example
 * @code
 *     unsigned char Disable_Position_Output;
 *     Disable_Position_Output = 1;
 *     MTK_Set_High_Sensitivity_Tracking_Position_Output(Disable_Position_Output);
 * @endcode
 */
unsigned char MTK_Set_High_Sensitivity_Tracking_Position_Output(unsigned char Disable_Position_Output);

/**
 * @brief
 * Get setting of position output disabled/enabled in high sensitivity tracking mode
 * @param[out]   Disable_Position_Output  1 ---> Disable\n
 *                                        0 ---> Enable (Default)
 * @return
 * void
 * @par       Example
 * @code
 *     unsigned char Disable_Position_Output;
 *     MTK_Get_High_Sensitivity_Tracking_Position_Output(&Disable_Position_Output);
 *     MTK_UART_OutputData("SDK: Disable_Position_Output = %d", Disable_Position_Output);
 * @endcode
 */
void MTK_Get_High_Sensitivity_Tracking_Position_Output(unsigned char *Disable_Position_Output);

/**
 * @brief
 * Get Galileo RLM data (10 beacons' RLM recently received)
 * @param BeaconID[10][3]  Beacon ID of the RLM, It uniquely identifies the beacon to which the RLM is addressed.
 * @param MessageCode[10] Message code
 * @param Parameter[10][5] The parameter field provides the information related to the specific RLS identified by the "Message code"
 * @param RLMType[10] The type of RLM, short type RLM or long type RLM
 * @param GpsSeconds[10] The GPS second when received this RLM
 * @return the number of RLM that has been received. Max number is 10.
 * @par       Example
 * @code
 *    unsigned int BeaconID[10][3];
 *    unsigned char MessageCode[10];
 *    unsigned int Parameter[10][5]; 
 *    unsigned char RLMType[10]; 
 *    unsigned int GpsSeconds[10];
 *    unsigned int count;
 *    int i;
 *    count = MTK_Get_GLEO_RLM(BeaconID,MessageCode,Parameter,RLMType,GpsSeconds);
 *    for (i = 0; i < count; ++i)
 *   {
 *           if (RLMType[i] == 0)      // show the short type RLM received
 *       {
 *           MTK_NMEA_OutputData("RLM:Total:%d,Cur:%d,ID:%5x%5x%5x,Message code:%d,Parameter:%4x,Time:%d", count,i+1,
 *                                          BeaconID[i][0],BeaconID[i][1],BeaconID[i][2],MessageCode[i],Parameter[i][0],GpsSeconds[i]);
 *       }
 *       else if (RLMType[i] == 1)   // show the long type RLM received
 *       {
 *          MTK_NMEA_OutputData("RLM:Total:%d,Cur:%d,ID:%5x%5x%5x,Message code:%d,Parameter:%4x%5x%5x%5x%5x,Time:%d", count,i+1,
 *                                          BeaconID[i][0],BeaconID[i][1],BeaconID[i][2],MessageCode[i],Parameter[i][0],
 *                                          Parameter[i][1],Parameter[i][2],Parameter[i][3],Parameter[i][4],GpsSeconds[i]);
 *       }
 *   }
 * @endcode
 */

unsigned int MTK_Get_GLEO_RLM(unsigned int BeaconID[10][3], 
                                           unsigned char MessageCode[10], 
                                           unsigned int Parameter[10][5], 
                                           unsigned char RLMType[10], 
                                           unsigned int GpsSeconds[10]);

/**
 * @brief
 * This API is used to start counting of odometer feature
 * @return
 * 1: Success\n    0: Failure
 * @par       Example
 * @code
 *    MTK_Odometer_Start();
 * @endcode
 */
int MTK_Odometer_Start(void);

/**
 * @brief
 * This API is used to stop odometer feature and keep the distance value
 * @return
 * 1: Success\n    0: Failure
 * @par       Example
 * @code
 *    MTK_Odometer_Stop();
 * @endcode
 */
int MTK_Odometer_Stop(void);

/**
 * @brief
 * This API is used to get the distance value of current state.
 * @param   distance: the move distance from odometer start.
 * @return
 * 1: Success\n    0: Failure
 * @par       Example
 * @code
 *    double distance;
 *    MTK_Odometer_Query(&distance);
 *    MTK_NMEA_OutputData("SDK, distance:%.2f", distance);
 * @endcode
 */
int MTK_Odometer_Query(double *distance);


/**
 * @brief
 * This API is used to get the accurate SNR of all GPS satellites.
 * @param[out]   SNR: satellites SNR
 * @return
 * void
 * @par       Example
 * @code
 *    float SNR[32];
 *    MTK_Get_Sat_Accurate_SNR(SNR);
 *    MTK_UART_OutputData("SV17: SNR = %lf", SNR[16]);
 *    =====> SV17: SNR = 38.1
 * @endcode
 */
void MTK_Get_Sat_Accurate_SNR ( float SNR[32]);


/**
 * @brief
 * This API is used to get the accurate SNR of all GLONASS satellites.
 * @param[out]   ASNR: satellites SNR
 * @return
 * void
 * @par       Example
 * @code
 *    float ASNR[24];
 *    MTK_Get_GLON_Sat_Accurate_SNR(ASNR);
 *    MTK_UART_OutputData("GLON,SV1: SNR = %lf", SNR[0]);
 *    =====> GLON,SV1: SNR = 38.1
 * @endcode
 */
void MTK_Get_GLON_Sat_Accurate_SNR ( float ASNR[24]);

/**
 * @brief
 * This API is used to get the accurate SNR of all GALILEO satellites.
 * @param[out]   ASNR: satellites SNR
 * @return
 * void
 * @par       Example
 * @code
 *    float ASNR[30];
 *    MTK_Get_GLEO_Sat_Accurate_SNR(ASNR);
 *    MTK_UART_OutputData("GLEO,SV1: SNR = %lf", SNR[0]);
 *    =====> GLEO,SV1: SNR = 38.1
 * @endcode
 */
void MTK_Get_GLEO_Sat_Accurate_SNR ( float ASNR[30] );

/**
 * @brief
 * This API is used to get the accurate SNR of all BEIDOU satellites.
 * @param[out]   ASNR: satellites SNR
 * @return
 * void
 * @par       Example
 * @code
 *    float ASNR[37];
 *    MTK_Get_BEDO_Sat_Accurate_SNR(ASNR);
 *    MTK_UART_OutputData("BEDO,SV1: SNR = %lf", SNR[0]);
 *    =====> BEDO,SV1: SNR = 38.1
 * @endcode
 */
void MTK_Get_BEDO_Sat_Accurate_SNR ( float ASNR[37] );


/**
 * @brief
 * Set dynamic performance to be AXN3.8-like performance
 * @param   Mode  0 ---> Original performance (Default)\n
 *                1 ---> AXN3.8-like performance: Trajectory could be more smooth, but it might suffer long-time position bias
 * @return
 * 1: Success    0: Failure
 * @par       Example
 * @code
 *     unsigned char Mode;
 *     Mode = 1;
 *     MTK_Set_Dynamic_Performance_Mode(Mode);
 * @endcode
 */
unsigned char MTK_Set_Dynamic_Performance_Mode(unsigned char Mode);

/**
 * @brief
 * Get setting of dynamic performance mode
 * @param[out]   Mode  0 ---> Original performance (Default)\n
 *                     1 ---> AXN3.8-like performance
 * @return
 * void
 * @par       Example
 * @code
 *     unsigned char Mode;
 *     MTK_Get_Dynamic_Performance_Mode(&Mode);
 *     MTK_UART_OutputData("SDK: Dynamic_Performance_Mode = %d", Mode);
 * @endcode
 */
void MTK_Get_Dynamic_Performance_Mode(unsigned char *Mode);

/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
   }
#endif

#endif /* MTK_SDK_H */
